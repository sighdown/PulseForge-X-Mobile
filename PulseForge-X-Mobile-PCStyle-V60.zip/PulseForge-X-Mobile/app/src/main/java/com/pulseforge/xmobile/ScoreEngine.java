package com.pulseforge.xmobile;
import java.util.*;

public final class ScoreEngine {
 public static final String MODEL_VERSION="early_v60";
 public static class Hist { public double price,qv,oi; public Hist(double p,double q,double o){price=p;qv=q;oi=o;} }
 public static class Result {
  public double score,preLateScore,confidence,vz,oz,ret1,ret3,ret5,ret10,ret20,ret30,ret60,compression,prebreakout,gap,chase,dist20,burst,latePenalty;
  public int leadCount,staleHighMin;
  public boolean lateBlocked;
  public String lateFlag="";
 }
 static double clamp(double x){return Math.max(0,Math.min(100,x));}
 static double pct(double p,double old){return p>0&&old>0?(p/old-1)*100:0;}
 static double agoPct(double price,List<Hist> h,int n){return h.size()>=n?pct(price,h.get(h.size()-n).price):0;}
 static double z(List<Double> vals,double x){List<Double> v=new ArrayList<>(); for(double d:vals)if(d>0)v.add(d); if(v.size()<5)return 0; double m=0;for(double d:v)m+=d;m/=v.size();double s=0;for(double d:v)s+=(d-m)*(d-m);s=Math.sqrt(s/v.size());return s<=0?0:Math.max(-4,Math.min(4,(x-m)/s));}
 static double compression(double r){if(r<=.8)return 100;if(r<=1.5)return 88;if(r<=2.5)return 68;if(r<=4)return 42;if(r<=6)return 22;return 8;}
 static double[] pre(double price,double high){if(price<=0||high<=0)return new double[]{35,0};double g=(high-price)/high*100;if(g>=.08&&g<=.8)return new double[]{100,g};if(g>=0&&g<.08)return new double[]{88,g};if(g>.8&&g<=1.8)return new double[]{82,g};if(g>1.8&&g<=3)return new double[]{58,g};if(g>=-.25&&g<0)return new double[]{58,g};if(g<-.25)return new double[]{12,g};return new double[]{28,g};}
 static double quiet(double r3,double r10){if(r3>=-.5&&r3<=.9&&r10>=-1&&r10<=1.8)return 100;if(r3>=-1&&r3<=1.5&&r10>=-2&&r10<=3)return 78;if(r3>=-1.5&&r3<=2&&r10>=-3&&r10<=4)return 52;return 15;}
 static double funding(double f){if(f<=-.00030)return 100;if(f<=-.00010)return 88;if(f<=0)return 72;if(f<=.00010)return 55;if(f<=.00030)return 35;return 15;}
 static double meanPrice(List<Hist> h,int n){int a=Math.max(0,h.size()-n);double s=0;int c=0;for(int i=a;i<h.size();i++)if(h.get(i).price>0){s+=h.get(i).price;c++;}return c>0?s/c:0;}
 static double burstRatio(List<Hist> h,double ret1){if(h.size()<8)return 0;int a=Math.max(1,h.size()-18);double s=0;int c=0;for(int i=a;i<h.size();i++){double x=Math.abs(pct(h.get(i).price,h.get(i-1).price));if(x<20){s+=x;c++;}}double avg=c>0?s/c:0;return Math.abs(ret1)/(avg+.05);}
 static int staleHigh(List<Hist> h,double price){if(price<=0||h.isEmpty())return 0;int a=Math.max(0,h.size()-30);for(int i=a;i<h.size();i++){double p=h.get(i).price;if(p>0&&p>=price*.994)return h.size()-i;}return 0;}
 static String lateFlag(double r1,double r3,double r5,double r10,double r30,double r60,double change24,double pb,double comp,int stale,double dist20,double latePenalty){
  if(r1>=2.2||r3>=4.0||r5>=5.5||r10>=7.5)return "FAST_SPIKE";
  if(r30>=10.0||r60>=15.0)return "EXTENDED_MOVE";
  if(change24>=18&&stale>=12&&pb>=82&&comp>=65&&Math.abs(r10)<=2.0)return "STALE_HIGH";
  if(dist20>=4.5&&change24>=10)return "MEAN_STRETCH";
  if(latePenalty>=18)return "OVEREXTENDED";
  return "";
 }
 public static Result compute(double price,double qv,double change24,double fund,double oi,List<Hist> h,double btc){
  List<Double> qd=new ArrayList<>(),oc=new ArrayList<>();int start=Math.max(1,h.size()-24);for(int i=start;i<h.size();i++){double d=h.get(i).qv-h.get(i-1).qv;if(d>=0)qd.add(d);if(h.get(i-1).oi>0&&h.get(i).oi>0)oc.add((h.get(i).oi/h.get(i-1).oi-1)*100);}
  double vd=h.isEmpty()?0:Math.max(0,qv-h.get(h.size()-1).qv),vz=z(qd,vd);double lastOi=0;for(int i=h.size()-1;i>=0;i--)if(h.get(i).oi>0){lastOi=h.get(i).oi;break;}double oiPct=oi>0&&lastOi>0?(oi/lastOi-1)*100:0,oz=oi>0?z(oc,oiPct):0;
  double r1=agoPct(price,h,1),r3=agoPct(price,h,3),r5=agoPct(price,h,5),r10=agoPct(price,h,10),r20=agoPct(price,h,20),r30=agoPct(price,h,30),r60=agoPct(price,h,60);
  List<Double> recent=new ArrayList<>();for(int i=Math.max(0,h.size()-12);i<h.size();i++)if(h.get(i).price>0)recent.add(h.get(i).price);double comp=35,pb=35,gap=0;if(!recent.isEmpty()){double hi=Collections.max(recent),lo=Collections.min(recent),mean=0;for(double p:recent)mean+=p;mean/=recent.size();comp=compression(mean>0?(hi-lo)/mean*100:99);double[] pr=pre(price,hi);pb=pr[0];gap=pr[1];}
  double mean20=meanPrice(h,20),dist20=mean20>0?(price/mean20-1)*100:0,burst=burstRatio(h,r1);int stale=staleHigh(h,price);
  double vs=clamp(50+vz*17),os=clamp(50+oz*16),qs=quiet(r3,r10),fs=funding(fund),bs=clamp(50+btc*4);double raw=vs*.28+os*.24+comp*.16+pb*.15+qs*.08+fs*.05+bs*.04;
  double chase=0;if(r1>1.0)chase+=Math.min(12,(r1-1.0)*8);if(r3>1.8)chase+=Math.min(14,(r3-1.8)*6);if(r5>2.8)chase+=Math.min(12,(r5-2.8)*3.5);if(r10>4.0)chase+=Math.min(12,(r10-4.0)*2.5);if(gap<-.25)chase+=Math.min(8,Math.abs(gap+.25)*5+2);chase=Math.max(0,Math.min(38,chase));
  double late=0;if(r30>5)late+=Math.min(12,(r30-5)*1.2);if(r60>8)late+=Math.min(14,(r60-8)*.9);if(dist20>2.0)late+=Math.min(10,(dist20-2.0)*2.2);if(burst>=4&&r1>.8)late+=Math.min(8,(burst-4)*1.5+2);if(change24>=12&&pb>=82&&comp>=65&&Math.abs(r10)<=1.8&&stale>=12)late+=Math.min(18,8+(change24-12)*.65);late=Math.max(0,Math.min(42,late));
  double maturity=Math.min(1,h.size()/12.0),preLate=clamp(50+(raw-50)*(.42+.58*maturity)-chase),score=clamp(preLate-late);String lf=lateFlag(r1,r3,r5,r10,r30,r60,change24,pb,comp,stale,dist20,late);boolean lateBlocked=!lf.isEmpty();
  int leads=0;if(vz>=1.15)leads++;if(oz>=.90)leads++;if(comp>=70)leads++;if(pb>=65)leads++;if(qs>=75)leads++;int complete=(qv>0?1:0)+1+(oi>0?1:0)+(h.size()>=6?1:0);
  Result r=new Result();r.score=Math.round(score*10)/10.0;r.preLateScore=Math.round(preLate*10)/10.0;r.confidence=Math.round(clamp(35+65*(complete/4.0))*10)/10.0;r.vz=vz;r.oz=oz;r.ret1=r1;r.ret3=r3;r.ret5=r5;r.ret10=r10;r.ret20=r20;r.ret30=r30;r.ret60=r60;r.compression=comp;r.prebreakout=pb;r.gap=gap;r.chase=chase;r.dist20=dist20;r.burst=burst;r.staleHighMin=stale;r.latePenalty=Math.round(late*10)/10.0;r.lateFlag=lf;r.lateBlocked=lateBlocked;r.leadCount=leads;return r;
 }
 public static String stage(double s){return s>=88?"PRIME":s>=84?"HOT":s>=78?"ALERT":s>=72?"EARLY WATCH":"QUIET";}
 public static String lateLabel(String f){if("FAST_SPIKE".equals(f))return "단기 급등 진행";if("EXTENDED_MOVE".equals(f))return "30~60분 과확장";if("STALE_HIGH".equals(f))return "급등 후 고점 체류";if("MEAN_STRETCH".equals(f))return "단기 평균 과이격";if("OVEREXTENDED".equals(f))return "과열/추격 위험";return "";}
}
