# PulseForge X Mobile V6.0

PulseForge X Android build focused on the original project goal: detect pre-move conditions, not merely coins that have already surged.

## V6.0 highlights
- New signal model `early_v60` with stronger anti-late / anti-chase logic.
- Added 1m/5m/30m/60m momentum, 20m mean distance, 1m burst ratio, and high-zone dwell time.
- Late-risk classifications: `FAST_SPIKE`, `EXTENDED_MOVE`, `STALE_HIGH`, `MEAN_STRETCH`, `OVEREXTENDED`.
- Late candidates are removed from TOP SIGNALS and cannot trigger push alerts.
- Late candidates that would otherwise have qualified are stored as suppressed records (up to once per symbol per 15 minutes) and are post-scored so the filter itself can later be evaluated.
- Alert History adds `후행차단` filter. Normal `전체/단계` filters keep showing only non-suppressed signals.
- Alert History filter selection is now persisted in `ui_state`, so leaving/reopening the screen restores the last selected filter.
- Post-score outcomes now record first-hit lead time to +3% / +5% / +8%, shown in symbol detail once available.
- Symbol detail shows expanded 1/3/5/10/20/30/60m momentum and late-risk diagnostics.
- Binance Futures direct-open second attempt uses the official Binance Futures `_dp` path format before falling back to Binance app launch + clipboard symbol copy.
- Existing Binance API / Android Keystore / leverage filter / max-leverage cache / multi-timeframe chart / notification settings remain intact.
- Existing V5.9 database, API credentials and app settings are preserved by the in-place DB v3 -> v4 migration and unchanged package ID.

## Security
- Do not put Binance API credentials in source code, GitHub, ZIP files, screenshots, or chat.
- Credentials are entered only on the device and encrypted with Android Keystore.
- The authenticated code path is for `GET /fapi/v1/leverageBracket` only; no order-placement endpoint is implemented.

## Notes
- `early_v60` intentionally starts its similar-pattern correction sample set separately from older signal models. Historical alerts/outcomes remain stored, but V6 statistical score correction begins after at least five comparable V6 samples.
- Stronger anti-late filtering is a heuristic improvement, not a guarantee of future price movement. Keep collecting outcomes and compare blocked vs accepted signals before tightening thresholds further.
