# PulseForge X Mobile V10.5 — Linear Chart Auto Fallback Restore

V10.4의 알림번호 정렬/FALLBACK 상태 표시와 V10.3의 specialUse FGS 안정화를 그대로 유지하면서, PRIMARY 수신전용 구간에서 로컬 `scans`가 부족해 일부 과거 알림의 선형 그래프가 비는 현상을 보완합니다.

- 로컬 PulseForge 60초 스캔을 최우선 사용
- 부족하면 Binance Futures 1분 종가로 선형 그래프 자동 보완
- 급등/급락 알림 위치 마커도 가장 가까운 1분봉에 표시
- 보완 데이터는 차트 표시 전용이며 로컬 `scans` DB에는 저장하지 않음
- 기존 GitHub Actions `Build Android APK` 워크플로 사용

---

# PulseForge X Mobile V9.1 — Core Bridge + Mobile FALLBACK

V9.0의 알림이력 SQL 숫자비교 수정과 기존 급등/급락/차트/실매매 UX를 유지하면서, 보조PC Core와 동일한 canonical alert number / event UUID 체계를 추가합니다.

## V9.1 핵심
- Core: `http://100.74.6.90:8765` (Tailscale)
- Device ID: `mobile-a56`
- 기존 실사용 lease `#115995 ~ #116994` 재사용
- 서버 온라인: 신호를 `/events/create`로 등록하고 Core가 부여한 `alert_no` + `event_uuid` 저장
- 서버 오프라인: 저장된 lease 번호 + UUID로 FALLBACK 큐 생성
- 서버 복귀: `/ingest/fallback` 자동 동기화
- 푸시/알림이력에 `알림 #xxxxxx` 표시
- 시스템 상태에 SERVER / WAITING / FALLBACK, lease, 대기 큐 표시
- DB v16: 기존 데이터는 삭제/초기화하지 않고 컬럼/큐 테이블만 추가

## 설치 전
보조PC의 Core를 `Core V2.2 Trusted Mobile`로 먼저 올린 뒤 V9.1을 설치/실행하세요.

## 빌드
기존 GitHub Actions `Build Android APK` 워크플로를 그대로 사용합니다.
