# PulseForge X Mobile V10.8 — FALLBACK History Order Hotfix

V10.7의 뉴스 품질 기능과 기존 PRIMARY/FALLBACK 구조를 보존하면서, 알림 이력 정렬을 발생시간 우선으로 수정합니다.

- 최신 이벤트는 alert_no 크기와 무관하게 위에 표시
- 같은 timestamp에서는 alert_no DESC
- alert_no가 0인 FALLBACK 이벤트도 시간순으로 정상 표시
