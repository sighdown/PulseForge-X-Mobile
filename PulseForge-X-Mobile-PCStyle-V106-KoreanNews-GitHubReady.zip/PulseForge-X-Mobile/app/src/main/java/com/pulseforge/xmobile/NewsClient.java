package com.pulseforge.xmobile;

import android.util.Xml;
import org.xmlpull.v1.XmlPullParser;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class NewsClient {
 public static class Item { public String title,url,source; public long ts; Item(String t,String u,String s,long x){title=t;url=u;source=s;ts=x;} }
 static class Cache { long at; ArrayList<Item> items; Cache(long a,ArrayList<Item> i){at=a;items=i;} }
 static final long CACHE_MS=15*60*1000L, MAX_AGE_MS=72*60*60*1000L;
 static final ConcurrentHashMap<String,Cache> cache=new ConcurrentHashMap<>();
 static final HashMap<String,String> KO=new HashMap<>();
 static { String[][] x={{"BTC","비트코인"},{"ETH","이더리움"},{"XRP","리플"},{"SOL","솔라나"},{"DOGE","도지코인"},{"ADA","에이다"},{"BNB","바이낸스코인"},{"AVAX","아발란체"},{"LINK","체인링크"},{"DOT","폴카닷"},{"TRX","트론"},{"SUI","수이"},{"APT","앱토스"},{"OP","옵티미즘"},{"ARB","아비트럼"},{"WLD","월드코인"},{"UNI","유니스왑"},{"AAVE","에이브"},{"BCH","비트코인캐시"},{"LTC","라이트코인"},{"ETC","이더리움클래식"},{"NEAR","니어프로토콜"},{"ATOM","코스모스"},{"FIL","파일코인"},{"INJ","인젝티브"},{"SEI","세이"},{"TON","톤코인"},{"XLM","스텔라루멘"},{"HBAR","헤데라"},{"SHIB","시바이누"},{"PEPE","페페"},{"ENA","에테나"},{"ONDO","온도"},{"DYDX","디와이디엑스"},{"TAO","비텐서"},{"FET","페치에이아이"},{"RENDER","렌더"},{"POL","폴리곤"},{"MATIC","폴리곤"},{"ICP","인터넷컴퓨터"},{"EOS","이오스"},{"GALA","갈라"},{"SAND","샌드박스"},{"MANA","디센트럴랜드"},{"APE","에이프코인"},{"JUP","주피터"},{"JTO","지토"},{"PYTH","피스네트워크"},{"PENDLE","펜들"}}; for(String[] a:x)KO.put(a[0],a[1]); }
 public static String base(String symbol){String s=(symbol==null?"":symbol.trim().toUpperCase(Locale.US));for(String q:new String[]{"USDT","USDC","BUSD","FDUSD"})if(s.endsWith(q)){s=s.substring(0,s.length()-q.length());break;}s=s.replaceFirst("^1000(?=[A-Z])","");return s;}
 public static String query(String symbol){String b=base(symbol),a=KO.get(b);return ((a==null?"":a+" ")+b+" 코인 암호화폐 when:3d").trim();}
 public static String searchUrl(String symbol)throws Exception{return "https://news.google.com/search?q="+URLEncoder.encode(query(symbol),"UTF-8")+"&hl=ko&gl=KR&ceid=KR%3Ako";}
 static boolean hangul(String s){if(s==null)return false;for(int i=0;i<s.length();i++){char c=s.charAt(i);if(c>='가'&&c<='힣')return true;}return false;}
 static String clean(String s){return s==null?"":s.replaceAll("\\s+"," ").trim();}
 static long parseDate(String s){try{return new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss z",Locale.US).parse(s).getTime();}catch(Exception e){return 0;}}
 public static ArrayList<Item> fetch(String symbol,int limit,boolean force)throws Exception{
  String key=base(symbol);long now=System.currentTimeMillis();Cache c=cache.get(key);if(!force&&c!=null&&now-c.at<=CACHE_MS)return new ArrayList<>(c.items.subList(0,Math.min(limit,c.items.size())));
  String u="https://news.google.com/rss/search?q="+URLEncoder.encode(query(symbol),"UTF-8")+"&hl=ko&gl=KR&ceid=KR%3Ako";
  HttpURLConnection h=(HttpURLConnection)new URL(u).openConnection();h.setConnectTimeout(6000);h.setReadTimeout(7000);h.setRequestProperty("User-Agent","Mozilla/5.0 PulseForgeX-Mobile/10.6");h.setRequestProperty("Accept-Language","ko-KR,ko;q=0.9");
  ArrayList<Item> out=new ArrayList<>();HashSet<String> seen=new HashSet<>();
  try(InputStream in=h.getInputStream()){
   XmlPullParser p=Xml.newPullParser();p.setInput(in,"UTF-8");boolean inItem=false;String tag="",title="",link="",source="",pub="";
   for(int ev=p.getEventType();ev!=XmlPullParser.END_DOCUMENT;ev=p.next()){
    if(ev==XmlPullParser.START_TAG){tag=p.getName();if("item".equals(tag)){inItem=true;title=link=source=pub="";}}
    else if(ev==XmlPullParser.TEXT&&inItem){String t=p.getText();if("title".equals(tag))title+=t;else if("link".equals(tag))link+=t;else if("source".equals(tag))source+=t;else if("pubDate".equals(tag))pub+=t;}
    else if(ev==XmlPullParser.END_TAG){String n=p.getName();if("item".equals(n)){inItem=false;title=clean(title);link=clean(link);source=clean(source);if(!source.isEmpty()&&title.endsWith(" - "+source))title=title.substring(0,title.length()-source.length()-3).trim();long ts=parseDate(clean(pub));if(hangul(title)&&!link.isEmpty()&&(ts==0||now-ts<=MAX_AGE_MS)){String norm=title.replaceAll("\\s+","").toLowerCase(Locale.US);if(seen.add(norm)){out.add(new Item(title,link,source.isEmpty()?"Google 뉴스":source,ts));if(out.size()>=limit)break;}}}tag="";}
   }
  } finally {h.disconnect();}
  cache.put(key,new Cache(now,new ArrayList<>(out)));return out;
 }
}
