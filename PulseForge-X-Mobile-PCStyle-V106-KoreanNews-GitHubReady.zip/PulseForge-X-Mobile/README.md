# PulseForge X Mobile V10.6 — Korean News

V10.5 기반. 종목 상세 화면에 최근 72시간 한국어 관련뉴스 섹션을 추가합니다.
뉴스 조회는 UI 표시용이며 PulseForge 엔진/DB/알림판정에는 영향을 주지 않습니다.
