package com.pulseforge.xmobile;

import android.app.*;import android.os.*;import android.widget.*;
import org.json.*;import java.util.*;import java.util.concurrent.*;

public class ChartFullscreenActivity extends Activity {
 private String symbol="",interval="5m",label="5분봉"; private long alertTs=0;
 private CandleChartView chart; private TextView title,status; private ExecutorService net=Executors.newSingleThreadExecutor();
 private volatile boolean loadingOlder=false;

 public void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_chart_fullscreen);
  symbol=getIntent().getStringExtra("symbol");if(symbol==null)symbol="";
  interval=getIntent().getStringExtra("interval");if(interval==null||interval.isEmpty())interval="5m";
  label=getIntent().getStringExtra("label");if(label==null||label.isEmpty())label=interval;
  alertTs=getIntent().getLongExtra("alert_ts",0);
  chart=findViewById(R.id.fullChart);title=findViewById(R.id.fullTitle);status=findViewById(R.id.fullStatus);
  title.setText(symbol+" · "+label);chart.setOnNeedOlderListener(oldest->loadOlder(oldest));
  findViewById(R.id.fullBack).setOnClickListener(v->finish());
  findViewById(R.id.chartHome).setOnClickListener(v->chart.resetZoom());
  findViewById(R.id.chartMinus).setOnClickListener(v->chart.zoomOut());
  findViewById(R.id.chartPlus).setOnClickListener(v->chart.zoomIn());
  load();
 }
 private long dur(){
  if("1m".equals(interval))return 60000L;if("3m".equals(interval))return 180000L;if("5m".equals(interval))return 300000L;
  if("15m".equals(interval))return 900000L;if("30m".equals(interval))return 1800000L;if("1h".equals(interval))return 3600000L;
  if("2h".equals(interval))return 7200000L;if("4h".equals(interval))return 14400000L;if("6h".equals(interval))return 21600000L;
  if("8h".equals(interval))return 28800000L;if("12h".equals(interval))return 43200000L;if("1d".equals(interval))return 86400000L;
  if("1w".equals(interval))return 604800000L;return 2592000000L;
 }
 void load(){status.setText("Binance 차트 불러오는 중…");net.submit(()->{try{
   Long start=null,end=null;long d=dur();if(alertTs>0){long center=alertTs*1000L;start=Math.max(0,center-360*d);end=Math.min(System.currentTimeMillis(),center+140*d);}
   JSONArray a=BinanceClient.klines(symbol,interval,500,start,end);ArrayList<CandleChartView.Candle> cs=new ArrayList<>();
   for(int i=0;i<a.length();i++){JSONArray k=a.getJSONArray(i);cs.add(new CandleChartView.Candle(k.getLong(0),num(k,1),num(k,2),num(k,3),num(k,4)));}
   runOnUiThread(()->{chart.setData(cs);chart.setMarker(alertTs*1000L,alertTs>0);status.setText("핀치/드래그 · 왼쪽 끝에서 더 과거로 이동하면 자동 추가 로드 · ‘처음으로’ 초기화");});
  }catch(Exception e){runOnUiThread(()->status.setText("차트 불러오기 실패 · 뒤로 갔다 다시 시도"));}});}
 
 void loadOlder(long oldestMs){
  if(loadingOlder){chart.olderLoadFinished();return;}loadingOlder=true;status.setText("과거 캔들 추가 로딩 중…");
  final long d=dur();net.submit(()->{try{
   long end=Math.max(0,oldestMs-1),start=Math.max(0,end-500L*d);
   JSONArray a=BinanceClient.klines(symbol,interval,500,start,end);ArrayList<CandleChartView.Candle> cs=new ArrayList<>();
   for(int i=0;i<a.length();i++){JSONArray k=a.getJSONArray(i);cs.add(new CandleChartView.Candle(k.getLong(0),num(k,1),num(k,2),num(k,3),num(k,4)));}
   runOnUiThread(()->{loadingOlder=false;int added=chart.prependData(cs);status.setText(added>0?"과거 "+added+"개 추가 · 계속 드래그하면 더 불러옴":"더 이전 캔들이 없습니다");});
  }catch(Exception e){runOnUiThread(()->{loadingOlder=false;chart.olderLoadFinished();status.setText("과거 데이터 로딩 실패 · 다시 드래그하면 재시도");});}});
 }
 double num(JSONArray a,int i)throws Exception{return Double.parseDouble(a.getString(i));}
 protected void onDestroy(){net.shutdownNow();super.onDestroy();}
}