package com.pulseforge.xmobile;

import android.content.*;
import android.util.*;
import android.graphics.*;
import android.view.*;
import java.text.*;
import java.util.*;

public class CandleChartView extends View {
 public static class Candle {
  public long openTime; public double open,high,low,close;
  public Candle(long t,double o,double h,double l,double c){openTime=t;open=o;high=h;low=l;close=c;}
 }

 private List<Candle> d=new ArrayList<>();
 private long markerTs=0; private boolean showMarker=true;
 private final Paint grid=new Paint(1),up=new Paint(1),down=new Paint(1),wick=new Paint(1),marker=new Paint(1),text=new Paint(1),axisBg=new Paint(1);
 private ScaleGestureDetector scaleDetector;
 private GestureDetector gestureDetector;
 private float visibleCount=72f, startIndex=0f, lastX=0f;
 private boolean dragging=false;
 private boolean olderRequested=false;
 public interface OnNeedOlderListener{void onNeedOlder(long oldestOpenTime);}
 private OnNeedOlderListener olderListener;
 private static final float MIN_VISIBLE=12f;
 private static final float AXIS_R=78f, AXIS_B=34f, PAD=10f;

 public CandleChartView(Context c,AttributeSet a){
  super(c,a);
  grid.setColor(Color.rgb(38,52,72)); grid.setStrokeWidth(1);
  up.setColor(Color.rgb(53,208,127)); down.setColor(Color.rgb(255,93,115));
  wick.setStrokeWidth(2);
  marker.setColor(Color.rgb(255,93,115)); marker.setStrokeWidth(3);
  text.setColor(Color.rgb(152,162,179)); text.setTextSize(22);
  axisBg.setColor(Color.rgb(17,29,46));
  setFocusable(true); setClickable(true);

  scaleDetector=new ScaleGestureDetector(c,new ScaleGestureDetector.SimpleOnScaleGestureListener(){
   public boolean onScale(ScaleGestureDetector detector){
    if(d.isEmpty()) return false;
    float factor=detector.getScaleFactor();
    if(factor<=0) return false;
    zoomAt(factor, detector.getFocusX());
    return true;
   }
  });
  gestureDetector=new GestureDetector(c,new GestureDetector.SimpleOnGestureListener(){
   public boolean onDoubleTap(MotionEvent e){ resetZoom(); return true; }
  });
 }

 public void setData(List<Candle>x){d=x==null?new ArrayList<>():x;olderRequested=false;resetZoom();}
 public void setOnNeedOlderListener(OnNeedOlderListener l){olderListener=l;}
 public void olderLoadFinished(){olderRequested=false;}
 public int prependData(List<Candle>x){
  if(x==null||x.isEmpty()){olderRequested=false;return 0;}
  long first=d.isEmpty()?Long.MAX_VALUE:d.get(0).openTime;
  ArrayList<Candle> add=new ArrayList<>();
  for(Candle c:x)if(c.openTime<first)add.add(c);
  if(add.isEmpty()){olderRequested=false;return 0;}
  d.addAll(0,add);startIndex+=add.size();olderRequested=false;invalidate();return add.size();
 }
 public void setMarker(long ts,boolean show){markerTs=ts;showMarker=show;invalidate();}
 public void resetZoom(){visibleCount=Math.max(MIN_VISIBLE,d.size());startIndex=0f;invalidate();}
 public void zoomIn(){zoomAt(1.35f,getWidth()/2f);}
 public void zoomOut(){zoomAt(1f/1.35f,getWidth()/2f);}

 private void zoomAt(float factor,float focusX){
  if(d.isEmpty())return;
  float before=visibleCount;
  float after=before/factor;
  float max=Math.max(MIN_VISIBLE,d.size());
  after=Math.max(MIN_VISIBLE,Math.min(max,after));
  float plotW=Math.max(1,getWidth()-AXIS_R);
  float ratio=Math.max(0,Math.min(1,focusX/plotW));
  float focusIndex=startIndex+ratio*before;
  visibleCount=after;
  startIndex=focusIndex-ratio*after;
  clampWindow(); invalidate();
 }

 @Override public boolean onTouchEvent(MotionEvent e){
  gestureDetector.onTouchEvent(e); scaleDetector.onTouchEvent(e);
  switch(e.getActionMasked()){
   case MotionEvent.ACTION_DOWN:
    lastX=e.getX(); dragging=true; getParent().requestDisallowInterceptTouchEvent(true); return true;
   case MotionEvent.ACTION_MOVE:
    if(!scaleDetector.isInProgress()&&dragging&&!d.isEmpty()){
     float dx=e.getX()-lastX; lastX=e.getX();
     float plotW=Math.max(1,getWidth()-AXIS_R);
     startIndex-=dx*(visibleCount/plotW); clampWindow(); invalidate();
     if(dx>0 && startIndex<=0.25f && olderListener!=null && !olderRequested){
      olderRequested=true; olderListener.onNeedOlder(d.get(0).openTime);
     }
    }
    return true;
   case MotionEvent.ACTION_POINTER_DOWN: dragging=false; return true;
   case MotionEvent.ACTION_POINTER_UP: lastX=e.getX(); return true;
   case MotionEvent.ACTION_UP:
   case MotionEvent.ACTION_CANCEL:
    dragging=false; getParent().requestDisallowInterceptTouchEvent(false); return true;
  }
  return true;
 }

 private void clampWindow(){
  if(d.isEmpty()){startIndex=0;return;}
  visibleCount=Math.max(MIN_VISIBLE,Math.min(Math.max(MIN_VISIBLE,d.size()),visibleCount));
  float maxStart=Math.max(0,d.size()-visibleCount);
  startIndex=Math.max(0,Math.min(maxStart,startIndex));
 }

 @Override protected void onDraw(Canvas c){
  super.onDraw(c);
  float w=getWidth(),h=getHeight(), plotW=Math.max(1,w-AXIS_R), plotH=Math.max(1,h-AXIS_B);
  c.drawRect(plotW,0,w,h,axisBg); c.drawRect(0,plotH,w,h,axisBg);
  if(d.isEmpty()){c.drawText("캔들 데이터 없음",18,h/2,text);return;}

  clampWindow();
  int from=Math.max(0,(int)Math.floor(startIndex));
  int to=Math.min(d.size(),(int)Math.ceil(startIndex+visibleCount));
  if(to<=from){from=0;to=d.size();}

  double mn=Double.MAX_VALUE,mx=-Double.MAX_VALUE;
  for(int i=from;i<to;i++){Candle x=d.get(i);mn=Math.min(mn,x.low);mx=Math.max(mx,x.high);}
  if(mx<=mn)mx=mn+1;
  double margin=(mx-mn)*0.04; mn-=margin; mx+=margin;

  for(int i=1;i<5;i++){
   float yy=plotH*i/5f; c.drawLine(0,yy,plotW,yy,grid);
   double pv=mx-(mx-mn)*(yy/plotH);
   c.drawText(price(pv),plotW+5,yy-4,text);
  }

  float step=plotW/Math.max(1,visibleCount), body=Math.max(2f,Math.min(14f,step*.64f));
  int markerIndex=-1;
  if(markerTs>0){long best=Long.MAX_VALUE;for(int i=0;i<d.size();i++){long dist=Math.abs(d.get(i).openTime-markerTs);if(dist<best){best=dist;markerIndex=i;}}}

  for(int i=from;i<to;i++){
   Candle x=d.get(i); float cx=((i-startIndex)+.5f)*step;
   float yh=y(x.high,mn,mx,plotH),yl=y(x.low,mn,mx,plotH),yo=y(x.open,mn,mx,plotH),yc=y(x.close,mn,mx,plotH);
   Paint p=x.close>=x.open?up:down; wick.setColor(p.getColor());
   c.drawLine(cx,yh,cx,yl,wick); float top=Math.min(yo,yc),bot=Math.max(yo,yc);if(bot-top<2)bot=top+2;
   c.drawRect(cx-body/2,top,cx+body/2,bot,p);
  }

  if(showMarker&&markerIndex>=from&&markerIndex<to){
   float x=((markerIndex-startIndex)+.5f)*step; Candle m=d.get(markerIndex); float yy=y(m.close,mn,mx,plotH);
   c.drawLine(x,0,x,plotH,marker);c.drawCircle(x,yy,9,marker);
   Paint ring=new Paint(marker);ring.setStyle(Paint.Style.STROKE);ring.setStrokeWidth(3);c.drawCircle(x,yy,15,ring);
  }

  int mid=(from+to-1)/2;
  drawTime(c,d.get(from).openTime,3,plotH+25);
  drawTimeCenter(c,d.get(mid).openTime,plotW/2,plotH+25);
  drawTimeRight(c,d.get(to-1).openTime,plotW-3,plotH+25);
 }

 private void drawTime(Canvas c,long ts,float x,float y){c.drawText(time(ts),x,y,text);}
 private void drawTimeCenter(Canvas c,long ts,float x,float y){String s=time(ts);c.drawText(s,x-text.measureText(s)/2,y,text);}
 private void drawTimeRight(Canvas c,long ts,float x,float y){String s=time(ts);c.drawText(s,x-text.measureText(s),y,text);}
 private String time(long ts){return new SimpleDateFormat("MM/dd HH:mm",Locale.KOREA).format(new Date(ts));}
 private String price(double v){
  if(v>=1000)return String.format(Locale.US,"%.1f",v);
  if(v>=1)return String.format(Locale.US,"%.4f",v);
  if(v>=0.01)return String.format(Locale.US,"%.5f",v);
  return String.format(Locale.US,"%.7f",v);
 }
 private float y(double v,double mn,double mx,float h){return (float)(PAD+(mx-v)/(mx-mn)*(h-PAD*2));}
}