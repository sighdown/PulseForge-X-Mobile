package com.pulseforge.xmobile;

import android.content.*;
import android.util.*;
import android.graphics.*;
import android.view.*;
import java.util.*;

public class CandleChartView extends View {
 public static class Candle {
  public long openTime; public double open,high,low,close;
  public Candle(long t,double o,double h,double l,double c){openTime=t;open=o;high=h;low=l;close=c;}
 }

 private List<Candle> d=new ArrayList<>();
 private long markerTs=0; private boolean showMarker=true;
 private final Paint grid=new Paint(1),up=new Paint(1),down=new Paint(1),wick=new Paint(1),marker=new Paint(1),text=new Paint(1);
 private ScaleGestureDetector scaleDetector;
 private GestureDetector gestureDetector;
 private float visibleCount=72f;
 private float startIndex=0f;
 private float lastX=0f;
 private boolean dragging=false;
 private static final float MIN_VISIBLE=12f;

 public CandleChartView(Context c,AttributeSet a){
  super(c,a);
  grid.setColor(Color.rgb(38,52,72)); grid.setStrokeWidth(1);
  up.setColor(Color.rgb(53,208,127)); down.setColor(Color.rgb(255,93,115));
  wick.setStrokeWidth(2); marker.setColor(Color.rgb(255,93,115)); marker.setStrokeWidth(3);
  text.setColor(Color.rgb(152,162,179)); text.setTextSize(25);
  setFocusable(true); setClickable(true);

  scaleDetector=new ScaleGestureDetector(c,new ScaleGestureDetector.SimpleOnScaleGestureListener(){
   public boolean onScale(ScaleGestureDetector detector){
    if(d.isEmpty()) return false;
    float before=visibleCount;
    float factor=detector.getScaleFactor();
    if(factor<=0) return false;
    float after=before/factor;
    float max=Math.max(MIN_VISIBLE,d.size());
    after=Math.max(MIN_VISIBLE,Math.min(max,after));
    if(Math.abs(after-before)<0.01f) return true;
    float focusRatio=getWidth()>0?detector.getFocusX()/getWidth():0.5f;
    float focusIndex=startIndex+focusRatio*before;
    visibleCount=after;
    startIndex=focusIndex-focusRatio*after;
    clampWindow(); invalidate();
    return true;
   }
  });

  gestureDetector=new GestureDetector(c,new GestureDetector.SimpleOnGestureListener(){
   public boolean onDoubleTap(MotionEvent e){ resetZoom(); return true; }
  });
 }

 public void setData(List<Candle>x){
  d=x==null?new ArrayList<>():x;
  visibleCount=Math.max(MIN_VISIBLE,d.size());
  startIndex=0f;
  invalidate();
 }
 public void setMarker(long ts,boolean show){markerTs=ts;showMarker=show;invalidate();}
 public void resetZoom(){
  visibleCount=Math.max(MIN_VISIBLE,d.size());
  startIndex=0f;
  invalidate();
 }

 @Override public boolean onTouchEvent(MotionEvent e){
  gestureDetector.onTouchEvent(e);
  scaleDetector.onTouchEvent(e);
  switch(e.getActionMasked()){
   case MotionEvent.ACTION_DOWN:
    lastX=e.getX(); dragging=true; getParent().requestDisallowInterceptTouchEvent(true); return true;
   case MotionEvent.ACTION_MOVE:
    if(!scaleDetector.isInProgress() && dragging && !d.isEmpty()){
     float dx=e.getX()-lastX; lastX=e.getX();
     if(getWidth()>0){
      float candlesPerPx=visibleCount/getWidth();
      startIndex-=dx*candlesPerPx;
      clampWindow(); invalidate();
     }
    }
    return true;
   case MotionEvent.ACTION_POINTER_DOWN:
    dragging=false; return true;
   case MotionEvent.ACTION_POINTER_UP:
    lastX=e.getX(); return true;
   case MotionEvent.ACTION_UP:
   case MotionEvent.ACTION_CANCEL:
    dragging=false; getParent().requestDisallowInterceptTouchEvent(false); return true;
  }
  return true;
 }

 private void clampWindow(){
  if(d.isEmpty()){startIndex=0;return;}
  visibleCount=Math.max(MIN_VISIBLE,Math.min(Math.max(MIN_VISIBLE,d.size()),visibleCount));
  float maxStart=Math.max(0,d.size()-visibleCount);
  startIndex=Math.max(0,Math.min(maxStart,startIndex));
 }

 @Override protected void onDraw(Canvas c){
  super.onDraw(c);
  float w=getWidth(),h=getHeight();
  for(int i=1;i<4;i++) c.drawLine(0,h*i/4,w,h*i/4,grid);
  if(d.isEmpty()){c.drawText("캔들 데이터 없음",18,h/2,text);return;}

  clampWindow();
  int from=Math.max(0,(int)Math.floor(startIndex));
  int to=Math.min(d.size(),(int)Math.ceil(startIndex+visibleCount));
  if(to<=from){from=0;to=d.size();}

  double mn=Double.MAX_VALUE,mx=-Double.MAX_VALUE;
  for(int i=from;i<to;i++){Candle x=d.get(i);mn=Math.min(mn,x.low);mx=Math.max(mx,x.high);}
  if(mx<=mn)mx=mn+1;

  float pad=14f, step=w/Math.max(1,visibleCount), body=Math.max(2f,Math.min(12f,step*.62f));
  int markerIndex=-1;
  if(markerTs>0){long best=Long.MAX_VALUE;for(int i=0;i<d.size();i++){long dist=Math.abs(d.get(i).openTime-markerTs);if(dist<best){best=dist;markerIndex=i;}}}

  for(int i=from;i<to;i++){
   Candle x=d.get(i); float cx=((i-startIndex)+.5f)*step;
   float yh=y(x.high,mn,mx,h,pad),yl=y(x.low,mn,mx,h,pad),yo=y(x.open,mn,mx,h,pad),yc=y(x.close,mn,mx,h,pad);
   Paint p=x.close>=x.open?up:down; wick.setColor(p.getColor());
   c.drawLine(cx,yh,cx,yl,wick); float top=Math.min(yo,yc),bot=Math.max(yo,yc); if(bot-top<2)bot=top+2;
   c.drawRect(cx-body/2,top,cx+body/2,bot,p);
  }

  if(showMarker&&markerIndex>=from&&markerIndex<to){
   float x=((markerIndex-startIndex)+.5f)*step; Candle m=d.get(markerIndex); float yy=y(m.close,mn,mx,h,pad);
   c.drawLine(x,0,x,h,marker); c.drawCircle(x,yy,9,marker);
   Paint ring=new Paint(marker); ring.setStyle(Paint.Style.STROKE); ring.setStrokeWidth(3); c.drawCircle(x,yy,15,ring);
  }
 }

 private float y(double v,double mn,double mx,float h,float pad){return (float)(h-pad-(v-mn)/(mx-mn)*(h-pad*2));}
}
