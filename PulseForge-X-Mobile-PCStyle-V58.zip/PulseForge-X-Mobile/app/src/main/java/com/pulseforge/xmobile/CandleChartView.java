package com.pulseforge.xmobile;
import android.content.*;import android.util.*;import android.graphics.*;import android.view.*;import java.util.*;
public class CandleChartView extends View{
 public static class Candle{public long openTime;public double open,high,low,close;public Candle(long t,double o,double h,double l,double c){openTime=t;open=o;high=h;low=l;close=c;}}
 List<Candle>d=new ArrayList<>();long markerTs=0;boolean showMarker=true;Paint grid=new Paint(1),up=new Paint(1),down=new Paint(1),wick=new Paint(1),marker=new Paint(1),text=new Paint(1);
 public CandleChartView(Context c,AttributeSet a){super(c,a);grid.setColor(Color.rgb(38,52,72));grid.setStrokeWidth(1);up.setColor(Color.rgb(53,208,127));down.setColor(Color.rgb(255,93,115));wick.setStrokeWidth(2);marker.setColor(Color.rgb(255,93,115));marker.setStrokeWidth(3);text.setColor(Color.rgb(152,162,179));text.setTextSize(25);}
 public void setData(List<Candle>x){d=x==null?new ArrayList<>():x;invalidate();}public void setMarker(long ts,boolean show){markerTs=ts;showMarker=show;invalidate();}
 protected void onDraw(Canvas c){super.onDraw(c);float w=getWidth(),h=getHeight();for(int i=1;i<4;i++)c.drawLine(0,h*i/4,w,h*i/4,grid);if(d.isEmpty()){c.drawText("캔들 데이터 없음",18,h/2,text);return;}double mn=Double.MAX_VALUE,mx=-Double.MAX_VALUE;for(Candle x:d){mn=Math.min(mn,x.low);mx=Math.max(mx,x.high);}if(mx<=mn)mx=mn+1;float pad=14f,chartH=Math.max(1,h-pad*2),step=w/Math.max(1,d.size()),body=Math.max(2f,Math.min(12f,step*.62f));int markerIndex=-1;if(markerTs>0){long best=Long.MAX_VALUE;for(int i=0;i<d.size();i++){long dist=Math.abs(d.get(i).openTime-markerTs);if(dist<best){best=dist;markerIndex=i;}}}
  for(int i=0;i<d.size();i++){Candle x=d.get(i);float cx=(i+.5f)*step;float yh=y(x.high,mn,mx,h,pad),yl=y(x.low,mn,mx,h,pad),yo=y(x.open,mn,mx,h,pad),yc=y(x.close,mn,mx,h,pad);Paint p=x.close>=x.open?up:down;wick.setColor(p.getColor());c.drawLine(cx,yh,cx,yl,wick);float top=Math.min(yo,yc),bot=Math.max(yo,yc);if(bot-top<2)bot=top+2;c.drawRect(cx-body/2,top,cx+body/2,bot,p);}
  if(showMarker&&markerIndex>=0){float x=(markerIndex+.5f)*step;Candle m=d.get(markerIndex);float y=y(m.close,mn,mx,h,pad);c.drawLine(x,0,x,h,marker);c.drawCircle(x,y,9,marker);Paint ring=new Paint(marker);ring.setStyle(Paint.Style.STROKE);ring.setStrokeWidth(3);c.drawCircle(x,y,15,ring);}
 }
 float y(double v,double mn,double mx,float h,float pad){return (float)(h-pad-(v-mn)/(mx-mn)*(h-pad*2));}
}
