package com.pulseforge.xmobile;

import android.content.*;
import android.database.*;
import android.database.sqlite.*;
import java.io.File;
import java.util.*;

public class PulseDb extends SQLiteOpenHelper {
 public static final int DB_VERSION=2;
 public static final int[] HORIZONS={5,15,30,60,120,240};
 private final Context ctx;
 public PulseDb(Context c){super(c,"pulseforge_mobile.db",null,DB_VERSION);ctx=c.getApplicationContext();}

 public void onCreate(SQLiteDatabase d){createLatest(d);}
 private void createLatest(SQLiteDatabase d){
  d.execSQL("CREATE TABLE IF NOT EXISTS scans(ts INTEGER,symbol TEXT,price REAL,qv REAL,oi REAL,score REAL,confidence REAL DEFAULT 0,vz REAL DEFAULT 0,oz REAL DEFAULT 0,funding REAL DEFAULT 0,change24 REAL DEFAULT 0,ret3 REAL DEFAULT 0,ret10 REAL DEFAULT 0,ret20 REAL DEFAULT 0,compression REAL DEFAULT 0,prebreakout REAL DEFAULT 0,chase REAL DEFAULT 0,lead_count INTEGER DEFAULT 0,PRIMARY KEY(ts,symbol))");
  d.execSQL("CREATE INDEX IF NOT EXISTS ix_scans_symbol_ts ON scans(symbol,ts)");
  d.execSQL("CREATE TABLE IF NOT EXISTS alerts(id INTEGER PRIMARY KEY AUTOINCREMENT,ts INTEGER NOT NULL,symbol TEXT NOT NULL,stage TEXT NOT NULL,score REAL,base_score REAL,price REAL,confidence REAL,vz REAL,oz REAL,ret3 REAL,ret10 REAL,compression REAL,prebreakout REAL,chase REAL,lead_count INTEGER,pattern_samples INTEGER DEFAULT 0,pattern_avg30 REAL,pattern_hit3 REAL,pattern_down3 REAL,model_version TEXT,reason TEXT)");
  d.execSQL("CREATE INDEX IF NOT EXISTS ix_alerts_symbol_ts ON alerts(symbol,ts)");
  d.execSQL("CREATE TABLE IF NOT EXISTS alert_outcomes(alert_id INTEGER NOT NULL,horizon_min INTEGER NOT NULL,evaluated_ts INTEGER NOT NULL,end_price REAL,return_pct REAL,max_up_pct REAL,max_down_pct REAL,hit3 INTEGER,hit5 INTEGER,hit8 INTEGER,hit_minus3 INTEGER,PRIMARY KEY(alert_id,horizon_min))");
  d.execSQL("CREATE INDEX IF NOT EXISTS ix_outcomes_horizon ON alert_outcomes(horizon_min,evaluated_ts)");
  d.execSQL("CREATE TABLE IF NOT EXISTS notification_state(symbol TEXT PRIMARY KEY,last_stage TEXT,last_ts INTEGER,rearmed INTEGER NOT NULL DEFAULT 1)");
 }
 private void safe(SQLiteDatabase d,String sql){try{d.execSQL(sql);}catch(Exception ignored){}}
 public void onUpgrade(SQLiteDatabase d,int oldV,int newV){
  if(oldV<2){
   for(String c:new String[]{
    "confidence REAL DEFAULT 0","vz REAL DEFAULT 0","oz REAL DEFAULT 0","funding REAL DEFAULT 0","change24 REAL DEFAULT 0","ret3 REAL DEFAULT 0","ret10 REAL DEFAULT 0","ret20 REAL DEFAULT 0","compression REAL DEFAULT 0","prebreakout REAL DEFAULT 0","chase REAL DEFAULT 0","lead_count INTEGER DEFAULT 0"}) safe(d,"ALTER TABLE scans ADD COLUMN "+c);
   safe(d,"CREATE INDEX IF NOT EXISTS ix_scans_symbol_ts ON scans(symbol,ts)");
   d.execSQL("CREATE TABLE IF NOT EXISTS alerts_v2(id INTEGER PRIMARY KEY AUTOINCREMENT,ts INTEGER NOT NULL,symbol TEXT NOT NULL,stage TEXT NOT NULL,score REAL,base_score REAL,price REAL,confidence REAL,vz REAL,oz REAL,ret3 REAL,ret10 REAL,compression REAL,prebreakout REAL,chase REAL,lead_count INTEGER,pattern_samples INTEGER DEFAULT 0,pattern_avg30 REAL,pattern_hit3 REAL,pattern_down3 REAL,model_version TEXT,reason TEXT)");
   try{d.execSQL("INSERT INTO alerts_v2(ts,symbol,stage,score,base_score,price) SELECT a.ts,a.symbol,a.stage,a.score,a.score,COALESCE((SELECT s.price FROM scans s WHERE s.symbol=a.symbol AND s.ts<=a.ts ORDER BY s.ts DESC LIMIT 1),0) FROM alerts a");}catch(Exception ignored){}
   safe(d,"DROP TABLE alerts");
   safe(d,"ALTER TABLE alerts_v2 RENAME TO alerts");
   createLatest(d);
  }
 }

 public static class Hist{public double price,qv,oi;public Hist(double p,double q,double o){price=p;qv=q;oi=o;}}
 public List<ScoreEngine.Hist> hist(String s){ArrayList<ScoreEngine.Hist> out=new ArrayList<>();Cursor c=getReadableDatabase().rawQuery("SELECT price,qv,oi FROM scans WHERE symbol=? ORDER BY ts DESC LIMIT 24",new String[]{s});while(c.moveToNext())out.add(0,new ScoreEngine.Hist(c.getDouble(0),c.getDouble(1),c.getDouble(2)));c.close();return out;}

 public void scan(long ts,String s,double p,double q,double oi,ScoreEngine.Result r,double funding,double change24){
  getWritableDatabase().execSQL("INSERT OR REPLACE INTO scans(ts,symbol,price,qv,oi,score,confidence,vz,oz,funding,change24,ret3,ret10,ret20,compression,prebreakout,chase,lead_count) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
   new Object[]{ts,s,p,q,oi,r.score,r.confidence,r.vz,r.oz,funding,change24,r.ret3,r.ret10,r.ret20,r.compression,r.prebreakout,r.chase,r.leadCount});
 }

 public static class Latest{
  public long ts;public double price,qv,oi,score,confidence,vz,oz,funding,change24,ret3,ret10,ret20,compression,prebreakout,chase;public int leadCount;
  Latest(Cursor c){ts=c.getLong(0);price=c.getDouble(1);qv=c.getDouble(2);oi=c.getDouble(3);score=c.getDouble(4);confidence=c.getDouble(5);vz=c.getDouble(6);oz=c.getDouble(7);funding=c.getDouble(8);change24=c.getDouble(9);ret3=c.getDouble(10);ret10=c.getDouble(11);ret20=c.getDouble(12);compression=c.getDouble(13);prebreakout=c.getDouble(14);chase=c.getDouble(15);leadCount=c.getInt(16);}
 }
 public Latest latest(String s){Cursor c=getReadableDatabase().rawQuery("SELECT ts,price,qv,oi,score,confidence,vz,oz,funding,change24,ret3,ret10,ret20,compression,prebreakout,chase,lead_count FROM scans WHERE symbol=? ORDER BY ts DESC LIMIT 1",new String[]{s});Latest x=c.moveToFirst()?new Latest(c):null;c.close();return x;}

 public static class Point{public long ts;public double price;Point(long t,double p){ts=t;price=p;}}
 public List<Point> points(String s,long alertTs){ArrayList<Point> out=new ArrayList<>();SQLiteDatabase d=getReadableDatabase();Cursor c;if(alertTs>0){long a=Math.max(0,alertTs-45*60),b=alertTs+90*60;c=d.rawQuery("SELECT ts,price FROM scans WHERE symbol=? AND ts BETWEEN ? AND ? ORDER BY ts ASC LIMIT 180",new String[]{s,String.valueOf(a),String.valueOf(b)});}else c=d.rawQuery("SELECT ts,price FROM scans WHERE symbol=? ORDER BY ts DESC LIMIT 120",new String[]{s});if(alertTs>0){while(c.moveToNext())out.add(new Point(c.getLong(0),c.getDouble(1)));}else{while(c.moveToNext())out.add(0,new Point(c.getLong(0),c.getDouble(1)));}c.close();return out;}

 public static class PatternStats{public int samples;public Double avg,hit3,down3;public double bonus;}
 public PatternStats patternStats(double score,double vz,double oz,double ret3,double compression){PatternStats p=new PatternStats();ArrayList<Double> rets=new ArrayList<>();int hit=0,down=0;Cursor c=getReadableDatabase().rawQuery(
  "SELECT o.return_pct,o.hit3,o.hit_minus3 FROM alerts a JOIN alert_outcomes o ON o.alert_id=a.id WHERE o.horizon_min=30 AND COALESCE(a.model_version,'')='early_v53' AND a.confidence IS NOT NULL AND a.vz IS NOT NULL AND a.oz IS NOT NULL AND a.compression IS NOT NULL AND ABS(COALESCE(a.base_score,0)-?)<=9 AND ABS(COALESCE(a.vz,0)-?)<=1.6 AND ABS(COALESCE(a.oz,0)-?)<=1.6 AND ABS(COALESCE(a.ret3,0)-?)<=1.5 AND ABS(COALESCE(a.compression,50)-?)<=25 ORDER BY a.ts DESC LIMIT 300",
  new String[]{String.valueOf(score),String.valueOf(vz),String.valueOf(oz),String.valueOf(ret3),String.valueOf(compression)});
  while(c.moveToNext()){rets.add(c.getDouble(0));hit+=c.getInt(1);down+=c.getInt(2);}c.close();p.samples=rets.size();if(p.samples>=5){double sum=0;for(double x:rets)sum+=x;p.avg=sum/p.samples;p.hit3=hit*100.0/p.samples;p.down3=down*100.0/p.samples;p.bonus=clamp((p.hit3-p.down3)*0.05+p.avg*0.55,-3,3);}return p;}

 public long lastAlertTs(String s){Cursor c=getReadableDatabase().rawQuery("SELECT MAX(ts) FROM alerts WHERE symbol=?",new String[]{s});long v=c.moveToFirst()?c.getLong(0):0;c.close();return v;}
 public long alert(long ts,String s,String stage,double finalScore,double baseScore,double price,ScoreEngine.Result r,PatternStats p,String reason){ContentValues v=new ContentValues();v.put("ts",ts);v.put("symbol",s);v.put("stage",stage);v.put("score",finalScore);v.put("base_score",baseScore);v.put("price",price);v.put("confidence",r.confidence);v.put("vz",r.vz);v.put("oz",r.oz);v.put("ret3",r.ret3);v.put("ret10",r.ret10);v.put("compression",r.compression);v.put("prebreakout",r.prebreakout);v.put("chase",r.chase);v.put("lead_count",r.leadCount);v.put("pattern_samples",p.samples);if(p.avg!=null)v.put("pattern_avg30",p.avg);if(p.hit3!=null)v.put("pattern_hit3",p.hit3);if(p.down3!=null)v.put("pattern_down3",p.down3);v.put("model_version","early_v53");v.put("reason",reason);return getWritableDatabase().insert("alerts",null,v);}

 public static class AlertRow{
  public long id,ts;public String symbol,stage,reason;public double score,baseScore,price,confidence,vz,oz,ret3,ret10,compression,prebreakout,chase;public int leadCount,patternSamples;public Double patternAvg30,patternHit3,patternDown3;
  AlertRow(Cursor c){id=c.getLong(0);ts=c.getLong(1);symbol=c.getString(2);stage=c.getString(3);score=c.getDouble(4);baseScore=c.getDouble(5);price=c.getDouble(6);confidence=c.getDouble(7);vz=c.getDouble(8);oz=c.getDouble(9);ret3=c.getDouble(10);ret10=c.getDouble(11);compression=c.getDouble(12);prebreakout=c.getDouble(13);chase=c.getDouble(14);leadCount=c.getInt(15);patternSamples=c.getInt(16);patternAvg30=c.isNull(17)?null:c.getDouble(17);patternHit3=c.isNull(18)?null:c.getDouble(18);patternDown3=c.isNull(19)?null:c.getDouble(19);reason=c.getString(20);}
 }
 private String alertSelect(){return "SELECT id,ts,symbol,stage,score,COALESCE(base_score,score),COALESCE(price,0),COALESCE(confidence,0),COALESCE(vz,0),COALESCE(oz,0),COALESCE(ret3,0),COALESCE(ret10,0),COALESCE(compression,0),COALESCE(prebreakout,0),COALESCE(chase,0),COALESCE(lead_count,0),COALESCE(pattern_samples,0),pattern_avg30,pattern_hit3,pattern_down3,COALESCE(reason,'') FROM alerts";}
 public List<AlertRow> alerts(int limit,String stage){ArrayList<AlertRow> out=new ArrayList<>();String sql=alertSelect();ArrayList<String> a=new ArrayList<>();if(stage!=null&&!stage.equals("전체")){sql+=" WHERE stage=?";a.add(stage);}sql+=" ORDER BY ts DESC LIMIT "+Math.max(1,limit);Cursor c=getReadableDatabase().rawQuery(sql,a.toArray(new String[0]));while(c.moveToNext())out.add(new AlertRow(c));c.close();return out;}
 public AlertRow alertById(long id){Cursor c=getReadableDatabase().rawQuery(alertSelect()+" WHERE id=? LIMIT 1",new String[]{String.valueOf(id)});AlertRow r=c.moveToFirst()?new AlertRow(c):null;c.close();return r;}
 public AlertRow alertByTs(String symbol,long ts){Cursor c=getReadableDatabase().rawQuery(alertSelect()+" WHERE symbol=? ORDER BY ABS(ts-?) ASC LIMIT 1",new String[]{symbol,String.valueOf(ts)});AlertRow r=c.moveToFirst()?new AlertRow(c):null;c.close();return r;}

 public static class Outcome{public int horizon;public long evaluatedTs;public double endPrice,ret,maxUp,maxDown;public boolean hit3,hit5,hit8,hitMinus3;Outcome(Cursor c){horizon=c.getInt(0);evaluatedTs=c.getLong(1);endPrice=c.getDouble(2);ret=c.getDouble(3);maxUp=c.getDouble(4);maxDown=c.getDouble(5);hit3=c.getInt(6)!=0;hit5=c.getInt(7)!=0;hit8=c.getInt(8)!=0;hitMinus3=c.getInt(9)!=0;}}
 public Map<Integer,Outcome> outcomes(long alertId){HashMap<Integer,Outcome> m=new HashMap<>();Cursor c=getReadableDatabase().rawQuery("SELECT horizon_min,evaluated_ts,end_price,return_pct,max_up_pct,max_down_pct,hit3,hit5,hit8,hit_minus3 FROM alert_outcomes WHERE alert_id=?",new String[]{String.valueOf(alertId)});while(c.moveToNext()){Outcome o=new Outcome(c);m.put(o.horizon,o);}c.close();return m;}

 public int evaluatePendingAlerts(long nowS){int done=0;SQLiteDatabase d=getWritableDatabase();Cursor a=d.rawQuery("SELECT id,ts,symbol,price FROM alerts WHERE ts>=? ORDER BY ts DESC LIMIT 500",new String[]{String.valueOf(nowS-14L*24*3600)});ArrayList<Object[]> alerts=new ArrayList<>();while(a.moveToNext())alerts.add(new Object[]{a.getLong(0),a.getLong(1),a.getString(2),a.getDouble(3)});a.close();for(Object[] ar:alerts){long id=(Long)ar[0],ats=(Long)ar[1];String sym=(String)ar[2];double entry=(Double)ar[3];if(entry<=0)continue;for(int h:HORIZONS){long target=ats+h*60L;if(nowS<target)continue;Cursor e=d.rawQuery("SELECT 1 FROM alert_outcomes WHERE alert_id=? AND horizon_min=?",new String[]{String.valueOf(id),String.valueOf(h)});boolean exists=e.moveToFirst();e.close();if(exists)continue;Cursor end=d.rawQuery("SELECT price FROM scans WHERE symbol=? AND ts BETWEEN ? AND ? ORDER BY ABS(ts-?) ASC LIMIT 1",new String[]{sym,String.valueOf(target-180),String.valueOf(target+600),String.valueOf(target)});if(!end.moveToFirst()){end.close();continue;}double endPrice=end.getDouble(0);end.close();Cursor mm=d.rawQuery("SELECT MIN(price),MAX(price) FROM scans WHERE symbol=? AND ts BETWEEN ? AND ?",new String[]{sym,String.valueOf(ats),String.valueOf(target+120)});double low=endPrice,high=endPrice;if(mm.moveToFirst()){if(!mm.isNull(0))low=mm.getDouble(0);if(!mm.isNull(1))high=mm.getDouble(1);}mm.close();double ret=(endPrice/entry-1)*100,up=(high/entry-1)*100,down=(low/entry-1)*100;d.execSQL("INSERT OR IGNORE INTO alert_outcomes(alert_id,horizon_min,evaluated_ts,end_price,return_pct,max_up_pct,max_down_pct,hit3,hit5,hit8,hit_minus3) VALUES(?,?,?,?,?,?,?,?,?,?,?)",new Object[]{id,h,nowS,endPrice,ret,up,down,up>=3?1:0,up>=5?1:0,up>=8?1:0,down<=-3?1:0});done++;}}return done;}

 public static class NotifyState{public String lastStage;public long lastTs;public boolean rearmed;NotifyState(String s,long t,boolean r){lastStage=s;lastTs=t;rearmed=r;}}
 public NotifyState notifyState(String sym){Cursor c=getReadableDatabase().rawQuery("SELECT last_stage,last_ts,rearmed FROM notification_state WHERE symbol=?",new String[]{sym});NotifyState s=c.moveToFirst()?new NotifyState(c.getString(0),c.getLong(1),c.getInt(2)!=0):null;c.close();return s;}
 public void saveNotifyState(String sym,String stage,long ts,boolean rearmed){getWritableDatabase().execSQL("INSERT OR REPLACE INTO notification_state(symbol,last_stage,last_ts,rearmed) VALUES(?,?,?,?)",new Object[]{sym,stage,ts,rearmed?1:0});}

 public static class Stats{public long rows,scans,alerts,outcomes,firstTs,lastTs;public long dbBytes;}
 public Stats stats(){Stats s=new Stats();SQLiteDatabase d=getReadableDatabase();Cursor c=d.rawQuery("SELECT COUNT(*),COUNT(DISTINCT ts),MIN(ts),MAX(ts) FROM scans",null);if(c.moveToFirst()){s.rows=c.getLong(0);s.scans=c.getLong(1);s.firstTs=c.isNull(2)?0:c.getLong(2);s.lastTs=c.isNull(3)?0:c.getLong(3);}c.close();c=d.rawQuery("SELECT COUNT(*) FROM alerts",null);if(c.moveToFirst())s.alerts=c.getLong(0);c.close();c=d.rawQuery("SELECT COUNT(*) FROM alert_outcomes",null);if(c.moveToFirst())s.outcomes=c.getLong(0);c.close();File f=ctx.getDatabasePath("pulseforge_mobile.db");s.dbBytes=f.exists()?f.length():0;return s;}
 public void pruneScans(long beforeTs){getWritableDatabase().delete("scans","ts<?",new String[]{String.valueOf(beforeTs)});}
 private static double clamp(double x,double a,double b){return Math.max(a,Math.min(b,x));}
}
