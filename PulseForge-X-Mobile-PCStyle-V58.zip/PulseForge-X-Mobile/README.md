# PulseForge X Mobile V5.8

Android companion for PulseForge X. Package ID stays `com.pulseforge.xmobile` so the existing signed installation can be updated in place with the same release key.

## V5.8 highlights

- 60-second Binance USDⓈ-M foreground monitoring with 3-attempt public API retry.
- EARLY / ALERT / HOT / PRIME stage colors and configurable notification stages.
- Signal events are recorded even when their visible notification stage is disabled.
- Post-signal scoring at 5 / 15 / 30 / 60 / 120 / 240 minutes.
- Return, MFE (maximum favorable excursion), and MAE (maximum adverse excursion) are accumulated per alert.
- PC-style similar-pattern statistics. Once at least 5 comparable 30-minute outcomes exist, the historical result contributes a bounded ±3 point adjustment to a new eligible signal.
- Persistent per-symbol notification state with cooldown, consecutive confirmations, immediate escalation, optional same-stage repeats, and sound toggle.
- Alert history stage filter and post-signal outcome display.
- Alert-time vs current-state comparison in symbol detail.
- Scan line chart plus 1m / 3m / 5m / 15m / 30m / 1h / 2h / 4h / 6h / 8h / 12h / 1d / 1w / 1M Binance candlestick charts.
- Alert location marker on line/candlestick charts.
- System status screen for collection freshness, uptime, DB counts, outcome counts, and alert settings.
- Binance app launch first; symbol is automatically copied as a fallback because Binance does not publish a stable generic USDⓈ-M symbol deep-link contract.
- Raw scan rows are pruned to the latest 12 hours to protect phone storage; alert/outcome statistics continue accumulating.

## Security / leverage filter

The leverage filter UI remains intentionally disabled. Binance `/fapi/v1/leverageBracket` requires authenticated API access. A later release should store credentials using Android Keystore rather than embedding or committing secrets.

## Build

The included GitHub Actions workflow builds a debug APK, zipaligns it, and signs it with the existing PulseForge signing key stored in GitHub Actions Secrets. Never commit the keystore or Binance API secrets.
