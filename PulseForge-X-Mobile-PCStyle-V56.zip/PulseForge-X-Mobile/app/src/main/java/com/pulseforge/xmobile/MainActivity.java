package com.pulseforge.xmobile;

import android.app.*;import android.os.*;import android.content.*;import android.content.pm.PackageManager;import android.graphics.Color;import android.widget.*;import java.util.*;

public class MainActivity extends Activity{
 TextView status,lastScan,symbolCount,countdown; Button start,stop,settings; ListView candidates; BroadcastReceiver rx; Handler h=new Handler(Looper.getMainLooper()); long nextScanAt=0; ArrayList<String> symbols=new ArrayList<>(); ArrayAdapter<String> adapter;
 Runnable tick=new Runnable(){public void run(){if(ScanService.runningNow&&nextScanAt>0){long left=Math.max(0,(nextScanAt-System.currentTimeMillis()+999)/1000);countdown.setText(left>0?"다음 분석  "+left+"초":"🔄 데이터 수집·분석 중…");}else countdown.setText("다음 분석  -");h.postDelayed(this,500);}};
 public void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_main);
  status=findViewById(R.id.status);candidates=findViewById(R.id.candidates);lastScan=findViewById(R.id.lastScan);symbolCount=findViewById(R.id.symbolCount);countdown=findViewById(R.id.countdown);start=findViewById(R.id.start);stop=findViewById(R.id.stop);settings=findViewById(R.id.settings);
  adapter=new ArrayAdapter<>(this,R.layout.signal_row,R.id.rowText,new ArrayList<>());candidates.setAdapter(adapter);candidates.setOnItemClickListener((p,v,pos,id)->{if(pos<symbols.size())startActivity(new Intent(this,SymbolDetailActivity.class).putExtra("symbol",symbols.get(pos)));});
  start.setOnClickListener(v->start()); stop.setOnClickListener(v->stop()); settings.setOnClickListener(v->startActivity(new Intent(this,SettingsActivity.class)));
  rx=new BroadcastReceiver(){public void onReceive(Context c,Intent i){String s=i.getStringExtra("status");if(s!=null){if(s.startsWith("수집 중")){status.setText("● 수집·분석 중");status.setTextColor(Color.parseColor("#F7C948"));countdown.setText("🔄 데이터 수집·분석 중…");}else if(s.startsWith("정상")){status.setText("● 감시 중");status.setTextColor(Color.parseColor("#35D07F"));nextScanAt=System.currentTimeMillis()+60000;}else if(s.startsWith("수집 오류")){status.setText("● 수집 오류 · 자동 재시도");status.setTextColor(Color.parseColor("#FF5D73"));}}
   String r=i.getStringExtra("rows");String sy=i.getStringExtra("symbols");if(r!=null){adapter.clear();symbols.clear();String[] lines=r.split("\\n");String[] ss=sy==null?new String[0]:sy.split(",");for(int k=0;k<lines.length;k++){if(!lines[k].trim().isEmpty()){adapter.add(lines[k]);if(k<ss.length)symbols.add(ss[k]);}}adapter.notifyDataSetChanged();}String tm=i.getStringExtra("time");if(tm!=null)lastScan.setText("마지막 수집  "+tm);int n=i.getIntExtra("count",-1);if(n>=0)symbolCount.setText("수집 종목  "+n+"개");};};
  if(Build.VERSION.SDK_INT>=33&&checkSelfPermission("android.permission.POST_NOTIFICATIONS")!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"},1);
  if(ScanService.runningNow){showRunning();nextScanAt=System.currentTimeMillis()+60000;}else showIdle();h.post(tick);
 }
 void start(){startForegroundService(new Intent(this,ScanService.class));status.setText("● 수집 준비 중…");status.setTextColor(Color.parseColor("#F7C948"));start.setText("감시 시작됨");start.setEnabled(false);nextScanAt=System.currentTimeMillis();}
 void stop(){stopService(new Intent(this,ScanService.class));showIdle();status.setText("● 감시 중지");countdown.setText("다음 분석  -");}
 void showRunning(){status.setText("● 감시 중");status.setTextColor(Color.parseColor("#35D07F"));start.setText("감시 중");start.setEnabled(false);}
 void showIdle(){status.setText("● 대기 중");status.setTextColor(Color.parseColor("#98A2B3"));start.setText("60초 감시 시작");start.setEnabled(true);}
 protected void onResume(){super.onResume();IntentFilter f=new IntentFilter(ScanService.ACTION);if(Build.VERSION.SDK_INT>=33)registerReceiver(rx,f,RECEIVER_NOT_EXPORTED);else registerReceiver(rx,f);if(ScanService.runningNow)showRunning();}
 protected void onPause(){super.onPause();try{unregisterReceiver(rx);}catch(Exception ignored){}}
 protected void onDestroy(){h.removeCallbacks(tick);super.onDestroy();}
}
