# PulseForge X Mobile V10.7 — Korean News Quality

V10.6 기반. 종목 상세의 한글 뉴스를 중요도/재료 유형 기준으로 정렬하고 단순 가격전망·퍼센트 등락 기사를 자동 제외합니다.
뉴스는 UI 표시 전용이며 PulseForge 엔진/DB/알림판정에는 영향을 주지 않습니다.

GitHub 복붙용 값은 `GITHUB_COPYPASTE_V107.txt`를 사용하세요.
