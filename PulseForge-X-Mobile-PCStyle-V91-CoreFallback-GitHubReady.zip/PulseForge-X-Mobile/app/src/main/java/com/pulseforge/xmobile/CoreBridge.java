package com.pulseforge.xmobile;

import android.content.*;
import org.json.*;
import java.util.*;

public class CoreBridge{
 public static final long FAILOVER_MS=120000L;
 final Context ctx;final PulseDb db;final SharedPreferences sp;
 public CoreBridge(Context c,PulseDb d){ctx=c.getApplicationContext();db=d;sp=ctx.getSharedPreferences("core_state",0);}

 public static class Canonical{
  public long alertNo;public String eventUuid,state;public boolean server;
  Canonical(long n,String u,String s,boolean v){alertNo=n;eventUuid=u;state=s;server=v;}
 }

 public String mode(){return sp.getString("mode","WAITING");}
 public long lastOkMs(){return sp.getLong("last_ok_ms",0);}
 public String lastError(){return sp.getString("last_error","");}

 public void refresh(){
  long now=System.currentTimeMillis();
  try{
   JSONObject h=CoreClient.health();if(!h.optBoolean("ok",false))throw new Exception("health false");
   sp.edit().putString("mode","SERVER").putLong("last_ok_ms",now).putLong("fail_since_ms",0).putString("last_error","").apply();
   try{CoreClient.heartbeat();}catch(Exception ignored){}
   ensureLease();
   syncPending();
  }catch(Exception e){
   long fail=sp.getLong("fail_since_ms",0);if(fail<=0){fail=now;sp.edit().putLong("fail_since_ms",fail).apply();}
   String m=(now-fail>=FAILOVER_MS)?"FALLBACK":"WAITING";
   sp.edit().putString("mode",m).putString("last_error",shortMsg(e)).apply();
  }
 }

 public void ensureLease()throws Exception{
  JSONObject r=CoreClient.lease();if(!r.optBoolean("ok",false))throw new Exception("lease failed");JSONObject l=r.getJSONObject("lease");long start=l.getLong("start_no"),end=l.getLong("end_no"),serverNext=r.optLong("next_local_no",start);db.saveCoreLease(CoreClient.DEVICE_ID,start,end,serverNext);sp.edit().putLong("lease_start",start).putLong("lease_end",end).apply();
 }

 public Canonical canonicalize(String type,long localRowId,JSONObject payload){
  try{
   JSONObject r=CoreClient.createEvent(type,payload,null);JSONObject e=r.getJSONObject("event");long no=e.getLong("alert_no");String u=e.getString("event_uuid");saveCanonical(type,localRowId,no,u,"SERVER");sp.edit().putString("mode","SERVER").putLong("last_ok_ms",System.currentTimeMillis()).putLong("fail_since_ms",0).putString("last_error","").apply();return new Canonical(no,u,"SERVER",true);
  }catch(Exception onlineError){
   try{
    PulseDb.LeaseAllocation a=db.allocateFallbackNumber(CoreClient.DEVICE_ID);
    if(a==null){try{ensureLease();a=db.allocateFallbackNumber(CoreClient.DEVICE_ID);}catch(Exception ignored){}}
    if(a==null){saveCanonical(type,localRowId,0,"","NO_LEASE");sp.edit().putString("mode","FALLBACK").putString("last_error","FALLBACK 번호 lease 없음 · "+shortMsg(onlineError)).apply();return new Canonical(0,"","NO_LEASE",false);}
    String u=UUID.randomUUID().toString();saveCanonical(type,localRowId,a.alertNo,u,"FALLBACK_PENDING");db.enqueueFallback(u,a.alertNo,type,localRowId,payload.toString());sp.edit().putString("mode","FALLBACK").putString("last_error",shortMsg(onlineError)).apply();return new Canonical(a.alertNo,u,"FALLBACK_PENDING",false);
   }catch(Exception e){sp.edit().putString("mode","FALLBACK").putString("last_error",shortMsg(e)).apply();return new Canonical(0,"","ERROR",false);}
  }
 }

 void saveCanonical(String type,long localRowId,long no,String uuid,String state){if("DROP".equals(type))db.setDropCanonical(localRowId,no,uuid,state);else db.setAlertCanonical(localRowId,no,uuid,state);}

 public void syncPending(){
  try{
   List<PulseDb.CoreQueueRow> rows=db.pendingCoreQueue(100);if(rows.isEmpty())return;JSONArray a=new JSONArray();for(PulseDb.CoreQueueRow q:rows){JSONObject x=new JSONObject();x.put("alert_no",q.alertNo);x.put("event_uuid",q.eventUuid);x.put("event_type",q.eventType);x.put("payload",new JSONObject(q.payloadJson));a.put(x);}JSONObject r=CoreClient.ingestFallback(a);if(!r.optBoolean("ok",false))throw new Exception("fallback sync failed");for(PulseDb.CoreQueueRow q:rows){db.markCoreQueueSynced(q.id);if("DROP".equals(q.eventType))db.setDropCanonical(q.localRowId,q.alertNo,q.eventUuid,"SYNCED");else db.setAlertCanonical(q.localRowId,q.alertNo,q.eventUuid,"SYNCED");}sp.edit().putLong("last_sync_ms",System.currentTimeMillis()).putString("last_error","").apply();
  }catch(Exception e){sp.edit().putString("last_error","동기화 · "+shortMsg(e)).apply();}
 }

 static String shortMsg(Exception e){String s=e.getMessage();if(s==null||s.trim().isEmpty())s=e.getClass().getSimpleName();return s.length()>140?s.substring(0,140):s;}
}
