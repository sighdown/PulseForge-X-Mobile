package com.pulseforge.xmobile;

import org.json.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;

public final class CoreClient{
 public static final String DEVICE_ID="mobile-a56";
 public static final String BASE_URL="http://100.74.6.90:8765";
 private CoreClient(){}

 public static JSONObject health()throws Exception{return request("GET","/health",null,2500,3000);}
 public static JSONObject heartbeat()throws Exception{JSONObject b=new JSONObject();b.put("device_id",DEVICE_ID);b.put("role","MOBILE");return request("POST","/heartbeat",b,2500,3500);}
 public static JSONObject lease()throws Exception{JSONObject b=new JSONObject();b.put("device_id",DEVICE_ID);return request("POST","/lease",b,3000,5000);}
 public static JSONObject createEvent(String eventType,JSONObject payload,String eventUuid)throws Exception{JSONObject b=new JSONObject();b.put("device_id",DEVICE_ID);b.put("event_type",eventType);b.put("origin","MOBILE_BRIDGE");b.put("payload",payload);if(eventUuid!=null&&!eventUuid.isEmpty())b.put("event_uuid",eventUuid);return request("POST","/events/create",b,3000,6000);}
 public static JSONObject ingestFallback(JSONArray events)throws Exception{JSONObject b=new JSONObject();b.put("device_id",DEVICE_ID);b.put("events",events);return request("POST","/ingest/fallback",b,3000,8000);}

 static JSONObject request(String method,String path,JSONObject body,int connectMs,int readMs)throws Exception{
  HttpURLConnection c=(HttpURLConnection)new URL(BASE_URL+path).openConnection();
  c.setConnectTimeout(connectMs);c.setReadTimeout(readMs);c.setRequestMethod(method);c.setUseCaches(false);c.setRequestProperty("Accept","application/json");
  if(body!=null){c.setDoOutput(true);c.setRequestProperty("Content-Type","application/json; charset=utf-8");byte[] raw=body.toString().getBytes(StandardCharsets.UTF_8);c.setFixedLengthStreamingMode(raw.length);try(OutputStream out=c.getOutputStream()){out.write(raw);}}
  int code=c.getResponseCode();InputStream in=code>=200&&code<300?c.getInputStream():c.getErrorStream();String text=readAll(in);c.disconnect();JSONObject o=text==null||text.trim().isEmpty()?new JSONObject():new JSONObject(text);if(code<200||code>=300)throw new IOException("HTTP "+code+" · "+o.optString("error",text));return o;
 }
 static String readAll(InputStream in)throws Exception{if(in==null)return "";try(InputStream x=in;ByteArrayOutputStream b=new ByteArrayOutputStream()){byte[] buf=new byte[8192];for(int n;(n=x.read(buf))>0;)b.write(buf,0,n);return b.toString("UTF-8");}}
}
