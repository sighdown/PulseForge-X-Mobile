package com.pulseforge.xmobile;

import android.content.Context;
import android.graphics.*;
import android.util.AttributeSet;
import android.view.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class InteractiveChartView extends View {
    public static class Point {
        public long timeMs; public double price;
        public Point(long t,double p){timeMs=t;price=p;}
    }
    public static class Candle {
        public long openTime; public double open,high,low,close,volume;
        public Candle(long t,double o,double h,double l,double c,double v){openTime=t;open=o;high=h;low=l;close=c;volume=v;}
    }

    private final ArrayList<Point> lineData=new ArrayList<>();
    private final ArrayList<Candle> candleData=new ArrayList<>();
    private boolean candleMode=false;
    private long markerTs=0; private double markerPrice=0; private boolean markerVisible=true;
    private int start=0,count=0; private boolean initialized=false;
    private float crossX=Float.NaN;
    private float downX,downY; private int dragStart; private boolean dragging=false;
    private final int touchSlop;
    private final ScaleGestureDetector scaleDetector;
    private final GestureDetector gestureDetector;
    public interface ViewportListener{void onViewportChanged(String summary);}
    private ViewportListener viewportListener;

    private final Paint grid=new Paint(Paint.ANTI_ALIAS_FLAG), text=new Paint(Paint.ANTI_ALIAS_FLAG), up=new Paint(Paint.ANTI_ALIAS_FLAG), down=new Paint(Paint.ANTI_ALIAS_FLAG), wick=new Paint(Paint.ANTI_ALIAS_FLAG), marker=new Paint(Paint.ANTI_ALIAS_FLAG), cross=new Paint(Paint.ANTI_ALIAS_FLAG), volume=new Paint(Paint.ANTI_ALIAS_FLAG), bgBox=new Paint(Paint.ANTI_ALIAS_FLAG);

    public InteractiveChartView(Context c,AttributeSet a){
        super(c,a); setFocusable(true); setClickable(true);
        float d=getResources().getDisplayMetrics().density;
        grid.setColor(Color.rgb(27,42,64)); grid.setStrokeWidth(Math.max(1,d));
        text.setColor(Color.rgb(129,144,165)); text.setTextSize(10*d);
        up.setColor(Color.rgb(14,203,129)); down.setColor(Color.rgb(246,70,93));
        wick.setStrokeWidth(Math.max(1,d)); marker.setColor(Color.rgb(255,93,115)); marker.setStrokeWidth(1.5f*d);
        cross.setColor(Color.rgb(100,116,139)); cross.setStrokeWidth(Math.max(1,d));
        volume.setStyle(Paint.Style.FILL); bgBox.setColor(Color.rgb(51,65,85));
        touchSlop=ViewConfiguration.get(c).getScaledTouchSlop();
        scaleDetector=new ScaleGestureDetector(c,new ScaleGestureDetector.SimpleOnScaleGestureListener(){
            public boolean onScaleBegin(ScaleGestureDetector detector){if(getParent()!=null)getParent().requestDisallowInterceptTouchEvent(true);crossX=Float.NaN;return true;}
            public boolean onScale(ScaleGestureDetector detector){
                int n=size(); if(n<3)return false; clamp(); int old=count;
                float sf=detector.getScaleFactor(); if(!Float.isFinite(sf)||sf<=0)return false;
                int min=Math.min(n,20); int neu=Math.max(min,Math.min(n,Math.round(old/sf)));
                if(neu==old)return true;
                float left=plotLeft(),right=plotRight(),pw=Math.max(1,right-left); float rel=Math.max(0,Math.min(1,(detector.getFocusX()-left)/pw));
                float anchor=start+rel*Math.max(1,old-1); start=Math.round(anchor-rel*Math.max(1,neu-1)); count=neu; clamp(); invalidate(); notifyViewport(); return true;
            }
            public void onScaleEnd(ScaleGestureDetector detector){if(getParent()!=null)getParent().requestDisallowInterceptTouchEvent(false);}
        });
        gestureDetector=new GestureDetector(c,new GestureDetector.SimpleOnGestureListener(){
            public boolean onDown(MotionEvent e){return true;}
            public boolean onDoubleTap(MotionEvent e){resetView();return true;}
            public boolean onSingleTapUp(MotionEvent e){crossX=e.getX();invalidate();performClick();return true;}
        });
    }

    public boolean performClick(){super.performClick();return true;}
    public void setViewportListener(ViewportListener l){viewportListener=l;}
    private void notifyViewport(){if(viewportListener!=null)viewportListener.onViewportChanged(visibleSummary());}
    public void setLineData(List<Point> x){candleMode=false;lineData.clear();if(x!=null)lineData.addAll(x);candleData.clear();initialized=false;resetView();}
    public void setCandleData(List<Candle> x){candleMode=true;candleData.clear();if(x!=null)candleData.addAll(x);lineData.clear();initialized=false;resetView();}
    public void setMarker(long tsMs,double price,boolean show){markerTs=tsMs;markerPrice=price;markerVisible=show;if(!initialized)resetView();else invalidate();}
    public void setMarkerVisible(boolean show){markerVisible=show;invalidate();}
    public void clearCrosshair(){crossX=Float.NaN;invalidate();}
    public void jumpLatest(){int n=size();if(n<=0)return;clamp();start=Math.max(0,n-count);crossX=Float.NaN;invalidate();notifyViewport();}
    public void jumpAlert(){int idx=markerIndex();if(idx<0)return;clamp();start=Math.max(0,Math.min(size()-count,idx-Math.round(count*0.42f)));crossX=Float.NaN;invalidate();notifyViewport();}
    public void resetView(){
        int n=size(); if(n<=0){start=0;count=0;initialized=true;invalidate();return;}
        int def=Math.min(n,candleMode?110:140); count=Math.max(Math.min(n,20),def);
        int idx=markerIndex(); if(idx>=0)start=Math.max(0,Math.min(n-count,idx-Math.round(count*0.42f)));else start=Math.max(0,n-count);
        crossX=Float.NaN;initialized=true;invalidate();notifyViewport();
    }
    public String visibleSummary(){int n=size();if(n<=0)return "데이터 없음";clamp();return "화면 "+(start+1)+"-"+Math.min(n,start+count)+" / 전체 "+n;}

    private int size(){return candleMode?candleData.size():lineData.size();}
    private long timeAt(int i){return candleMode?candleData.get(i).openTime:lineData.get(i).timeMs;}
    private void clamp(){int n=size();if(n<=0){start=count=0;return;}int min=Math.min(n,20);if(count<=0)count=Math.min(n,candleMode?110:140);count=Math.max(min,Math.min(count,n));start=Math.max(0,Math.min(start,Math.max(0,n-count)));}
    private int markerIndex(){
        int n=size();if(markerTs<=0||n<=0)return -1;long first=timeAt(0),last=timeAt(n-1);long step=60000L;if(n>1){ArrayList<Long> gaps=new ArrayList<>();for(int i=1;i<n;i++){long g=timeAt(i)-timeAt(i-1);if(g>0)gaps.add(g);}if(!gaps.isEmpty()){Collections.sort(gaps);step=gaps.get(gaps.size()/2);}}
        if(markerTs<first-step||markerTs>last+(long)(step*1.5))return -1;int best=-1;long bd=Long.MAX_VALUE;for(int i=0;i<n;i++){long v=Math.abs(timeAt(i)-markerTs);if(v<bd){bd=v;best=i;}}return bd<=Math.max(90000L,(long)(step*1.5))?best:-1;
    }
    private float plotLeft(){return dp(10);} private float plotRight(){return Math.max(plotLeft()+1,getWidth()-dp(76));}
    private float dp(float v){return v*getResources().getDisplayMetrics().density;}
    private String priceFmt(double v){double a=Math.abs(v);if(a>=1000)return String.format(Locale.US,"%,.2f",v);if(a>=100)return String.format(Locale.US,"%.3f",v);if(a>=1)return String.format(Locale.US,"%.5f",v);if(a>=0.01)return String.format(Locale.US,"%.6f",v);return String.format(Locale.US,"%.8f",v);}
    private String timeFmt(long ms,boolean full){Calendar cal=Calendar.getInstance();cal.setTimeInMillis(ms);String f;if(candleMode&&currentIntervalLikelyDays()){f=full?"yyyy/MM/dd":"MM/dd";}else f=full?"MM/dd HH:mm":"MM/dd HH:mm";return new SimpleDateFormat(f,Locale.KOREA).format(cal.getTime());}
    private boolean currentIntervalLikelyDays(){if(size()<2)return false;long g=Math.abs(timeAt(1)-timeAt(0));return g>=20L*3600*1000;}

    protected void onDraw(Canvas c){super.onDraw(c);drawChart(c);}
    private void drawChart(Canvas c){
        int n=size();if(n<=0){c.drawText("차트 데이터 없음",dp(16),getHeight()/2f,text);return;}clamp();int end=Math.min(n,start+count);int visN=end-start;if(visN<2)return;
        float w=getWidth(),h=getHeight(),left=plotLeft(),right=plotRight(),pw=Math.max(1,right-left),top=dp(34),bottom=h-dp(30);
        for(int k=1;k<6;k++){float x=left+pw*k/6f;c.drawLine(x,top,x,bottom,grid);}
        if(candleMode)drawCandles(c,start,end,left,right,top,bottom);else drawLine(c,start,end,left,right,top,bottom);
    }
    private void drawLine(Canvas c,int s,int e,float left,float right,float top,float bottom){
        int m=e-s;double lo=Double.MAX_VALUE,hi=-Double.MAX_VALUE;for(int i=s;i<e;i++){double p=lineData.get(i).price;lo=Math.min(lo,p);hi=Math.max(hi,p);}double raw=Math.max(hi-lo,Math.max(Math.abs(hi)*1e-9,1e-12));hi+=raw*.06;lo-=raw*.06;double span=hi-lo;
        for(int k=0;k<5;k++){float y=top+(bottom-top)*k/4f;double pv=hi-span*k/4.0;c.drawLine(left,y,right,y,grid);drawRightLabel(c,priceFmt(pv),right,y);}
        Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);p.setColor(Color.rgb(14,203,129));p.setStrokeWidth(dp(2));p.setStyle(Paint.Style.STROKE);Path path=new Path();
        for(int i=0;i<m;i++){Point x=lineData.get(s+i);float xx=left+(right-left)*(i/(float)Math.max(1,m-1));float yy=priceY(x.price,lo,hi,top,bottom);if(i==0)path.moveTo(xx,yy);else path.lineTo(xx,yy);}c.drawPath(path,p);
        drawTimes(c,s,e,left,right,bottom);drawMarkerLine(c,s,e,left,right,top,bottom,bottom,lo,hi,false);drawCrossLine(c,s,e,left,right,top,bottom,lo,hi);
    }
    private void drawCandles(Canvas c,int s,int e,float left,float right,float top,float bottom){
        int m=e-s;float volH=Math.min(dp(72),(bottom-top)*.25f),priceBottom=bottom-volH-dp(8),volTop=priceBottom+dp(12),volBottom=bottom;double lo=Double.MAX_VALUE,hi=-Double.MAX_VALUE,maxV=1;
        for(int i=s;i<e;i++){Candle x=candleData.get(i);lo=Math.min(lo,x.low);hi=Math.max(hi,x.high);maxV=Math.max(maxV,x.volume);}double raw=Math.max(hi-lo,Math.max(Math.abs(hi)*1e-9,1e-12));hi+=raw*.05;lo-=raw*.05;double span=hi-lo;
        for(int k=0;k<5;k++){float y=top+(priceBottom-top)*k/4f;double pv=hi-span*k/4.0;c.drawLine(left,y,right,y,grid);drawRightLabel(c,priceFmt(pv),right,y);}c.drawLine(left,volTop-dp(5),right,volTop-dp(5),grid);c.drawText("VOL",left+dp(3),volTop+dp(10),text);
        float step=(right-left)/Math.max(1,m),bw=Math.max(dp(2),Math.min(dp(14),step*.68f));
        for(int i=0;i<m;i++){Candle x=candleData.get(s+i);float cx=left+step*(i+.5f);Paint body=x.close>=x.open?up:down;wick.setColor(body.getColor());float yh=priceY(x.high,lo,hi,top,priceBottom),yl=priceY(x.low,lo,hi,top,priceBottom),yo=priceY(x.open,lo,hi,top,priceBottom),yc=priceY(x.close,lo,hi,top,priceBottom);c.drawLine(cx,yh,cx,yl,wick);float bt=Math.min(yo,yc),bb=Math.max(yo,yc);if(bb-bt<dp(1.5f))bb=bt+dp(1.5f);c.drawRect(cx-bw/2,bt,cx+bw/2,bb,body);float vh=(float)Math.max(dp(1),(volBottom-volTop)*x.volume/maxV);volume.setColor(body.getColor());volume.setAlpha(135);c.drawRect(cx-bw/2,volBottom-vh,cx+bw/2,volBottom,volume);volume.setAlpha(255);}
        drawTimes(c,s,e,left,right,bottom);drawMarkerLine(c,s,e,left,right,top,volBottom,priceBottom,lo,hi,true);drawCrossCandle(c,s,e,left,right,top,volBottom,priceBottom,lo,hi,step);
    }
    private void drawRightLabel(Canvas c,String label,float right,float y){Paint.FontMetrics fm=text.getFontMetrics();float hh=Math.abs(fm.ascent)+Math.abs(fm.descent);c.drawText(label,right+dp(6),y+hh*.3f,text);}
    private void drawTimes(Canvas c,int s,int e,float left,float right,float bottom){int m=e-s;for(int k=0;k<5;k++){int li=Math.round((m-1)*k/4f);float x=left+(right-left)*(li/(float)Math.max(1,m-1));String t=timeFmt(timeAt(s+li),false);float tw=text.measureText(t);x=Math.max(tw/2f,Math.min(getWidth()-tw/2f,x));c.drawText(t,x-tw/2f,getHeight()-dp(8),text);}}
    private void drawMarkerLine(Canvas c,int s,int e,float left,float right,float top,float lineBottom,float priceBottom,double lo,double hi,boolean candle){int idx=markerIndex();if(!markerVisible||idx<s||idx>=e)return;int li=idx-s;int m=e-s;float x=candle?left+(right-left)/Math.max(1,m)*(li+.5f):left+(right-left)*(li/(float)Math.max(1,m-1));double p=markerPrice>0?markerPrice:(candle?candleData.get(idx).close:lineData.get(idx).price);float y=priceY(p,lo,hi,top,priceBottom);Paint dash=new Paint(marker);dash.setPathEffect(new DashPathEffect(new float[]{dp(4),dp(3)},0));c.drawLine(x,top,x,lineBottom,dash);c.drawCircle(x,y,dp(7),marker);Paint ring=new Paint(marker);ring.setStyle(Paint.Style.STROKE);ring.setStrokeWidth(dp(2));c.drawCircle(x,y,dp(13),ring);Paint lab=new Paint(text);lab.setColor(Color.rgb(255,143,160));lab.setFakeBoldText(true);c.drawText("알림",Math.min(right-dp(34),x+dp(9)),Math.max(top+dp(12),y-dp(12)),lab);}
    private float priceY(double v,double lo,double hi,float top,float bottom){return (float)(top+(bottom-top)*(1-(v-lo)/(hi-lo)));}
    private int crossLocalIndex(int visN,float left,float right,boolean candle){if(Float.isNaN(crossX)||crossX<left||crossX>right)return -1;float rel=(crossX-left)/Math.max(1,right-left);int i=candle?(int)Math.floor(rel*visN):Math.round(rel*Math.max(1,visN-1));return Math.max(0,Math.min(visN-1,i));}
    private void drawCrossLine(Canvas c,int s,int e,float left,float right,float top,float bottom,double lo,double hi){int m=e-s,li=crossLocalIndex(m,left,right,false);if(li<0)return;Point p=lineData.get(s+li);float x=left+(right-left)*(li/(float)Math.max(1,m-1)),y=priceY(p.price,lo,hi,top,bottom);drawCross(c,x,y,left,right,top,bottom,priceFmt(p.price));drawInspectBox(c,timeFmt(p.timeMs,true)+"   가격 "+priceFmt(p.price));}
    private void drawCrossCandle(Canvas c,int s,int e,float left,float right,float top,float bottom,float priceBottom,double lo,double hi,float step){int m=e-s,li=crossLocalIndex(m,left,right,true);if(li<0)return;Candle x0=candleData.get(s+li);float x=left+step*(li+.5f),y=priceY(x0.close,lo,hi,top,priceBottom);drawCross(c,x,y,left,right,top,bottom,priceFmt(x0.close));drawInspectBox(c,timeFmt(x0.openTime,true)+"  O "+priceFmt(x0.open)+"  H "+priceFmt(x0.high)+"  L "+priceFmt(x0.low)+"  C "+priceFmt(x0.close)+"  V "+String.format(Locale.US,"%,.2f",x0.volume));}
    private void drawCross(Canvas c,float x,float y,float left,float right,float top,float bottom,String price){Paint dash=new Paint(cross);dash.setPathEffect(new DashPathEffect(new float[]{dp(2),dp(3)},0));c.drawLine(x,top,x,bottom,dash);c.drawLine(left,y,right,y,dash);float tw=text.measureText(price)+dp(10);c.drawRect(getWidth()-tw-dp(2),y-dp(10),getWidth()-dp(2),y+dp(10),bgBox);Paint white=new Paint(text);white.setColor(Color.WHITE);white.setFakeBoldText(true);c.drawText(price,getWidth()-tw+dp(3),y+dp(4),white);}
    private void drawInspectBox(Canvas c,String s){Paint p=new Paint(text);p.setColor(Color.rgb(226,232,240));p.setFakeBoldText(true);p.setTextSize(dp(9));float max=getWidth()-dp(12);String out=s;while(p.measureText(out)>max&&out.length()>12)out=out.substring(0,out.length()-2);c.drawText(out,dp(7),dp(19),p);}

    public boolean onTouchEvent(MotionEvent e){
        scaleDetector.onTouchEvent(e);gestureDetector.onTouchEvent(e);if(scaleDetector.isInProgress())return true;
        switch(e.getActionMasked()){
            case MotionEvent.ACTION_DOWN: downX=e.getX();downY=e.getY();dragStart=start;dragging=false;crossX=e.getX();invalidate();return true;
            case MotionEvent.ACTION_MOVE:
                float totalX=e.getX()-downX,totalY=e.getY()-downY;
                if(!dragging&&Math.abs(totalX)>touchSlop&&Math.abs(totalX)>Math.abs(totalY)*1.05f){dragging=true;crossX=Float.NaN;if(getParent()!=null)getParent().requestDisallowInterceptTouchEvent(true);}
                if(dragging){float pw=Math.max(1,plotRight()-plotLeft());int shift=Math.round(-totalX*Math.max(1,count)/pw);start=dragStart+shift;clamp();invalidate();notifyViewport();return true;}
                if(Math.abs(totalY)>touchSlop&&Math.abs(totalY)>Math.abs(totalX)){if(getParent()!=null)getParent().requestDisallowInterceptTouchEvent(false);return true;}
                crossX=e.getX();invalidate();return true;
            case MotionEvent.ACTION_UP: case MotionEvent.ACTION_CANCEL:
                if(getParent()!=null)getParent().requestDisallowInterceptTouchEvent(false);dragging=false;return true;
        }
        return true;
    }
}
