# PulseForge X Mobile V6.1

V6.0의 `early_v60` 선행 포착/후행 차단 모델을 그대로 유지하면서, 최신 PC V5.6에서 검증된 인터랙티브 차트 조작을 모바일 터치 UX로 이식한 버전입니다.

## V6.1 highlights
- Interactive Binance-style chart: pinch zoom, horizontal pan, touch crosshair, OHLC/volume inspection, double-tap reset.
- Right-side price axis, time axis, candle volume bars, alert marker.
- Alert/latest/reset shortcuts and landscape fullscreen chart.
- Up to 420 chart points/candles for smoother zoom/pan.
- Last selected timeframe persists.
- Per-symbol alert history shortcut from the detail screen.
- Existing V6 alert-history filter persistence remains intact.

## Signal model
- Model version remains `early_v60`.
- V6.1 does not change signal scoring, anti-late filters, post-scoring, or historical-pattern adjustment.

## Security
- Binance API credentials remain encrypted with Android Keystore.
- Authenticated API use remains limited to leverage bracket lookup; no order API is used.
