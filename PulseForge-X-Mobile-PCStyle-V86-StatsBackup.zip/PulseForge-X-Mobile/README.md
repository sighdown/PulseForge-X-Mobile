# PulseForge X Mobile V8.6 — Dual Signal Lab

## V8.6: 24H Prediction Stats + Backup Export

예측 통계 판정시간을 최대 24시간까지 확장하고, 보조 PC 연동/복원에 대비한 데이터 백업 내보내기 기능을 추가했습니다.

- 급등: HOT / PRIME / PRIME+
- 급락: REVERSAL / DROP RISK
- 기간: 7일 / 30일 / 전체
- 판정시간: 5분 / 15분 / 30분 / 1시간 / 2시간 / 4시간 / 6시간 / 8시간 / 12시간 / 24시간
- 기본 적중: 급등 +3%, 급락 -3% 도달
- 장기 6/8/12/24시간 결과는 Binance 과거 캔들로 보완 채점
- 원시 스캔 DB는 기존 최근 12시간 보관을 유지해 모바일 저장공간 증가를 최소화
- 시스템 상태 화면에서 ZIP 데이터 백업 내보내기 지원
- 백업 ZIP에 SQLite DB + 주요 설정 + 메타데이터 포함
- Binance API Key/Secret은 보안상 백업에서 제외

V8.5 예측 통계, V8.4 알림이력 위치 복원, V8.3 실제매매 LONG/SHORT·레버리지 기록 기능을 모두 유지합니다.

자세한 내용은 `업데이트_안내_V8.6.txt`를 참고하세요.
