package com.pulseforge.xmobile;

import android.app.*;import android.content.*;import androidx.core.app.NotificationCompat;import org.json.*;import java.util.*;import java.util.concurrent.*;

public class ScanService extends Service{
 public static final String CH="pf_scan",ALERT_CH="pf_alert",DROP_ALERT_CH="pf_drop_alert_v1",ACTION="com.pulseforge.xmobile.UPDATE";
 public static volatile boolean runningNow=false;
 static final int[] LEV_VALUES={5,10,20,25,50,75,100,125};
 volatile boolean running; ScheduledExecutorService ex; PulseDb db; Map<String,Integer> streak=new HashMap<>();

 public void onCreate(){super.onCreate();db=new PulseDb(this);NotificationManager n=getSystemService(NotificationManager.class);n.createNotificationChannel(new NotificationChannel(CH,"PulseForge 감시",NotificationManager.IMPORTANCE_LOW));NotificationChannel surgeCh=new NotificationChannel(ALERT_CH,"PulseForge 🚀 급등 선행",NotificationManager.IMPORTANCE_HIGH);surgeCh.setDescription("급등 선행신호 알림");n.createNotificationChannel(surgeCh);NotificationChannel dropCh=new NotificationChannel(DROP_ALERT_CH,"PulseForge ⚠ 급락 위험",NotificationManager.IMPORTANCE_HIGH);dropCh.setDescription("고점/급락 위험 알림 · 급등 알림과 별도 채널");dropCh.enableVibration(true);dropCh.setVibrationPattern(new long[]{0,120,80,120,80,240});try{android.net.Uri u=android.net.Uri.parse("android.resource://"+getPackageName()+"/"+R.raw.pf_drop_alert);android.media.AudioAttributes aa=new android.media.AudioAttributes.Builder().setUsage(android.media.AudioAttributes.USAGE_NOTIFICATION_EVENT).setContentType(android.media.AudioAttributes.CONTENT_TYPE_SONIFICATION).build();dropCh.setSound(u,aa);}catch(Exception ignored){}n.createNotificationChannel(dropCh);Intent mi=new Intent(this,MainActivity.class);PendingIntent mpi=PendingIntent.getActivity(this,10,mi,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);startForeground(10,new NotificationCompat.Builder(this,CH).setSmallIcon(R.drawable.ic_notification).setContentTitle("PulseForge X 감시 중").setContentText("60초마다 급등 선행 + 고점/급락 위험을 함께 분석합니다").setContentIntent(mpi).build());getSharedPreferences("runtime",0).edit().putLong("service_start_ms",System.currentTimeMillis()).putBoolean("service_running",true).apply();}
 public int onStartCommand(Intent i,int f,int id){runningNow=true;if(!running){running=true;ex=Executors.newSingleThreadScheduledExecutor();ex.scheduleWithFixedDelay(this::scan,0,60,TimeUnit.SECONDS);}return START_STICKY;}
 public void onDestroy(){runningNow=false;running=false;if(ex!=null)ex.shutdownNow();getSharedPreferences("runtime",0).edit().putBoolean("service_running",false).apply();super.onDestroy();}
 public android.os.IBinder onBind(Intent i){return null;}

 void scan(){long started=System.currentTimeMillis();try{
  runtime().edit().putString("state","collecting").putLong("last_scan_start_ms",started).apply();broadcastStatus("수집 중");refreshLeverageIfNeeded();
  Set<String> valid=BinanceClient.symbols();JSONArray ta=BinanceClient.tickers(),pa=BinanceClient.premiums();Map<String,Double> fund=new HashMap<>();for(int i=0;i<pa.length();i++){JSONObject x=pa.getJSONObject(i);if(valid.contains(x.optString("symbol")))fund.put(x.optString("symbol"),x.optDouble("lastFundingRate",0));}
  List<JSONObject> t=new ArrayList<>();for(int i=0;i<ta.length();i++){JSONObject x=ta.getJSONObject(i);if(valid.contains(x.optString("symbol")))t.add(x);}t.sort((a,b)->Double.compare(b.optDouble("quoteVolume"),a.optDouble("quoteVolume")));
  double btc=0;for(JSONObject x:t)if("BTCUSDT".equals(x.optString("symbol"))){btc=x.optDouble("priceChangePercent",0);break;}
  Map<String,Double> oi=new HashMap<>();for(int i=0;i<Math.min(60,t.size());i++)oi.put(t.get(i).optString("symbol"),BinanceClient.oi(t.get(i).optString("symbol")));
  long ts=System.currentTimeMillis()/1000;List<Row> rows=new ArrayList<>();
  for(JSONObject x:t){
   String s=x.optString("symbol");double p=x.optDouble("lastPrice"),q=x.optDouble("quoteVolume"),o=oi.getOrDefault(s,0.0),chg=x.optDouble("priceChangePercent"),fnd=fund.getOrDefault(s,0.0);List<ScoreEngine.Hist> hist=db.hist(s);
   ScoreEngine.Result r=ScoreEngine.compute(p,q,chg,fnd,o,hist,btc);
   if(r.leadCount>=2&&r.confidence>=75&&r.chase<10&&r.latePenalty<10&&Math.abs(r.ret10)<=3){PulseDb.LeadStats ls=db.leadStats(r.vz,r.oz,r.ret10,r.compression,r.prebreakout,r.dist20,r.leadCount);r.leadLearnSamples=ls.samples;r.leadLearnBonus=ls.bonus;r.leadLearnAvgGain=ls.avgGain;r.leadLearnAvgMinutes=ls.avgMinutes;}
   r.score=Math.round(clamp(r.score+r.leadLearnBonus,0,100)*10)/10.0;
   ScoreEngine.DropResult dr=ScoreEngine.computeDrop(p,chg,fnd,o,hist,btc,r);
   db.scan(ts,s,p,q,o,r,dr,fnd,chg);Row rr=new Row(s,r,dr,q,p,o,chg,fnd);rows.add(rr);evaluate(ts,rr);db.learnSurgeIfAny(ts,s,p,r);
   String dropStage=ScoreEngine.dropStage(dr),rawDropStage=ScoreEngine.dropStage(dr.preLateScore,dr.topHeat,dr.exhaustion,dr.reversal,dr.drawdownHigh);rearmDropIfQuiet(s,dropStage);
   boolean dropQuality=r.confidence>=75&&q>=5_000_000;
   if(dr.lateBlocked&&dropQuality&&!"NORMAL".equals(rawDropStage)){
    if(ts-db.lastDropSuppressedTs(s)>=900)db.dropSignal(ts,s,p,chg,r,dr);
   }else if(!"NORMAL".equals(dropStage)&&dropQuality){
    long minGap="TOP WATCH".equals(dropStage)?1800:900;
    if(ts-db.lastDropSignalTs(s)>=minGap){long dropId=db.dropSignal(ts,s,p,chg,r,dr);if(dropId>0&&shouldNotifyDrop(s,dropStage,ts)){notifyDropAlert(dropId,ts,s,dropStage,dr,p);markDropNotified(s,dropStage,ts);}}
   }
  }
  int outcomes=db.evaluatePendingAlerts(ts);db.evaluatePendingTrades(ts);int dropOutcomes=db.evaluatePendingDropSignals(ts);db.evaluatePendingDropTrades(ts);int[] longDone=evaluateLongHorizonOutcomes(ts);outcomes+=longDone[0];dropOutcomes+=longDone[1];maybePrune(ts);
  String[] surge=buildSurgeRanking(rows),drop=buildDropRanking(rows);
  long doneMs=System.currentTimeMillis(),nextAt=doneMs+60000;String now=new java.text.SimpleDateFormat("HH:mm:ss",Locale.KOREA).format(new Date(doneMs));
  SharedPreferences.Editor ed=runtime().edit().putString("state","ok").putLong("last_success_ms",doneMs).putLong("next_scan_ms",nextAt).putInt("last_count",t.size()).putString("last_rows",surge[0]).putString("last_symbols",surge[1]).putString("last_rows_surge",surge[0]).putString("last_symbols_surge",surge[1]).putString("last_rows_drop",drop[0]).putString("last_symbols_drop",drop[1]).putString("last_drop_diag",drop.length>2?drop[2]:"").putString("last_time",now).putString("last_error","").putInt("last_outcomes",outcomes).putInt("last_drop_outcomes",dropOutcomes);ed.apply();
  sendBroadcast(new Intent(ACTION).setPackage(getPackageName()).putExtra("status","정상 수집").putExtra("time",now).putExtra("count",t.size()).putExtra("rows",surge[0]).putExtra("symbols",surge[1]).putExtra("surgeRows",surge[0]).putExtra("surgeSymbols",surge[1]).putExtra("dropRows",drop[0]).putExtra("dropSymbols",drop[1]).putExtra("dropDiag",drop.length>2?drop[2]:"").putExtra("nextAt",nextAt).putExtra("outcomes",outcomes).putExtra("dropOutcomes",dropOutcomes));
 }catch(Exception e){String msg=e.getClass().getSimpleName();runtime().edit().putString("state","error").putString("last_error",msg).putLong("next_scan_ms",System.currentTimeMillis()+60000).apply();sendBroadcast(new Intent(ACTION).setPackage(getPackageName()).putExtra("status","수집 오류 · "+msg+" · 자동 재시도"));}}

 String[] buildSurgeRanking(List<Row> source){ArrayList<Row> rows=new ArrayList<>(source);rows.sort((a,b)->Double.compare(b.r.score,a.r.score));StringBuilder b=new StringBuilder(),syms=new StringBuilder();SharedPreferences sp=getSharedPreferences("settings",0);int rankIdx=Math.max(0,Math.min(8,sp.getInt("RANK_LEV_INDEX",0))),rankMin=rankIdx==0?0:LEV_VALUES[rankIdx-1],shown=0;for(Row r:rows){if(r.r.lateBlocked)continue;String st=ScoreEngine.stage(r.r.score);if(!rankStageAllowed(sp,st))continue;int ml=db.maxLeverage(r.s);if(rankMin>0&&(ml<=0||ml<rankMin))continue;if(shown>=15)break;if(shown>0)b.append("\n@@\n");b.append(shown+1).append(". ").append(r.s).append("  ").append(st).append("  ").append(String.format(Locale.US,"%.1f점",r.r.score)).append("\n   현재 ").append(fmt(r.price)).append("  |  24h ").append(String.format(Locale.US,"%+.2f%%",r.chg)).append("  |  거래 ").append(money(r.qv)).append("  |  OI ").append(money(r.oi));if(ml>0)b.append("  |  최대 ").append(ml).append("x");if(shown>0)syms.append(",");syms.append(r.s);shown++;}return new String[]{b.toString(),syms.toString()};}
 String[] buildDropRanking(List<Row> source){
  ArrayList<Row> rows=new ArrayList<>(source);rows.sort((a,b)->Double.compare(b.d.score,a.d.score));
  StringBuilder b=new StringBuilder(),syms=new StringBuilder();SharedPreferences sp=getSharedPreferences("settings",0);
  int rankIdx=Math.max(0,Math.min(8,sp.getInt("RANK_LEV_INDEX",0))),rankMin=rankIdx==0?0:LEV_VALUES[rankIdx-1],shown=0,eligible=0,topN=0,exhN=0,revN=0,riskN=0;
  Row best=null;double bestScore=-1;
  for(Row r:rows){
   if(r.d.lateBlocked)continue;
   int ml=db.maxLeverage(r.s);if(rankMin>0&&(ml<=0||ml<rankMin))continue;
   eligible++;String st=ScoreEngine.dropStage(r.d);
   if("TOP WATCH".equals(st))topN++;else if("EXHAUST".equals(st))exhN++;else if("REVERSAL".equals(st))revN++;else if("DROP RISK".equals(st))riskN++;
   if(r.d.score>bestScore){bestScore=r.d.score;best=r;}
   if("NORMAL".equals(st)||!dropStageAllowed(sp,st))continue;if(shown>=15)continue;
   if(shown>0)b.append("\n@@\n");
   b.append(shown+1).append(". ").append(r.s).append("  ").append(st).append("  ").append(String.format(Locale.US,"%.1f점",r.d.score))
    .append("\n   현재 ").append(fmt(r.price)).append("  |  24h ").append(String.format(Locale.US,"%+.2f%%",r.chg))
    .append("  |  60m ").append(String.format(Locale.US,"%+.2f%%",r.r.ret60))
    .append("  |  고점대비 ").append(String.format(Locale.US,"%+.2f%%",r.d.drawdownHigh));
   if(ml>0)b.append("  |  최대 ").append(ml).append("x");
   b.append("\n   과열 ").append(String.format(Locale.US,"%.0f",r.d.topHeat))
    .append("  |  약화 ").append(String.format(Locale.US,"%.0f",r.d.exhaustion))
    .append("  |  반전 ").append(String.format(Locale.US,"%.0f",r.d.reversal))
    .append("  |  OI과열 ").append(String.format(Locale.US,"%.0f",r.d.oiHeat))
    .append("\n   근거  ").append(r.d.reason);
   if(shown>0)syms.append(",");syms.append(r.s);shown++;
  }
  String scope=rankMin>0?rankMin+"x+":"전체";
  StringBuilder diag=new StringBuilder("엔진 진단 · ").append(scope).append(" 평가 ").append(eligible).append("종목")
   .append(" · WATCH ").append(topN).append(" · EXHAUST ").append(exhN).append(" · REVERSAL ").append(revN).append(" · RISK ").append(riskN);
  if(best!=null)diag.append("\n최고 ").append(best.s).append(" ").append(String.format(Locale.US,"%.1f점",best.d.score))
   .append(" · 과열 ").append(String.format(Locale.US,"%.0f",best.d.topHeat))
   .append(" / 약화 ").append(String.format(Locale.US,"%.0f",best.d.exhaustion))
   .append(" / 반전 ").append(String.format(Locale.US,"%.0f",best.d.reversal));
  if(shown==0)diag.append("\n현재 선택 단계 진입 종목 없음 · 엔진은 정상 계산 중");
  return new String[]{b.toString(),syms.toString(),diag.toString()};
 }

 void refreshLeverageIfNeeded(){if(!ApiCredentialStore.exists(this))return;long now=System.currentTimeMillis();PulseDb.LeverageStats s=db.leverageStats();if(s.count>0&&now-s.updatedTs*1000L<6L*60*60*1000)return;SharedPreferences r=runtime();long lastAttempt=r.getLong("leverage_last_attempt_ms",0);if(now-lastAttempt<10L*60*1000)return;r.edit().putLong("leverage_last_attempt_ms",now).apply();try{ApiCredentialStore.Credentials c=ApiCredentialStore.load(this);if(c==null)return;Map<String,Integer> m=BinanceClient.leverageMap(c.apiKey,c.secret);db.saveLeverageMap(m);r.edit().putLong("leverage_last_ok_ms",now).putString("leverage_last_error","").apply();}catch(Exception e){String m=e.getMessage()==null?e.getClass().getSimpleName():e.getMessage();if(m.length()>120)m=m.substring(0,120);r.edit().putString("leverage_last_error",m).apply();}}

 void evaluate(long ts,Row x){double base=x.r.score,c=x.r.confidence;rearmIfQuiet(x.s,base);
  boolean quality=c>=75&&x.qv>=5_000_000&&x.r.leadCount>=2;
  if(x.r.lateBlocked&&quality&&x.r.preLateScore>=72){streak.put(x.s,0);if(ts-db.lastSuppressedTs(x.s)>=900){PulseDb.PatternStats empty=new PulseDb.PatternStats();String stage=ScoreEngine.stage(x.r.preLateScore);String why="후행차단 · "+ScoreEngine.lateLabel(x.r.lateFlag)+" · 원점수 "+String.format(Locale.US,"%.1f",x.r.preLateScore)+" → "+String.format(Locale.US,"%.1f",x.r.score)+" · 패널티 "+String.format(Locale.US,"%.1f",x.r.latePenalty);db.alert(ts,x.s,stage,x.r.score,x.r.preLateScore,x.price,x.r,empty,why,true);}return;}
  boolean noChase=x.r.ret1>=-1.2&&x.r.ret1<=1.5&&x.r.ret3>=-1.5&&x.r.ret3<=1.8&&x.r.ret5<=2.8&&x.r.ret10>=-3&&x.r.ret10<=3.8&&x.r.chase<12&&x.r.latePenalty<10&&x.r.prebreakout>=45;
  boolean leadMatched=x.r.leadLearnSamples>=5&&x.r.leadLearnBonus>=1.0;boolean early=base>=72&&c>=75&&x.qv>=5_000_000&&((x.r.leadCount>=3)||(leadMatched&&x.r.leadCount>=2))&&noChase,confirmed=base>=78&&c>=75&&x.qv>=5_000_000&&x.r.leadCount>=2&&noChase;if(!(early||confirmed)){streak.put(x.s,0);return;}int n=streak.getOrDefault(x.s,0)+1;streak.put(x.s,n);int required=Math.max(1,Math.min(3,getSharedPreferences("settings",0).getInt("CONFIRMATIONS",2)));if(n<required)return;if(ts-db.lastAlertTs(x.s)<300)return;
  PulseDb.PatternStats p=db.patternStats(base,x.r.vz,x.r.oz,x.r.ret3,x.r.compression);double finalScore=Math.round(clamp(base+p.bonus,0,100)*10)/10.0;if(finalScore<72){streak.put(x.s,0);return;}String stage=ScoreEngine.stage(finalScore),reason=reason(x,p);long alertId=db.alert(ts,x.s,stage,finalScore,base,x.price,x.r,p,reason);streak.put(x.s,0);if(shouldNotify(x.s,stage,ts)){notifyAlert(alertId,ts,x.s,stage,finalScore);markNotified(x.s,stage,ts);}}

 String reason(Row x,PulseDb.PatternStats p){ArrayList<String>a=new ArrayList<>();if(x.r.vz>=1.15)a.add("거래량 선행");if(x.r.oz>=.90)a.add("OI 유입");if(x.r.compression>=70)a.add("가격 압축");if(x.r.prebreakout>=65)a.add("돌파 직전");if(x.r.leadLearnSamples>=5)a.add("선행역추적 "+x.r.leadLearnSamples+"건 +"+String.format(Locale.US,"%.1f",x.r.leadLearnBonus)+"점");if(p.samples>=5)a.add("유사패턴 "+p.samples+"건");return a.isEmpty()?"복합 선행 신호":join(a," · ");}
 String join(List<String>x,String sep){StringBuilder b=new StringBuilder();for(String s:x){if(b.length()>0)b.append(sep);b.append(s);}return b.toString();}

 void rearmIfQuiet(String sym,double score){if(score>=72)return;PulseDb.NotifyState s=db.notifyState(sym);if(s!=null&&!s.rearmed)db.saveNotifyState(sym,s.lastStage,s.lastTs,true);}
 boolean shouldNotify(String sym,String stage,long now){SharedPreferences p=getSharedPreferences("settings",0);boolean enabled=(stage.equals("EARLY WATCH")&&p.getBoolean("EARLY",false))||(stage.equals("ALERT")&&p.getBoolean("ALERT",false))||(stage.equals("HOT")&&p.getBoolean("HOT",true))||(stage.equals("PRIME")&&p.getBoolean("PRIME",true))||(stage.equals("PRIME+")&&p.getBoolean("PRIME_PLUS",p.getBoolean("PRIME",true)));if(!enabled)return false;if(p.getBoolean("LEV_ENABLED",false)){int idx=Math.max(0,Math.min(LEV_VALUES.length-1,p.getInt("MIN_LEV_INDEX",4))),minLev=LEV_VALUES[idx],maxLev=db.maxLeverage(sym);if(maxLev<=0||maxLev<minLev)return false;}PulseDb.NotifyState s=db.notifyState(sym);if(s==null)return true;long cooldown=Math.max(15,p.getInt("COOLDOWN_MIN",60))*60L;int nr=rank(stage),or=rank(s.lastStage);if(p.getBoolean("ESCALATION_IMMEDIATE",true)&&nr>or)return true;if(now-s.lastTs<cooldown)return false;if(s.rearmed)return true;if(stage.equals(s.lastStage)&&p.getBoolean("SAME_STAGE_REPEAT",false))return true;return nr>or;}
 void markNotified(String sym,String stage,long ts){db.saveNotifyState(sym,stage,ts,false);}
 boolean rankStageAllowed(SharedPreferences p,String s){if("PRIME+".equals(s))return p.getBoolean("RANK_STAGE_PRIME_PLUS",p.getBoolean("RANK_STAGE_PRIME",true));if("PRIME".equals(s))return p.getBoolean("RANK_STAGE_PRIME",true);if("HOT".equals(s))return p.getBoolean("RANK_STAGE_HOT",true);if("ALERT".equals(s))return p.getBoolean("RANK_STAGE_ALERT",true);if("EARLY WATCH".equals(s))return p.getBoolean("RANK_STAGE_EARLY",true);return false;}
 boolean dropStageAllowed(SharedPreferences p,String s){if("DROP RISK".equals(s))return p.getBoolean("DROP_STAGE_RISK",true);if("REVERSAL".equals(s))return p.getBoolean("DROP_STAGE_REVERSAL",true);if("EXHAUST".equals(s))return p.getBoolean("DROP_STAGE_EXHAUST",true);if("TOP WATCH".equals(s))return p.getBoolean("DROP_STAGE_TOP",true);return false;}
 void rearmDropIfQuiet(String sym,String stage){if(!"NORMAL".equals(stage))return;PulseDb.NotifyState s=db.dropNotifyState(sym);if(s!=null&&!s.rearmed)db.saveDropNotifyState(sym,s.lastStage,s.lastTs,true);}
 boolean shouldNotifyDrop(String sym,String stage,long now){SharedPreferences p=getSharedPreferences("settings",0);boolean enabled=("TOP WATCH".equals(stage)&&p.getBoolean("DROP_NOTIFY_TOP",false))||("EXHAUST".equals(stage)&&p.getBoolean("DROP_NOTIFY_EXHAUST",false))||("REVERSAL".equals(stage)&&p.getBoolean("DROP_NOTIFY_REVERSAL",true))||("DROP RISK".equals(stage)&&p.getBoolean("DROP_NOTIFY_RISK",true));if(!enabled)return false;if(p.getBoolean("LEV_ENABLED",false)){int idx=Math.max(0,Math.min(LEV_VALUES.length-1,p.getInt("MIN_LEV_INDEX",4))),minLev=LEV_VALUES[idx],maxLev=db.maxLeverage(sym);if(maxLev<=0||maxLev<minLev)return false;}PulseDb.NotifyState s=db.dropNotifyState(sym);if(s==null)return true;long cooldown=Math.max(15,p.getInt("DROP_COOLDOWN_MIN",60))*60L;int nr=dropRank(stage),or=dropRank(s.lastStage);if(p.getBoolean("DROP_ESCALATION_IMMEDIATE",true)&&nr>or)return true;if(now-s.lastTs<cooldown)return false;if(s.rearmed)return true;if(stage.equals(s.lastStage)&&p.getBoolean("DROP_SAME_STAGE_REPEAT",false))return true;return nr>or;}
 void markDropNotified(String sym,String stage,long ts){db.saveDropNotifyState(sym,stage,ts,false);}
 int dropRank(String s){if("DROP RISK".equals(s))return 4;if("REVERSAL".equals(s))return 3;if("EXHAUST".equals(s))return 2;if("TOP WATCH".equals(s))return 1;return 0;}
 void notifyDropAlert(long dropId,long ts,String sym,String stage,ScoreEngine.DropResult d,double price){Intent i=new Intent(this,SymbolDetailActivity.class).putExtra("symbol",sym).putExtra("drop_alert",true).putExtra("drop_signal_id",dropId).putExtra("drop_alert_ts",ts).putExtra("drop_alert_price",price).putExtra("drop_alert_stage",stage).putExtra("drop_alert_score",d.score).putExtra("drop_alert_drawdown",d.drawdownHigh).putExtra("drop_alert_reason",d.reason);PendingIntent pi=PendingIntent.getActivity(this,(int)((dropId*131)^sym.hashCode()),i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);String text=sym+" · "+String.format(Locale.US,"%.1f점",d.score)+" · 고점대비 "+String.format(Locale.US,"%+.2f%%",d.drawdownHigh);NotificationCompat.Builder b=new NotificationCompat.Builder(this,DROP_ALERT_CH).setSmallIcon(R.drawable.ic_notification).setColor(0xFFFF5D73).setContentTitle("⚠ 급락 위험 · "+stage).setContentText(text).setStyle(new NotificationCompat.BigTextStyle().bigText(text+"\n과열 "+String.format(Locale.US,"%.0f",d.topHeat)+" · 약화 "+String.format(Locale.US,"%.0f",d.exhaustion)+" · 반전 "+String.format(Locale.US,"%.0f",d.reversal)+"\n"+d.reason)).setContentIntent(pi).setPriority(NotificationCompat.PRIORITY_HIGH).setAutoCancel(true);if(!getSharedPreferences("settings",0).getBoolean("DROP_SOUND",true))b.setSilent(true);getSystemService(NotificationManager.class).notify((int)((dropId*17)&0x7fffffff),b.build());}

 int rank(String s){if("PRIME+".equals(s))return 5;if("PRIME".equals(s))return 4;if("HOT".equals(s))return 3;if("ALERT".equals(s))return 2;if("EARLY WATCH".equals(s))return 1;return 0;}

 void notifyAlert(long alertId,long ts,String sym,String stage,double score){String mark=stage.equals("PRIME+")?"💎":stage.equals("PRIME")?"🔥":stage.equals("HOT")?"🔥":stage.equals("ALERT")?"⚡":"👀";Intent d=new Intent(this,SymbolDetailActivity.class).putExtra("symbol",sym).putExtra("alert_ts",ts).putExtra("alert_id",alertId);PendingIntent pi=PendingIntent.getActivity(this,(int)((alertId*31)^sym.hashCode()),d,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);NotificationCompat.Builder b=new NotificationCompat.Builder(this,ALERT_CH).setSmallIcon(R.drawable.ic_notification).setColor(0xFF35D07F).setContentTitle("🚀 급등 선행 · "+stage).setContentText(sym+" · "+String.format(Locale.US,"%.1f",score)+"점 · "+mark).setContentIntent(pi).setPriority(NotificationCompat.PRIORITY_HIGH).setAutoCancel(true);if(!getSharedPreferences("settings",0).getBoolean("SOUND",true))b.setSilent(true);getSystemService(NotificationManager.class).notify((int)(System.nanoTime()&0x7fffffff),b.build());}

 int[] evaluateLongHorizonOutcomes(long nowS){
  int surge=0,drop=0;
  for(PulseDb.PendingOutcome p:db.pendingLongOutcomes(false,nowS)){try{if(evaluateLongOne(p,nowS))surge++;}catch(Exception ignored){}}
  for(PulseDb.PendingOutcome p:db.pendingLongOutcomes(true,nowS)){try{if(evaluateLongOne(p,nowS))drop++;}catch(Exception ignored){}}
  return new int[]{surge,drop};
 }
 boolean evaluateLongOne(PulseDb.PendingOutcome p,long nowS)throws Exception{
  int stepMin=p.horizon<=480?1:3;String interval=stepMin+"m";int limit=Math.min(500,Math.max(10,p.horizon/stepMin+5));long targetMs=(p.ts+p.horizon*60L)*1000L;
  JSONArray a=BinanceClient.klines(p.symbol,interval,limit,p.ts*1000L,targetMs+stepMin*60_000L);double hi=p.price,lo=p.price,end=p.price;boolean saw=false;Double t2=null,t3=null,t5=null,t8=null;
  for(int i=0;i<a.length();i++){JSONArray k=a.getJSONArray(i);long kt=k.getLong(0);if(kt>=targetMs)break;double kh=Double.parseDouble(k.getString(2)),kl=Double.parseDouble(k.getString(3)),kc=Double.parseDouble(k.getString(4));hi=Math.max(hi,kh);lo=Math.min(lo,kl);end=kc;saw=true;double mins=Math.max(0,(kt/1000L-p.ts)/60.0);double up=(kh/p.price-1)*100,down=(kl/p.price-1)*100;if(p.drop){if(t2==null&&down<=-2)t2=mins;if(t3==null&&down<=-3)t3=mins;if(t5==null&&down<=-5)t5=mins;if(t8==null&&down<=-8)t8=mins;}else{if(t3==null&&up>=3)t3=mins;if(t5==null&&up>=5)t5=mins;if(t8==null&&up>=8)t8=mins;}}
  if(!saw)return false;double maxUp=(hi/p.price-1)*100,maxDown=(lo/p.price-1)*100;return p.drop?db.saveLongDropOutcome(p,nowS,end,maxUp,maxDown,t2,t3,t5,t8):db.saveLongSurgeOutcome(p,nowS,end,maxUp,maxDown,t3,t5,t8);
 }

 void maybePrune(long nowS){SharedPreferences p=runtime();long last=p.getLong("last_prune_ms",0);long now=System.currentTimeMillis();if(now-last<6*60*60*1000L)return;db.pruneScans(nowS-12*60*60L);p.edit().putLong("last_prune_ms",now).apply();}
 SharedPreferences runtime(){return getSharedPreferences("runtime",0);}void broadcastStatus(String s){sendBroadcast(new Intent(ACTION).setPackage(getPackageName()).putExtra("status",s));}
 static double clamp(double v,double a,double b){return Math.max(a,Math.min(b,v));}static String fmt(double v){return v>=1?String.format(Locale.US,"%,.4f",v):String.format(Locale.US,"%.8f",v);}static String money(double v){if(v>=1e9)return String.format(Locale.US,"%.2fB",v/1e9);if(v>=1e6)return String.format(Locale.US,"%.2fM",v/1e6);return String.format(Locale.US,"%,.0f",v);}static class Row{String s;ScoreEngine.Result r;ScoreEngine.DropResult d;double qv,price,oi,chg,funding;Row(String s,ScoreEngine.Result r,ScoreEngine.DropResult d,double q,double p,double o,double c,double f){this.s=s;this.r=r;this.d=d;qv=q;price=p;oi=o;chg=c;funding=f;}}
}
