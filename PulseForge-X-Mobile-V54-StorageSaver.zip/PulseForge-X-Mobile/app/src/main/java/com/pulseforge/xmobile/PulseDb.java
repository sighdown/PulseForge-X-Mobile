package com.pulseforge.xmobile;
import android.content.*;import android.database.sqlite.*;import android.database.*;import java.util.*;
public class PulseDb extends SQLiteOpenHelper{
 private static final long RAW_KEEP_SECONDS=45*60; // 최근 45분 원시 스캔만 유지
 private static final int MAX_ALERTS=5000;          // 의미있는 신호 이력은 최대 5천건
 public PulseDb(Context c){super(c,"pulseforge_mobile.db",null,2);}
 public void onCreate(SQLiteDatabase d){
  d.execSQL("CREATE TABLE scans(ts INTEGER,symbol TEXT,price REAL,qv REAL,oi REAL,score REAL,PRIMARY KEY(ts,symbol))");
  d.execSQL("CREATE INDEX idx_scans_symbol_ts ON scans(symbol,ts DESC)");
  d.execSQL("CREATE TABLE alerts(ts INTEGER,symbol TEXT,stage TEXT,score REAL)");
  d.execSQL("CREATE INDEX idx_alerts_ts ON alerts(ts DESC)");
 }
 public void onUpgrade(SQLiteDatabase d,int a,int b){
  if(a<2){d.execSQL("CREATE INDEX IF NOT EXISTS idx_scans_symbol_ts ON scans(symbol,ts DESC)");d.execSQL("CREATE INDEX IF NOT EXISTS idx_alerts_ts ON alerts(ts DESC)");}
 }
 public List<ScoreEngine.Hist> hist(String s){ArrayList<ScoreEngine.Hist> out=new ArrayList<>();Cursor c=getReadableDatabase().rawQuery("SELECT price,qv,oi FROM scans WHERE symbol=? ORDER BY ts DESC LIMIT 24",new String[]{s});ArrayList<ScoreEngine.Hist> rev=new ArrayList<>();while(c.moveToNext())rev.add(new ScoreEngine.Hist(c.getDouble(0),c.getDouble(1),c.getDouble(2)));c.close();Collections.reverse(rev);return rev;}
 public void scan(long ts,String s,double p,double q,double oi,double score){getWritableDatabase().execSQL("INSERT OR REPLACE INTO scans VALUES(?,?,?,?,?,?)",new Object[]{ts,s,p,q,oi,score});}
 public void alert(long ts,String s,String st,double sc){getWritableDatabase().execSQL("INSERT INTO alerts VALUES(?,?,?,?)",new Object[]{ts,s,st,sc});}
 // 매 스캔 종료 후 오래된 원시 데이터 자동 삭제. SQLite는 빈 공간을 이후 데이터에 재사용하므로 DB가 계속 커지는 것을 막는다.
 public void prune(long nowTs){SQLiteDatabase d=getWritableDatabase();d.beginTransaction();try{d.delete("scans","ts<?",new String[]{String.valueOf(nowTs-RAW_KEEP_SECONDS)});d.execSQL("DELETE FROM alerts WHERE rowid NOT IN (SELECT rowid FROM alerts ORDER BY ts DESC LIMIT "+MAX_ALERTS+")");d.setTransactionSuccessful();}finally{d.endTransaction();}}
}
