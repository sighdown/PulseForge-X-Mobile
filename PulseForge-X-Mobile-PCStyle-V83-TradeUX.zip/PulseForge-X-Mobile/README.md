# PulseForge X Mobile V8.3 — Dual Signal Lab

기존 V8.2 LeadGuard의 급등/급락 감시, 후행차단 정보, 알림이력 위치 복원 및 평가 기능을 유지합니다.

## V8.3: Actual trade entry
- 급등/급락 알림이력에서 실제 매매 기록용 LONG(초록) / SHORT(코랄) 포지션 표시.
- 포지션과 레버리지 드롭다운을 한 줄에 배치. 5x/10x/20x/25x/50x/75x/100x/125x; 기본 50x.
- 가격 수익률과 배수 반영 *예상* 수익률을 분리하여 표시하며, 수익/손실은 방향 색상과 별도로 표시합니다.
- V11→V12 DB 자동 마이그레이션. 기존 기록의 레버리지는 모르는 값으로 유지됩니다(자동으로 50x 수익률을 가정하지 않음).
- 수익률 표시에는 수수료·펀딩비·슬리피지·강제청산·증거금 설정을 포함하지 않습니다.

## Android 빌드
이 프로젝트 디렉터리 기준 Gradle 8.7 / Java 17 / Android compileSdk 35. GitHub 저장소의 외부 `build-apk.yml`이 저장소 루트의 배포 ZIP을 `extracted` 폴더에 푼 다음 `extracted/PulseForge-X-Mobile`에서 기존 서명키 설정을 유지하며 빌드합니다.

릴리스 정보는 `업데이트_안내_V8.3.txt`, 이전 버전 기록은 `docs/release-history/`를 참고하세요.

## 보안
Binance API 자격 증명을 소스·ZIP·GitHub에 저장하거나 공유하지 마세요. 앱의 기기 내 Android Keystore 기능을 사용하세요. 안드로이드 앱 데이터를 삭제하거나 제거하면 기기 내 DB가 소실될 수 있습니다. 같은 서명 키로 기존 앱 위에 업데이트하는 방식을 권장합니다.
