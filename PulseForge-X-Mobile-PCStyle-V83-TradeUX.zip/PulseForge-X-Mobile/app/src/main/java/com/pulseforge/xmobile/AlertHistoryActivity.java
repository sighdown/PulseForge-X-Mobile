package com.pulseforge.xmobile;

import android.app.*;
import android.os.*;
import android.content.*;
import android.content.res.ColorStateList;
import android.graphics.*;
import android.text.*;
import android.text.style.*;
import android.view.*;
import android.widget.*;
import java.util.*;
import java.util.concurrent.*;

public class AlertHistoryActivity extends Activity{
 ArrayList<PulseDb.AlertRow> rows=new ArrayList<>();
 ArrayList<PulseDb.DropRow> dropRows=new ArrayList<>();
 ListView list;
 Button modeSurge,modeDrop,filterBtn,viewFilterBtn,clearSearchBtn;
 TextView count,historySubtitle,viewFilterLabel,searchHelp;
 EditText searchSymbol;
 ExecutorService work=Executors.newSingleThreadExecutor();
 boolean evaluating=false,preserveClickedAnchor=false;
 SharedPreferences ui;
 PulseDb db;
 long surgeAnchorId=-1,dropAnchorId=-1;
 int surgeAnchorTop=0,dropAnchorTop=0,surgeRestoreBudget=0,dropRestoreBudget=0;
 final String[] opts={"EARLY WATCH","ALERT","HOT","PRIME","PRIME+"};
 final String[] dropOpts={"TOP WATCH","EXHAUST","REVERSAL","DROP RISK"};
 final String[] viewOpts={"일반 알림","👍 추천 전체","👎 비추천 전체","후행차단 전체","💰 실제 매매"};
 final String[] dropViewOpts={"일반 알림","👍 추천 전체","👎 비추천 전체","후행차단 전체","💰 실제 매매"};

 public void onCreate(Bundle b){
  super.onCreate(b);setContentView(R.layout.activity_alert_history);
  findViewById(R.id.back).setOnClickListener(v->finish());
  list=findViewById(R.id.list);modeSurge=findViewById(R.id.historyModeSurge);modeDrop=findViewById(R.id.historyModeDrop);filterBtn=findViewById(R.id.filterBtn);viewFilterBtn=findViewById(R.id.viewFilterBtn);viewFilterLabel=findViewById(R.id.viewFilterLabel);historySubtitle=findViewById(R.id.historySubtitle);searchHelp=findViewById(R.id.searchHelp);searchSymbol=findViewById(R.id.searchSymbol);clearSearchBtn=findViewById(R.id.clearSearchBtn);count=findViewById(R.id.count);
  ui=getSharedPreferences("ui_state",0);initHistoryFilterDefaults();db=new PulseDb(this);migrateOldFilter();migratePrimePlus();migrateViewFilter();migrateDropViewFilterV2();
  modeSurge.setOnClickListener(v->setEngineMode(0));modeDrop.setOnClickListener(v->setEngineMode(1));filterBtn.setOnClickListener(v->showFilterDialog());viewFilterBtn.setOnClickListener(v->showViewFilterDialog());
  searchSymbol.setText(ui.getString("HIST_SYMBOL_SEARCH",""));searchSymbol.setSelection(searchSymbol.length());
  searchSymbol.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int before,int c){ui.edit().putString("HIST_SYMBOL_SEARCH",s.toString()).apply();clearSearchBtn.setVisibility(s.length()>0?View.VISIBLE:View.GONE);render();}public void afterTextChanged(Editable e){}});
  clearSearchBtn.setOnClickListener(v->searchSymbol.setText(""));clearSearchBtn.setVisibility(searchSymbol.length()>0?View.VISIBLE:View.GONE);applyEngineUI();
 }

 protected void onResume(){
  super.onResume();loadSavedAnchor(engineMode()==1);applyEngineUI();render();preserveClickedAnchor=false;
  if(!evaluating){evaluating=true;work.submit(()->{long now=System.currentTimeMillis()/1000;try{db.evaluatePendingAlerts(now);}catch(Exception ignored){}try{db.evaluatePendingDropSignals(now);}catch(Exception ignored){}try{db.evaluatePendingTrades(now);}catch(Exception ignored){}try{db.evaluatePendingDropTrades(now);}catch(Exception ignored){}runOnUiThread(()->{evaluating=false;render();});});}
 }


 protected void onPause(){if(!preserveClickedAnchor)rememberVisibleAnchor();super.onPause();}
 void rememberVisibleAnchor(){if(list==null||list.getCount()<=0)return;int first=list.getFirstVisiblePosition();if(first<0)return;View child=list.getChildAt(0);int top=child==null?0:child.getTop();boolean drop=engineMode()==1;long id=-1;if(drop&&first<dropRows.size())id=dropRows.get(first).id;else if(!drop&&first<rows.size())id=rows.get(first).id;if(id<=0)return;if(drop){dropAnchorId=id;dropAnchorTop=top;dropRestoreBudget=6;ui.edit().putLong("HIST_DROP_ANCHOR_ID",id).putInt("HIST_DROP_ANCHOR_TOP",top).apply();}else{surgeAnchorId=id;surgeAnchorTop=top;surgeRestoreBudget=6;ui.edit().putLong("HIST_SURGE_ANCHOR_ID",id).putInt("HIST_SURGE_ANCHOR_TOP",top).apply();}}
 void loadSavedAnchor(boolean drop){if(drop){dropAnchorId=ui.getLong("HIST_DROP_ANCHOR_ID",dropAnchorId);dropAnchorTop=ui.getInt("HIST_DROP_ANCHOR_TOP",dropAnchorTop);if(dropAnchorId>0)dropRestoreBudget=6;}else{surgeAnchorId=ui.getLong("HIST_SURGE_ANCHOR_ID",surgeAnchorId);surgeAnchorTop=ui.getInt("HIST_SURGE_ANCHOR_TOP",surgeAnchorTop);if(surgeAnchorId>0)surgeRestoreBudget=6;}}

 void initHistoryFilterDefaults(){
  SharedPreferences.Editor e=ui.edit();
  if(!ui.contains("HIST_EARLY"))e.putBoolean("HIST_EARLY",true);if(!ui.contains("HIST_ALERT"))e.putBoolean("HIST_ALERT",true);if(!ui.contains("HIST_HOT"))e.putBoolean("HIST_HOT",true);if(!ui.contains("HIST_PRIME"))e.putBoolean("HIST_PRIME",true);if(!ui.contains("HIST_PRIME_PLUS"))e.putBoolean("HIST_PRIME_PLUS",true);
  if(!ui.contains("HIST_DROP_TOP"))e.putBoolean("HIST_DROP_TOP",true);if(!ui.contains("HIST_DROP_EXHAUST"))e.putBoolean("HIST_DROP_EXHAUST",true);if(!ui.contains("HIST_DROP_REVERSAL"))e.putBoolean("HIST_DROP_REVERSAL",true);if(!ui.contains("HIST_DROP_RISK"))e.putBoolean("HIST_DROP_RISK",true);
  if(!ui.contains("HIST_VIEW_INDEX"))e.putInt("HIST_VIEW_INDEX",0);if(!ui.contains("HIST_DROP_VIEW_INDEX"))e.putInt("HIST_DROP_VIEW_INDEX",0);if(!ui.contains("HIST_ENGINE_MODE"))e.putInt("HIST_ENGINE_MODE",0);if(!ui.contains("HIST_SYMBOL_SEARCH"))e.putString("HIST_SYMBOL_SEARCH","");e.apply();
 }
 void migrateOldFilter(){if(ui.contains("HIST_FILTER_V2"))return;String old=ui.getString("ALERT_HISTORY_FILTER","전체");boolean e="전체".equals(old)||"EARLY WATCH".equals(old),a="전체".equals(old)||"ALERT".equals(old),h="전체".equals(old)||"HOT".equals(old),p="전체".equals(old)||"PRIME".equals(old),s="전체".equals(old)||"후행차단".equals(old);ui.edit().putBoolean("HIST_EARLY",e).putBoolean("HIST_ALERT",a).putBoolean("HIST_HOT",h).putBoolean("HIST_PRIME",p).putBoolean("HIST_SUPPRESSED",s).putBoolean("HIST_FILTER_V2",true).apply();}
 void migratePrimePlus(){if(ui.contains("HIST_FILTER_V3"))return;boolean pr=ui.getBoolean("HIST_PRIME",true);ui.edit().putBoolean("HIST_PRIME_PLUS",pr).putBoolean("HIST_FILTER_V3",true).apply();}
 void migrateViewFilter(){if(ui.contains("HIST_VIEW_FILTER_V1"))return;boolean anyNormal=pref("HIST_EARLY",true)||pref("HIST_ALERT",true)||pref("HIST_HOT",true)||pref("HIST_PRIME",true)||pref("HIST_PRIME_PLUS",pref("HIST_PRIME",true));boolean oldSupp=pref("HIST_SUPPRESSED",false);SharedPreferences.Editor e=ui.edit();if(oldSupp&&!anyNormal){e.putInt("HIST_VIEW_INDEX",3).putBoolean("HIST_EARLY",true).putBoolean("HIST_ALERT",true).putBoolean("HIST_HOT",true).putBoolean("HIST_PRIME",true).putBoolean("HIST_PRIME_PLUS",true);}else e.putInt("HIST_VIEW_INDEX",0);e.putBoolean("HIST_VIEW_FILTER_V1",true).apply();}
 void migrateDropViewFilterV2(){if(ui.contains("HIST_DROP_VIEW_FILTER_V2"))return;int old=ui.getInt("HIST_DROP_VIEW_INDEX",0);ui.edit().putInt("HIST_DROP_VIEW_INDEX",old==3?4:old).putBoolean("HIST_DROP_VIEW_FILTER_V2",true).apply();}
 boolean pref(String k,boolean d){return ui.getBoolean(k,d);}
 int engineMode(){return Math.max(0,Math.min(1,ui.getInt("HIST_ENGINE_MODE",0)));}
 void setEngineMode(int m){rememberVisibleAnchor();ui.edit().putInt("HIST_ENGINE_MODE",m==1?1:0).apply();loadSavedAnchor(m==1);applyEngineUI();render();}
 int viewMode(){return Math.max(0,Math.min(viewOpts.length-1,ui.getInt("HIST_VIEW_INDEX",0)));}
 int dropViewMode(){return Math.max(0,Math.min(dropViewOpts.length-1,ui.getInt("HIST_DROP_VIEW_INDEX",0)));}

 String surgeFilterSummary(){boolean e=pref("HIST_EARLY",true),a=pref("HIST_ALERT",true),h=pref("HIST_HOT",true),p=pref("HIST_PRIME",true),pp=pref("HIST_PRIME_PLUS",p);if(e&&a&&h&&p&&pp)return "전체";ArrayList<String>x=new ArrayList<>();if(e)x.add("EARLY");if(a)x.add("ALERT");if(h)x.add("HOT");if(p)x.add("PRIME");if(pp)x.add("PRIME+");return x.isEmpty()?"선택 없음":TextUtils.join(" + ",x);}
 String dropFilterSummary(){boolean a=pref("HIST_DROP_TOP",true),b=pref("HIST_DROP_EXHAUST",true),c=pref("HIST_DROP_REVERSAL",true),d=pref("HIST_DROP_RISK",true);if(a&&b&&c&&d)return "전체";ArrayList<String>x=new ArrayList<>();if(a)x.add("WATCH");if(b)x.add("EXHAUST");if(c)x.add("REVERSAL");if(d)x.add("DROP RISK");return x.isEmpty()?"선택 없음":TextUtils.join(" + ",x);}
 String filterSummary(){return engineMode()==1?dropFilterSummary():surgeFilterSummary();}
 void updateViewFilterButton(){if(viewFilterBtn!=null)viewFilterBtn.setText("보기 필터 · "+(engineMode()==1?dropViewOpts[dropViewMode()]:viewOpts[viewMode()]));}

 void applyEngineUI(){
  boolean drop=engineMode()==1;
  modeSurge.setText((!drop?"● ":"")+"🚀 급등 선행");modeDrop.setText((drop?"● ":"")+"⚠ 급락 위험");
  modeSurge.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor(!drop?"#227253":"#2A3E55")));modeDrop.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor(drop?"#91405A":"#2A3E55")));
  modeSurge.setTextColor(Color.parseColor("#F5F8FC"));modeDrop.setTextColor(Color.parseColor("#F5F8FC"));modeSurge.setAlpha(1f);modeDrop.setAlpha(1f);
  historySubtitle.setText(drop?"5/15/30/60/120/240분 급락 사후채점 · -2/-3/-5/-8% 도달시간 · 방향/배수별 매매 기록":"5/15/30/60/120/240분 사후채점 · 👍/👎 사용자 평가는 엔진과 별도 저장");
  filterBtn.setText("단계 필터 · "+filterSummary());
  viewFilterLabel.setVisibility(View.VISIBLE);viewFilterBtn.setVisibility(View.VISIBLE);
  viewFilterLabel.setText("보기 필터 · 한 번에 하나만 선택");
  searchHelp.setText("검색은 현재 단계/보기 필터를 따르며 기간은 DB 전체");
  applyViewState();
 }
 void applyViewState(){boolean drop=engineMode()==1;int m=drop?dropViewMode():viewMode();boolean stageActive=m==0;filterBtn.setEnabled(stageActive);filterBtn.setAlpha(stageActive?1f:.55f);updateViewFilterButton();}
 void showViewFilterDialog(){boolean drop=engineMode()==1;final String[] arr=drop?dropViewOpts:viewOpts;int cur=drop?dropViewMode():viewMode();new AlertDialog.Builder(this,android.R.style.Theme_Material_Dialog_Alert).setTitle(drop?"급락 위험 보기 필터":"급등 선행 보기 필터").setSingleChoiceItems(arr,cur,(d,which)->{which=Math.max(0,Math.min(arr.length-1,which));SharedPreferences.Editor e=ui.edit();if(drop)e.putInt("HIST_DROP_VIEW_INDEX",which);else e.putInt("HIST_VIEW_INDEX",which);e.apply();d.dismiss();applyViewState();render();}).setNegativeButton("취소",null).show();}

 void showFilterDialog(){
  if(engineMode()==1){
   final boolean[] chk={pref("HIST_DROP_TOP",true),pref("HIST_DROP_EXHAUST",true),pref("HIST_DROP_REVERSAL",true),pref("HIST_DROP_RISK",true)};
   final String[] names={"TOP WATCH · 고점 과열 관찰","EXHAUST · 상승 에너지 약화","REVERSAL · 단기 반전 확인","DROP RISK · 급락 위험 집중"};
   new AlertDialog.Builder(this,android.R.style.Theme_Material_Dialog_Alert).setTitle("DROP RISK 단계 필터").setMultiChoiceItems(names,chk,(d,w,on)->chk[w]=on).setNegativeButton("취소",null).setPositiveButton("적용",(d,w)->{ui.edit().putBoolean("HIST_DROP_TOP",chk[0]).putBoolean("HIST_DROP_EXHAUST",chk[1]).putBoolean("HIST_DROP_REVERSAL",chk[2]).putBoolean("HIST_DROP_RISK",chk[3]).apply();filterBtn.setText("단계 필터 · "+dropFilterSummary());render();}).show();
  }else{
   final boolean[] chk={pref("HIST_EARLY",true),pref("HIST_ALERT",true),pref("HIST_HOT",true),pref("HIST_PRIME",true),pref("HIST_PRIME_PLUS",pref("HIST_PRIME",true))};
   new AlertDialog.Builder(this,android.R.style.Theme_Material_Dialog_Alert).setTitle("TOP SIGNALS 단계 필터").setMultiChoiceItems(opts,chk,(d,w,on)->chk[w]=on).setNegativeButton("취소",null).setPositiveButton("적용",(d,w)->{ui.edit().putBoolean("HIST_EARLY",chk[0]).putBoolean("HIST_ALERT",chk[1]).putBoolean("HIST_HOT",chk[2]).putBoolean("HIST_PRIME",chk[3]).putBoolean("HIST_PRIME_PLUS",chk[4]).apply();filterBtn.setText("단계 필터 · "+surgeFilterSummary());render();}).show();
  }
 }

 void render(){if(list==null)return;if(engineMode()==1)renderDrop();else renderSurge();}
 void renderSurge(){
  boolean e=pref("HIST_EARLY",true),a=pref("HIST_ALERT",true),h=pref("HIST_HOT",true),p=pref("HIST_PRIME",true),pp=pref("HIST_PRIME_PLUS",p);int mode=viewMode();String q=searchSymbol==null?"":searchSymbol.getText().toString().trim();
  rows.clear();rows.addAll(db.alertsHistory(2000,e,a,h,p,pp,mode,q));ArrayList<String> text=new ArrayList<>();java.text.SimpleDateFormat df=new java.text.SimpleDateFormat("MM/dd HH:mm:ss",Locale.KOREA);
  for(PulseDb.AlertRow r:rows){Map<Integer,PulseDb.Outcome> o=db.outcomes(r.id);String pattern=r.patternSamples>=5?String.format(Locale.US,"유사 %d건 · 30m 평균 %+.2f%%",r.patternSamples,r.patternAvg30==null?0:r.patternAvg30):"유사패턴 표본 "+r.patternSamples+"건";String head=r.suppressed?"후행차단 · 원 "+r.stage+" "+String.format(Locale.US,"%.1f점",r.baseScore)+" → "+String.format(Locale.US,"%.1f점",r.score):r.stage+"   "+String.format(Locale.US,"%.1f점",r.score);String extra=r.suppressed?"\n"+(r.reason==null?"후행 위험으로 푸시 제외":r.reason):"";PulseDb.TradeRow tr=db.trade(r.id);String trade=tradeSummary(tr,r.id,false);text.add(df.format(new Date(r.ts*1000))+"   "+head+"\n"+r.symbol+"   당시 "+fmt(r.price)+"   "+pattern+extra+trade+"\n5m "+ret(o,5)+"  ·  15m "+ret(o,15)+"  ·  30m "+ret(o,30)+"\n1h "+ret(o,60)+"  ·  2h "+ret(o,120)+"  ·  4h "+ret(o,240));}
  list.setAdapter(new SurgeHistAdapter(this,text));updateSurgeCount();restoreAnchor(false);
 }
 void renderDrop(){
  boolean a=pref("HIST_DROP_TOP",true),b=pref("HIST_DROP_EXHAUST",true),c=pref("HIST_DROP_REVERSAL",true),d=pref("HIST_DROP_RISK",true);int mode=dropViewMode();String q=searchSymbol==null?"":searchSymbol.getText().toString().trim();
  dropRows.clear();dropRows.addAll(db.dropHistory(2000,a,b,c,d,mode,q));ArrayList<String> text=new ArrayList<>();java.text.SimpleDateFormat df=new java.text.SimpleDateFormat("MM/dd HH:mm:ss",Locale.KOREA);
  for(PulseDb.DropRow r:dropRows){Map<Integer,PulseDb.DropOutcome> o=db.dropOutcomes(r.id);PulseDb.DropOutcome last=latestDropOutcome(o);String max=last==null?"사후 최대값 대기":"최대하락 "+String.format(Locale.US,"%+.2f%%",last.maxDown)+" · 역행상승 "+String.format(Locale.US,"%+.2f%%",last.maxUp);String hits=last==null?"-2/-3/-5/-8% 도달 대기":"-2% "+mins(last.time2)+" · -3% "+mins(last.time3)+" · -5% "+mins(last.time5)+" · -8% "+mins(last.time8);String reason=(r.reason==null||r.reason.trim().isEmpty())?"":("\n근거  "+r.reason);String head=r.suppressed?"후행차단 · 원 "+r.stage+" "+String.format(Locale.US,"%.1f점",r.baseScore)+" → "+String.format(Locale.US,"%.1f점",r.score):r.stage+"   "+String.format(Locale.US,"%.1f점",r.score);String block=r.suppressed?"\n차단근거  "+ScoreEngine.dropLateLabel(r.lateFlag)+" · 후행패널티 "+String.format(Locale.US,"%.1f",r.latePenalty)+"점":"";PulseDb.TradeRow tr=db.dropTrade(r.id);String trade=tradeSummary(tr,r.id,true);text.add(df.format(new Date(r.ts*1000))+"   "+head+"\n"+r.symbol+"   당시 "+fmt(r.price)+"   24h "+String.format(Locale.US,"%+.2f%%",r.change24)+" · 고점대비 "+String.format(Locale.US,"%+.2f%%",r.drawdownHigh)+block+"\n과열 "+String.format(Locale.US,"%.0f",r.topHeat)+" · 약화 "+String.format(Locale.US,"%.0f",r.exhaustion)+" · 반전 "+String.format(Locale.US,"%.0f",r.reversal)+" · OI과열 "+String.format(Locale.US,"%.0f",r.oiHeat)+reason+trade+"\n5m "+dropRet(o,5)+"  ·  15m "+dropRet(o,15)+"  ·  30m "+dropRet(o,30)+"\n1h "+dropRet(o,60)+"  ·  2h "+dropRet(o,120)+"  ·  4h "+dropRet(o,240)+"\n"+max+"\n"+hits);}
  list.setAdapter(new DropHistAdapter(this,text));updateDropCount();restoreAnchor(true);
 }

 void updateSurgeCount(){int up=0,down=0,trades=0;for(PulseDb.AlertRow r:rows){if(r.userRating>0)up++;else if(r.userRating<0)down++;if(db.trade(r.id)!=null)trades++;}int m=viewMode();String tail=m==0?"단계 "+surgeFilterSummary()+" · "+viewOpts[m]:viewOpts[m]+" · 단계필터 일시 미적용";String q=searchSymbol==null?"":searchSymbol.getText().toString().trim();if(!q.isEmpty())tail+=" · 검색 "+q.toUpperCase(Locale.US)+" (전체기간)";count.setText("🚀 표시 "+rows.size()+"건 · 👍 "+up+" · 👎 "+down+" · 💰 "+trades+" · "+tail);}
 void updateDropCount(){int w=0,e=0,r=0,k=0,blocked=0,up=0,down=0,trades=0;for(PulseDb.DropRow x:dropRows){if(x.suppressed)blocked++;if("TOP WATCH".equals(x.stage))w++;else if("EXHAUST".equals(x.stage))e++;else if("REVERSAL".equals(x.stage))r++;else if("DROP RISK".equals(x.stage))k++;if(x.userRating>0)up++;else if(x.userRating<0)down++;if(db.dropTrade(x.id)!=null)trades++;}int m=dropViewMode();String tail=m==0?"단계 "+dropFilterSummary()+" · "+dropViewOpts[m]:dropViewOpts[m]+" · 단계필터 일시 미적용";String q=searchSymbol==null?"":searchSymbol.getText().toString().trim();if(!q.isEmpty())tail+=" · 검색 "+q.toUpperCase(Locale.US)+" (전체기간)";count.setText("⚠ 표시 "+dropRows.size()+"건 · 👍 "+up+" · 👎 "+down+" · 💰 "+trades+" · 후행차단 "+blocked+" · WATCH "+w+" · EXHAUST "+e+" · REVERSAL "+r+" · RISK "+k+" · "+tail);}

 void rememberAnchor(long id,int pos,boolean drop){int first=list.getFirstVisiblePosition();View child=list.getChildAt(pos-first);int top=child==null?0:child.getTop();if(drop){dropAnchorId=id;dropAnchorTop=top;dropRestoreBudget=6;ui.edit().putLong("HIST_DROP_ANCHOR_ID",id).putInt("HIST_DROP_ANCHOR_TOP",top).apply();}else{surgeAnchorId=id;surgeAnchorTop=top;surgeRestoreBudget=6;ui.edit().putLong("HIST_SURGE_ANCHOR_ID",id).putInt("HIST_SURGE_ANCHOR_TOP",top).apply();}}
 void restoreAnchor(boolean drop){if(drop&&dropRestoreBudget<=0)return;if(!drop&&surgeRestoreBudget<=0)return;final long id=drop?dropAnchorId:surgeAnchorId;final int top=drop?dropAnchorTop:surgeAnchorTop;if(id<=0)return;list.post(()->{int pos=-1;if(drop){for(int i=0;i<dropRows.size();i++)if(dropRows.get(i).id==id){pos=i;break;}if(dropRestoreBudget>0)dropRestoreBudget--;}else{for(int i=0;i<rows.size();i++)if(rows.get(i).id==id){pos=i;break;}if(surgeRestoreBudget>0)surgeRestoreBudget--;}if(pos>=0)list.setSelectionFromTop(pos,top);});}

 void openDetail(PulseDb.AlertRow r){preserveClickedAnchor=true;startActivity(new Intent(this,SymbolDetailActivity.class).putExtra("symbol",r.symbol).putExtra("alert_ts",r.ts).putExtra("alert_id",r.id));}
 void openDropDetail(PulseDb.DropRow r){preserveClickedAnchor=true;startActivity(new Intent(this,SymbolDetailActivity.class).putExtra("symbol",r.symbol).putExtra("drop_alert",true).putExtra("drop_signal_id",r.id).putExtra("drop_alert_ts",r.ts).putExtra("drop_alert_price",r.price).putExtra("drop_alert_stage",r.stage).putExtra("drop_alert_score",r.score).putExtra("drop_alert_drawdown",r.drawdownHigh).putExtra("drop_alert_reason",r.reason));}
 void rate(PulseDb.AlertRow r,int wanted){int next=r.userRating==wanted?0:wanted;db.setUserRating(r.id,next);r.userRating=next;render();String msg=next>0?"👍 추천으로 저장":next<0?"👎 비추천으로 저장":"사용자 평가 취소";Toast.makeText(this,msg+" · 엔진 점수에는 직접 반영되지 않음",Toast.LENGTH_SHORT).show();}
 void rateDrop(PulseDb.DropRow r,int wanted){int next=r.userRating==wanted?0:wanted;db.setDropUserRating(r.id,next);r.userRating=next;render();String msg=next>0?"👍 추천으로 저장":next<0?"👎 비추천으로 저장":"사용자 평가 취소";Toast.makeText(this,msg+" · 급락 엔진 점수에는 직접 반영되지 않음",Toast.LENGTH_SHORT).show();}
 String ret(Map<Integer,PulseDb.Outcome>o,int h){PulseDb.Outcome x=o.get(h);return x==null?"-":String.format(Locale.US,"%+.2f%%",x.ret);}
 String dropRet(Map<Integer,PulseDb.DropOutcome>o,int h){PulseDb.DropOutcome x=o.get(h);return x==null?"-":String.format(Locale.US,"%+.2f%%",x.ret);}
 PulseDb.DropOutcome latestDropOutcome(Map<Integer,PulseDb.DropOutcome>m){int[] hs={240,120,60,30,15,5};for(int h:hs)if(m.get(h)!=null)return m.get(h);return null;}
 String mins(Double v){if(v==null)return "-";return String.format(Locale.US,"%.0f분",v);}
 String tradeSummary(PulseDb.TradeRow t,long refId,boolean dropEngine){
  if(t==null)return "";
  String side=t.side==null?(dropEngine?"SHORT":"LONG"):t.side;
  String lev=t.leverage>0?t.leverage+"x":"배수 미입력";
  if(!t.closed())return "\n💰 "+side+" · "+lev+" · 진입 "+fmt(t.buyPrice)+" · 보유중";
  long mins=Math.max(0,(t.sellTs-t.buyTs)/60);
  String x="\n💰 "+side+" · "+lev+" · "+fmt(t.buyPrice)+" → "+fmt(t.sellPrice)
   +"\n가격 수익률 "+String.format(Locale.US,"%+.2f%%",t.priceReturnPct())
   +" · 배수 반영 예상 "+(t.leverage>0?String.format(Locale.US,"%+.2f%%",t.leveragedReturnPct()):"미입력")+" · "+mins+"분";
  if(t.holdMfe!=null)x+="\n보유 MFE(가격) "+String.format(Locale.US,"%+.2f%%",t.holdMfe)+(t.holdMae==null?"":" · MAE "+String.format(Locale.US,"%+.2f%%",t.holdMae));
  Map<Integer,PulseDb.TradeOutcome> m=dropEngine?db.dropTradeOutcomes(refId):db.tradeOutcomes(refId);
  int[] hs={240,120,60,30,15};for(int h:hs){PulseDb.TradeOutcome o=m.get(h);if(o!=null){x+=" · 매도 후 가격 "+(h>=60?(h/60)+"h":h+"m")+" 최대 "+String.format(Locale.US,"%+.2f%%",o.maxFav);break;}}
  return x;
 }

 TextView tradeLabel(String text){TextView v=new TextView(this);v.setText(text);v.setTextColor(Color.parseColor("#D9E4F2"));v.setTextSize(13);v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);v.setPadding(2,10,2,4);return v;}
 android.graphics.drawable.GradientDrawable tradeBg(String fill,String stroke){android.graphics.drawable.GradientDrawable g=new android.graphics.drawable.GradientDrawable();g.setColor(Color.parseColor(fill));g.setCornerRadius(9*getResources().getDisplayMetrics().density);g.setStroke(Math.max(1,(int)getResources().getDisplayMetrics().density),Color.parseColor(stroke));return g;}
 void styleTradeInput(EditText e){e.setTextColor(Color.parseColor("#FFFFFF"));e.setHintTextColor(Color.parseColor("#9FB0C4"));e.setTextSize(16);e.setSingleLine(true);e.setPadding((int)(14*getResources().getDisplayMetrics().density),0,(int)(14*getResources().getDisplayMetrics().density),0);e.setMinHeight((int)(52*getResources().getDisplayMetrics().density));e.setBackground(tradeBg("#1B2B3F","#45617F"));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,0,0,(int)(6*getResources().getDisplayMetrics().density));e.setLayoutParams(lp);}
 void editTrade(PulseDb.AlertRow r){editTradeCommon(r.id,r.symbol,r.ts,false);}
 void editDropTrade(PulseDb.DropRow r){editTradeCommon(r.id,r.symbol,r.ts,true);}
 int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}
 int positionColor(boolean shortSide){return Color.parseColor(shortSide?"#FF9EAD":"#77EDAA");}
 android.widget.ArrayAdapter<String> coloredSideAdapter(String[] items){
  return new android.widget.ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,items){
   TextView sideText(int position,boolean dropdown){
    TextView t=new TextView(AlertHistoryActivity.this);t.setText(items[position]);
    t.setTextColor(positionColor(position==1));t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
    t.setTextSize(16);t.setGravity(Gravity.CENTER_VERTICAL);t.setPadding(dp(12),0,dp(6),0);
    t.setMinHeight(dp(48));if(dropdown)t.setBackgroundColor(Color.parseColor("#172639"));return t;
   }
   @Override public View getView(int p,View v,ViewGroup parent){return sideText(p,false);}
   @Override public View getDropDownView(int p,View v,ViewGroup parent){return sideText(p,true);}
  };
 }
 void editTradeCommon(long refId,String symbol,long defaultTs,boolean dropEngine){
  PulseDb.TradeRow old=dropEngine?db.dropTrade(refId):db.trade(refId);
  LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(18),dp(6),dp(18),dp(6));
  TextView help=new TextView(this);help.setText("실제 체결 가격을 기록합니다. 청산 전이면 매도가/시간은 비워두세요.\n가격 수익률과 배수 반영 예상 수익률은 별도로 표시됩니다. 수수료·펀딩·슬리피지·강제청산·증거금 방식은 미반영입니다.");
  help.setTextColor(Color.parseColor("#C2CEDC"));help.setTextSize(13);help.setLineSpacing(0,1.12f);box.addView(help);
  if(old!=null&&old.leverage<=0){TextView legacy=tradeLabel("기존 기록에 저장된 배수가 없습니다. 저장하면 선택한 배수가 적용됩니다.");legacy.setTextColor(Color.parseColor("#F7C948"));box.addView(legacy);}

  LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setGravity(Gravity.TOP);
  LinearLayout sideCol=new LinearLayout(this);sideCol.setOrientation(LinearLayout.VERTICAL);
  LinearLayout levCol=new LinearLayout(this);levCol.setOrientation(LinearLayout.VERTICAL);
  sideCol.addView(tradeLabel("포지션"));levCol.addView(tradeLabel("레버리지"));
  Spinner side=new Spinner(this),leverage=new Spinner(this);
  String[] sides={"LONG","SHORT"};side.setAdapter(coloredSideAdapter(sides));
  side.setSelection(old!=null&&"SHORT".equals(old.side)?1:(old==null&&dropEngine?1:0));
  side.setBackground(tradeBg("#133B2A","#3B9666"));side.setMinimumHeight(dp(52));
  leverage.setAdapter(new PfSpinnerAdapter(this,LeverageOptions.LABELS));
  leverage.setSelection(LeverageOptions.indexOf(old!=null&&old.leverage>0?old.leverage:50));
  leverage.setBackground(tradeBg("#1B2B3F","#45617F"));leverage.setMinimumHeight(dp(52));
  sideCol.addView(side,new LinearLayout.LayoutParams(-1,dp(52)));
  levCol.addView(leverage,new LinearLayout.LayoutParams(-1,dp(52)));
  LinearLayout.LayoutParams sideLp=new LinearLayout.LayoutParams(0,-2,1f),levLp=new LinearLayout.LayoutParams(0,-2,1f);sideLp.setMargins(0,0,dp(6),0);levLp.setMargins(dp(6),0,0,0);
  row.addView(sideCol,sideLp);row.addView(levCol,levLp);box.addView(row);
  side.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){
   public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){side.setBackground(pos==1?tradeBg("#4A2334","#B65A70"):tradeBg("#153B2B","#399866"));}
   public void onNothingSelected(android.widget.AdapterView<?> p){}
  });

  box.addView(tradeLabel("진입가"));EditText buy=new EditText(this);buy.setHint("예: 1.5920");buy.setInputType(android.text.InputType.TYPE_CLASS_NUMBER|android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);styleTradeInput(buy);if(old!=null)buy.setText(String.valueOf(old.buyPrice));box.addView(buy);
  box.addView(tradeLabel("진입시간"));EditText bt=new EditText(this);bt.setHint("yyyy-MM-dd HH:mm");styleTradeInput(bt);bt.setText(formatTradeTime(old!=null?old.buyTs:defaultTs));box.addView(bt);
  box.addView(tradeLabel("청산가"));EditText sell=new EditText(this);sell.setHint("보유중이면 비워두기");sell.setInputType(android.text.InputType.TYPE_CLASS_NUMBER|android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);styleTradeInput(sell);if(old!=null&&old.sellPrice>0)sell.setText(String.valueOf(old.sellPrice));box.addView(sell);
  box.addView(tradeLabel("청산시간"));EditText st=new EditText(this);st.setHint("yyyy-MM-dd HH:mm · 보유중이면 비움");styleTradeInput(st);if(old!=null&&old.sellTs>0)st.setText(formatTradeTime(old.sellTs));box.addView(st);
  ScrollView scroll=new ScrollView(this);scroll.setFillViewport(false);scroll.addView(box);
  AlertDialog.Builder b=new AlertDialog.Builder(this,android.R.style.Theme_Material_Dialog_Alert)
   .setTitle("💰 "+symbol+" 실제 매매 기록").setView(scroll).setNegativeButton("취소",null).setPositiveButton("저장",null);
  if(old!=null)b.setNeutralButton("기록삭제",null);
  AlertDialog dlg=b.create();dlg.setOnShowListener(z->{
   dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{try{
    double bp=Double.parseDouble(buy.getText().toString().trim());long bts=parseTradeTime(bt.getText().toString().trim());
    String ss=sell.getText().toString().trim(),ts=st.getText().toString().trim();
    Double sp=ss.isEmpty()?null:Double.parseDouble(ss);Long sts=ts.isEmpty()?null:parseTradeTime(ts);
    if(!Double.isFinite(bp)||bp<=0||bts<=0||(sp!=null&&(!Double.isFinite(sp)||sp<=0||sts==null||sts<bts))||(sp==null&&sts!=null)){
     Toast.makeText(this,"진입가/시간 또는 청산가/시간을 확인해줘",Toast.LENGTH_SHORT).show();return;
    }
    int selectedLeverage=LeverageOptions.valueAt(leverage.getSelectedItemPosition());
    if(dropEngine)db.saveDropTrade(refId,symbol,sides[side.getSelectedItemPosition()],selectedLeverage,bp,bts,sp,sts);
    else db.saveTrade(refId,symbol,sides[side.getSelectedItemPosition()],selectedLeverage,bp,bts,sp,sts);
    dlg.dismiss();render();Toast.makeText(this,"💰 "+sides[side.getSelectedItemPosition()]+" · "+selectedLeverage+"x 기록 저장",Toast.LENGTH_SHORT).show();
   }catch(Exception ex){Toast.makeText(this,"가격 또는 시간 형식을 확인해줘",Toast.LENGTH_SHORT).show();}});
   if(old!=null)dlg.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v->new AlertDialog.Builder(this)
    .setMessage("이 실제 매매 기록을 삭제할까?").setNegativeButton("취소",null)
    .setPositiveButton("삭제",(d,w)->{if(dropEngine)db.deleteDropTrade(refId);else db.deleteTrade(refId);dlg.dismiss();render();}).show());
  });dlg.show();
 }
 String formatTradeTime(long ts){return new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.KOREA).format(new Date(ts*1000));}
 long parseTradeTime(String s)throws Exception{return new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.KOREA).parse(s).getTime()/1000;}

 static String fmt(double v){return v>=1?String.format(Locale.US,"%,.4f",v):String.format(Locale.US,"%.8f",v);}
 static int surgeCol(String x){if(x.contains("후행차단"))return Color.parseColor("#98A2B3");if(x.contains("PRIME+"))return Color.parseColor("#C084FC");if(x.contains("PRIME"))return Color.parseColor("#FF5D73");if(x.contains("HOT"))return Color.parseColor("#FF9F43");if(x.contains("ALERT"))return Color.parseColor("#F7C948");return Color.parseColor("#36C5F0");}
 static int dropCol(String x){if(x.contains("후행차단"))return Color.parseColor("#98A2B3");if(x.contains("DROP RISK"))return Color.parseColor("#FF5D73");if(x.contains("REVERSAL"))return Color.parseColor("#FF8A65");if(x.contains("EXHAUST"))return Color.parseColor("#F7C948");return Color.parseColor("#36C5F0");}
 protected void onDestroy(){work.shutdownNow();if(db!=null)db.close();super.onDestroy();}

 SpannableString styled(String x,String[] stages,boolean dropMode){SpannableString sp=new SpannableString(x);for(String st:stages){int from=0;while(true){int a=x.indexOf(st,from);if(a<0)break;sp.setSpan(new ForegroundColorSpan(dropMode?dropCol(st):surgeCol(st)),a,a+st.length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);sp.setSpan(new StyleSpan(Typeface.BOLD),a,a+st.length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);from=a+st.length();}}java.util.regex.Matcher m=java.util.regex.Pattern.compile("[+-]\\d+(?:\\.\\d+)?%").matcher(x);while(m.find()){boolean plus=x.charAt(m.start())=='+';int c;if(dropMode)c=plus?Color.parseColor("#FF8A65"):Color.parseColor("#35D07F");else c=plus?Color.parseColor("#35D07F"):Color.parseColor("#FF5D73");sp.setSpan(new ForegroundColorSpan(c),m.start(),m.end(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);}// LONG/SHORT label is position identity; ROI sign remains independently green/red.
  for(String side:new String[]{"LONG","SHORT"}){
   int from=0;while((from=x.indexOf("💰 "+side,from))>=0){int a=from+3;sp.setSpan(new ForegroundColorSpan(positionColor("SHORT".equals(side))),a,a+side.length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);sp.setSpan(new StyleSpan(Typeface.BOLD),a,a+side.length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);from=a+side.length();}
  }
  java.util.regex.Matcher pnl=java.util.regex.Pattern.compile("(?:가격 수익률|배수 반영 예상) [+-]\\d+(?:\\.\\d+)?%").matcher(x);
  while(pnl.find()){String piece=pnl.group();int sign=piece.indexOf('+');if(sign<0)sign=piece.indexOf('-');if(sign<0)continue;int color=piece.charAt(sign)=='+'?Color.parseColor("#79EAB1"):Color.parseColor("#FFA8B6");sp.setSpan(new ForegroundColorSpan(color),pnl.start()+sign,pnl.end(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);sp.setSpan(new StyleSpan(Typeface.BOLD),pnl.start()+sign,pnl.end(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);}
  return sp;}

 void styleRatingButtons(Button up,Button down,int rating){up.setText(rating==1?"👍 추천됨":"👍 추천");down.setText(rating==-1?"👎 비추천됨":"👎 비추천");int upBg=rating==1?Color.parseColor("#164A34"):(rating==-1?Color.parseColor("#111B29"):Color.parseColor("#1A283A"));int downBg=rating==-1?Color.parseColor("#552733"):(rating==1?Color.parseColor("#111B29"):Color.parseColor("#1A283A"));int upFg=rating==1?Color.parseColor("#8AF0B3"):(rating==-1?Color.parseColor("#778396"):Color.parseColor("#E5EAF1"));int downFg=rating==-1?Color.parseColor("#FF93A2"):(rating==1?Color.parseColor("#778396"):Color.parseColor("#E5EAF1"));up.setBackgroundTintList(ColorStateList.valueOf(upBg));down.setBackgroundTintList(ColorStateList.valueOf(downBg));up.setTextColor(upFg);down.setTextColor(downFg);up.setAlpha(1f);down.setAlpha(1f);}
 void styleTradeButton(Button trade,TextView badge,PulseDb.TradeRow tr){
  if(tr==null){badge.setVisibility(View.GONE);trade.setText("💰 실제 매매 기록");trade.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#1A283A")));trade.setTextColor(Color.parseColor("#E5EAF1"));return;}
  boolean shortSide="SHORT".equals(tr.side);
  badge.setVisibility(View.VISIBLE);badge.setText((shortSide?"SHORT":"LONG")+(tr.leverage>0?"  "+tr.leverage+"x":"  배수 미입력"));
  badge.setTextColor(positionColor(shortSide));
  badge.setBackground(tradeBg(shortSide?"#4A2334":"#153B2B",shortSide?"#B65A70":"#399866"));
  if(tr.closed()){
   double rr=tr.leveragedReturnPct();boolean available=!Double.isNaN(rr);
   trade.setText(available?"배수 반영 예상 "+String.format(Locale.US,"%+.2f%%",rr):"가격 "+String.format(Locale.US,"%+.2f%%",tr.priceReturnPct()));
   boolean profit=(available?rr:tr.priceReturnPct())>=0;
   trade.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor(profit?"#174634":"#4E2835")));
   trade.setTextColor(Color.parseColor(profit?"#A3F3C4":"#FFB3BD"));
  }else{trade.setText("💰 보유중 · 기록 보기");trade.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#29374B")));trade.setTextColor(Color.parseColor("#DFE8F5"));}
 }

 class SurgeHistAdapter extends ArrayAdapter<String>{
  SurgeHistAdapter(Context c,ArrayList<String>x){super(c,R.layout.alert_history_row,R.id.rowText,x);}
  public View getView(int pos,View v,android.view.ViewGroup parent){if(v==null)v=getLayoutInflater().inflate(R.layout.alert_history_row,parent,false);TextView t=v.findViewById(R.id.rowText);Button up=v.findViewById(R.id.rateUp),down=v.findViewById(R.id.rateDown),trade=v.findViewById(R.id.tradeBtn);TextView badge=v.findViewById(R.id.positionBadge);up.setVisibility(View.VISIBLE);down.setVisibility(View.VISIBLE);trade.setVisibility(View.VISIBLE);String x=getItem(pos);t.setText(styled(x,new String[]{"후행차단","PRIME+","EARLY WATCH","ALERT","HOT","PRIME"},false));PulseDb.AlertRow r=rows.get(pos);styleRatingButtons(up,down,r.userRating);PulseDb.TradeRow tr=db.trade(r.id);styleTradeButton(trade,badge,tr);up.setOnClickListener(z->{rememberAnchor(r.id,pos,false);rate(r,1);});down.setOnClickListener(z->{rememberAnchor(r.id,pos,false);rate(r,-1);});trade.setOnClickListener(z->{rememberAnchor(r.id,pos,false);editTrade(r);});t.setOnClickListener(z->{rememberAnchor(r.id,pos,false);openDetail(r);});return v;}
 }
 class DropHistAdapter extends ArrayAdapter<String>{
  DropHistAdapter(Context c,ArrayList<String>x){super(c,R.layout.alert_history_row,R.id.rowText,x);}
  public View getView(int pos,View v,android.view.ViewGroup parent){if(v==null)v=getLayoutInflater().inflate(R.layout.alert_history_row,parent,false);TextView t=v.findViewById(R.id.rowText);Button up=v.findViewById(R.id.rateUp),down=v.findViewById(R.id.rateDown),trade=v.findViewById(R.id.tradeBtn);TextView badge=v.findViewById(R.id.positionBadge);up.setVisibility(View.VISIBLE);down.setVisibility(View.VISIBLE);trade.setVisibility(View.VISIBLE);String x=getItem(pos);t.setText(styled(x,new String[]{"후행차단","DROP RISK","REVERSAL","EXHAUST","TOP WATCH"},true));PulseDb.DropRow r=dropRows.get(pos);styleRatingButtons(up,down,r.userRating);PulseDb.TradeRow tr=db.dropTrade(r.id);styleTradeButton(trade,badge,tr);up.setOnClickListener(z->{rememberAnchor(r.id,pos,true);rateDrop(r,1);});down.setOnClickListener(z->{rememberAnchor(r.id,pos,true);rateDrop(r,-1);});trade.setOnClickListener(z->{rememberAnchor(r.id,pos,true);editDropTrade(r);});t.setOnClickListener(z->{rememberAnchor(r.id,pos,true);openDropDetail(r);});return v;}
 }
}
