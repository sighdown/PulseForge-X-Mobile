package com.pulseforge.xmobile;
import android.app.*;import android.os.*;import android.content.*;import android.widget.*;
public class SettingsActivity extends Activity{
 CheckBox early,alert,hot,prime,lev;Spinner minLev;
 public void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_settings);early=findViewById(R.id.early);alert=findViewById(R.id.alert);hot=findViewById(R.id.hot);prime=findViewById(R.id.prime);lev=findViewById(R.id.levEnabled);minLev=findViewById(R.id.minLev);
  String[] ls={"5x","10x","20x","25x","50x","75x","100x","125x"};minLev.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,ls));
  android.content.SharedPreferences p=getSharedPreferences("settings",0);early.setChecked(p.getBoolean("EARLY",false));alert.setChecked(p.getBoolean("ALERT",true));hot.setChecked(p.getBoolean("HOT",true));prime.setChecked(p.getBoolean("PRIME",true));minLev.setSelection(p.getInt("MIN_LEV_INDEX",4));lev.setChecked(p.getBoolean("LEV_ENABLED",false));lev.setEnabled(false);minLev.setEnabled(false);
  findViewById(R.id.save).setOnClickListener(v->{p.edit().putBoolean("EARLY",early.isChecked()).putBoolean("ALERT",alert.isChecked()).putBoolean("HOT",hot.isChecked()).putBoolean("PRIME",prime.isChecked()).putInt("MIN_LEV_INDEX",minLev.getSelectedItemPosition()).apply();Toast.makeText(this,"알림 설정 저장 완료",Toast.LENGTH_SHORT).show();finish();});findViewById(R.id.back).setOnClickListener(v->finish());
 }
}
