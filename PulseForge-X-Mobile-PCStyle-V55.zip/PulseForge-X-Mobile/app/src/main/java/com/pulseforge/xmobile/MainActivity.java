package com.pulseforge.xmobile;

import android.app.*;import android.os.*;import android.content.*;import android.content.pm.PackageManager;import android.graphics.Color;import android.widget.*;

public class MainActivity extends Activity{
 TextView status,candidates,lastScan,symbolCount; Button start,stop,settings; BroadcastReceiver rx;
 public void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_main);
  status=findViewById(R.id.status);candidates=findViewById(R.id.candidates);lastScan=findViewById(R.id.lastScan);symbolCount=findViewById(R.id.symbolCount);start=findViewById(R.id.start);stop=findViewById(R.id.stop);settings=findViewById(R.id.settings);
  start.setOnClickListener(v->start()); stop.setOnClickListener(v->stop()); settings.setOnClickListener(v->startActivity(new Intent(this,SettingsActivity.class)));
  rx=new BroadcastReceiver(){public void onReceive(Context c,Intent i){String s=i.getStringExtra("status");if(s!=null){status.setText(s);if(s.startsWith("정상")){status.setText("● 감시 중");status.setTextColor(Color.parseColor("#35D07F"));}else if(s.startsWith("수집 오류")){status.setText("● 수집 오류");status.setTextColor(Color.parseColor("#FF5D73"));}}
   String r=i.getStringExtra("rows");if(r!=null)candidates.setText(r);String tm=i.getStringExtra("time");if(tm!=null)lastScan.setText("마지막 수집  "+tm);int n=i.getIntExtra("count",-1);if(n>=0)symbolCount.setText("수집 종목  "+n+"개");};};
  if(Build.VERSION.SDK_INT>=33&&checkSelfPermission("android.permission.POST_NOTIFICATIONS")!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"},1);
  if(ScanService.runningNow){showRunning();}else showIdle();
 }
 void start(){startForegroundService(new Intent(this,ScanService.class));status.setText("● 수집 준비 중…");status.setTextColor(Color.parseColor("#F7C948"));start.setText("감시 시작됨");start.setEnabled(false);}
 void stop(){stopService(new Intent(this,ScanService.class));showIdle();status.setText("● 감시 중지");}
 void showRunning(){status.setText("● 감시 중");status.setTextColor(Color.parseColor("#35D07F"));start.setText("감시 중");start.setEnabled(false);}
 void showIdle(){status.setText("● 대기 중");status.setTextColor(Color.parseColor("#98A2B3"));start.setText("60초 감시 시작");start.setEnabled(true);}
 protected void onResume(){super.onResume();IntentFilter f=new IntentFilter(ScanService.ACTION);if(Build.VERSION.SDK_INT>=33)registerReceiver(rx,f,RECEIVER_NOT_EXPORTED);else registerReceiver(rx,f);if(ScanService.runningNow)showRunning();}
 protected void onPause(){super.onPause();try{unregisterReceiver(rx);}catch(Exception ignored){}}
}
