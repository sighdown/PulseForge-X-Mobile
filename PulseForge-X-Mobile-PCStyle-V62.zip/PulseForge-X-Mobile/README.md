# PulseForge X Mobile V6.2

PulseForge X Android build focused on the original goal: detect pre-move conditions rather than merely reporting coins after a surge.

## V6.2 highlights
- TOP SIGNALS now has a persistent multi-select stage filter for EARLY WATCH / ALERT / HOT / PRIME.
- Stage selection works together with the existing leverage ranking filter, so combinations such as `50x+ + HOT/PRIME` are supported.
- Alert History now uses a persistent multi-select filter for EARLY WATCH / ALERT / HOT / PRIME / 후행차단.
- Existing V6.0 single Alert History filter preference is migrated to the new multi-select format on first launch.
- Alert History multi-stage queries retrieve up to 2,000 records.
- Display filters remain independent from push-notification settings and do not stop full-symbol scanning, DB collection, or post-scoring.
- Existing V6 anti-late logic, Binance Futures direct open, HMAC API / Android Keystore, leverage cache/filter, multi-timeframe chart, alert markers, post-score outcomes and MFE/MAE remain intact.

## Security
- Never place Binance API credentials in source code, GitHub, ZIP files, screenshots, or chat.
- Credentials are entered only on-device and encrypted with Android Keystore.
