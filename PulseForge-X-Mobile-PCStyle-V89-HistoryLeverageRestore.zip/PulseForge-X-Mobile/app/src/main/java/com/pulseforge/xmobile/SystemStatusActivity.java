package com.pulseforge.xmobile;

import android.app.*;
import android.os.*;
import android.content.*;
import android.net.*;
import android.widget.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.zip.*;
import org.json.*;

public class SystemStatusActivity extends Activity{
 TextView info,backupStatus; Button backup;
 Handler h=new Handler(Looper.getMainLooper());
 Runnable tick=new Runnable(){public void run(){render();h.postDelayed(this,1000);}};
 static final int[] LEVS={5,10,20,25,50,75,100,125};
 static final int REQ_BACKUP=8601;

 public void onCreate(Bundle b){
  super.onCreate(b);setContentView(R.layout.activity_system_status);info=findViewById(R.id.info);backup=findViewById(R.id.backupExport);backupStatus=findViewById(R.id.backupStatus);findViewById(R.id.back).setOnClickListener(v->finish());backup.setOnClickListener(v->chooseBackup());h.post(tick);
 }

 void render(){
  PulseDb db=new PulseDb(this);PulseDb.Stats s=db.stats();PulseDb.LeverageStats ls=db.leverageStats();db.close();
  SharedPreferences r=getSharedPreferences("runtime",0),p=getSharedPreferences("settings",0);
  long now=System.currentTimeMillis(),last=r.getLong("last_success_ms",0),start=r.getLong("service_start_ms",0);
  long age=last>0?(now-last)/1000:-1,up=start>0?(now-start)/1000:0;
  boolean svc=ScanService.runningNow||r.getBoolean("service_running",false);
  String state=svc?(age>=0&&age<=110?"정상 감시 중":"감시 중 · 갱신 확인 필요"):"중지";
  String stages=(p.getBoolean("EARLY",false)?"EARLY ":"")+(p.getBoolean("ALERT",false)?"ALERT ":"")+(p.getBoolean("HOT",true)?"HOT ":"")+(p.getBoolean("PRIME",true)?"PRIME ":"")+(p.getBoolean("PRIME_PLUS",p.getBoolean("PRIME",true))?"PRIME+":"");
  String dropPush=(p.getBoolean("DROP_NOTIFY_TOP",false)?"TOP WATCH ":"")+(p.getBoolean("DROP_NOTIFY_EXHAUST",false)?"EXHAUST ":"")+(p.getBoolean("DROP_NOTIFY_REVERSAL",true)?"REVERSAL ":"")+(p.getBoolean("DROP_NOTIFY_RISK",true)?"DROP RISK":"");if(dropPush.trim().isEmpty())dropPush="OFF";
  if(stages.trim().isEmpty())stages="모두 OFF";
  boolean levOn=p.getBoolean("LEV_ENABLED",false);
  int li=Math.max(0,Math.min(LEVS.length-1,p.getInt("MIN_LEV_INDEX",4)));
  int ri=Math.max(0,Math.min(8,p.getInt("RANK_LEV_INDEX",0)));
  String api=ApiCredentialStore.exists(this)?"연결정보 저장됨":"미연결";
  long levAgeMin=ls.updatedTs>0?Math.max(0,(System.currentTimeMillis()/1000-ls.updatedTs)/60):-1;
  String levCache=ls.count>0?ls.count+"종목 · "+fmtDate(ls.updatedTs*1000)+" · "+levAgeMin+"분 전":"없음";
  String rankFilter=ri==0?"전체":LEVS[ri-1]+"x 이상";
  ArrayList<String> rs=new ArrayList<>();if(p.getBoolean("RANK_STAGE_EARLY",true))rs.add("EARLY");if(p.getBoolean("RANK_STAGE_ALERT",true))rs.add("ALERT");if(p.getBoolean("RANK_STAGE_HOT",true))rs.add("HOT");if(p.getBoolean("RANK_STAGE_PRIME",true))rs.add("PRIME");if(p.getBoolean("RANK_STAGE_PRIME_PLUS",p.getBoolean("RANK_STAGE_PRIME",true)))rs.add("PRIME+");String rankStages=rs.size()==5?"전체":(rs.isEmpty()?"선택 없음":android.text.TextUtils.join(" + ",rs));
  String levFilter=levOn?LEVS[li]+"x 이상":"OFF";
  String levErr=r.getString("leverage_last_error","");
  String blockedSym=r.getString("leverage_last_blocked_symbol","");int blockedMax=r.getInt("leverage_last_blocked_max",0),blockedMin=r.getInt("leverage_last_blocked_min",0);long blockedMs=r.getLong("leverage_last_blocked_ms",0);

  StringBuilder b=new StringBuilder();
  b.append("실시간 수집 상태  ").append(state)
   .append("\n마지막 정상 스캔  ").append(last>0?fmtTime(last):"-")
   .append("\n마지막 스캔 경과  ").append(age>=0?age+"초":"-")
   .append("\n서비스 가동시간  ").append(fmtDur(up))
   .append("\n\n원시 스캔 DB  ").append(String.format(Locale.US,"%,d",s.rows)).append("행")
   .append("\n분석 회차  ").append(String.format(Locale.US,"%,d",s.scans)).append("회")
   .append("\n알림 신호 기록  ").append(String.format(Locale.US,"%,d",s.alerts)).append("건")
   .append("\n후행차단 기록  ").append(String.format(Locale.US,"%,d",s.suppressed)).append("건")
   .append("\n사후채점 완료  ").append(String.format(Locale.US,"%,d",s.outcomes)).append("개 구간")
   .append("\n급등 역추적 이벤트  ").append(String.format(Locale.US,"%,d",s.surgeEvents)).append("건")
   .append("\n선행 템플릿  ").append(String.format(Locale.US,"%,d",s.leadTemplates)).append("건")
   .append("\n급락 위험 신호  ").append(String.format(Locale.US,"%,d",s.dropSignals)).append("건")
   .append("\n급락 사후검증  ").append(String.format(Locale.US,"%,d",s.dropOutcomes)).append("개 구간")
   .append("\nDB 크기  ").append(String.format(Locale.US,"%.1f MB",s.dbBytes/1048576.0))
   .append("\nDB 기록 범위  ").append(s.firstTs>0?fmtDate(s.firstTs*1000):"-").append(" ~ ").append(s.lastTs>0?fmtDate(s.lastTs*1000):"-")
   .append("\n\n알림 단계  ").append(stages.trim())
   .append("\n재알림 쿨다운  ").append(p.getInt("COOLDOWN_MIN",60)).append("분")
   .append("\n연속 확인  ").append(p.getInt("CONFIRMATIONS",2)).append("회")
   .append("\n단계 상승 즉시 알림  ").append(p.getBoolean("ESCALATION_IMMEDIATE",true)?"ON":"OFF")
   .append("\n같은 단계 반복  ").append(p.getBoolean("SAME_STAGE_REPEAT",false)?"ON":"OFF")
   .append("\n\nBinance API  ").append(api)
   .append("\n레버리지 캐시  ").append(levCache)
   .append("\nTOP SIGNAL 단계  ").append(rankStages)
   .append("\n순위 최소배수  ").append(rankFilter)
   .append("\n레버리지 알림필터  ").append(levFilter)
   .append("\n알림 직전 배수검증  ").append(levOn?"ON · 실시간 재확인":"OFF");
  if(!blockedSym.isEmpty()&&blockedMs>0)b.append("\n최근 배수차단  ").append(blockedSym).append(" · 최대 ").append(blockedMax>0?blockedMax+"x":"확인실패").append(" < ").append(blockedMin).append("x · ").append(fmtDate(blockedMs));
  if(!levErr.isEmpty())b.append("\n최근 API 오류  ").append(levErr);
  b.append("\n\n급등 모델  ").append(ScoreEngine.MODEL_VERSION).append(" · 선행포착/역추적/후행차단");
  b.append("\n급락 모델  ").append(ScoreEngine.DROP_MODEL_VERSION).append(" · 고점과열/소진/반전 · 현재 순위/검증 모드");
  b.append("\n※ 원시 스캔은 최근 12시간 유지 · 6/8/12/24시간 장기 사후채점은 Binance 과거 캔들로 보완해 DB 용량 증가를 최소화합니다.");
  info.setText(b.toString());
 }

 void chooseBackup(){
  Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/zip");String name="PulseForge_Backup_"+new java.text.SimpleDateFormat("yyyyMMdd_HHmm",Locale.KOREA).format(new Date())+".zip";i.putExtra(Intent.EXTRA_TITLE,name);startActivityForResult(i,REQ_BACKUP);
 }
 protected void onActivityResult(int req,int result,Intent data){super.onActivityResult(req,result,data);if(req!=REQ_BACKUP||result!=RESULT_OK||data==null||data.getData()==null)return;Uri uri=data.getData();final boolean wasRunning=ScanService.runningNow||getSharedPreferences("runtime",0).getBoolean("service_running",false);backup.setEnabled(false);backupStatus.setText("백업 준비 중… 감시가 켜져 있으면 잠깐 멈춘 뒤 자동 재시작합니다.");h.removeCallbacks(tick);if(wasRunning)stopService(new Intent(this,ScanService.class));new Thread(()->{String msg;try{if(wasRunning)Thread.sleep(900);exportBackup(uri);msg="백업 완료 · 선택한 위치에 ZIP 저장됨";}catch(Exception e){msg="백업 실패 · "+e.getClass().getSimpleName();}finally{if(wasRunning){try{startForegroundService(new Intent(this,ScanService.class));}catch(Exception ignored){}}}final String m=msg;runOnUiThread(()->{backup.setEnabled(true);backupStatus.setText(m+"\n※ Binance API Key/Secret은 보안상 백업에서 제외됩니다.");h.post(tick);});}).start();}
 void exportBackup(Uri uri)throws Exception{
  PulseDb db=new PulseDb(this);db.checkpointForBackup();db.close();File f=getDatabasePath("pulseforge_mobile.db");if(!f.exists())throw new FileNotFoundException("database");OutputStream raw=getContentResolver().openOutputStream(uri,"w");if(raw==null)throw new IOException("output");try(ZipOutputStream z=new ZipOutputStream(new BufferedOutputStream(raw))){addFile(z,"pulseforge_mobile.db",f);JSONObject meta=new JSONObject();meta.put("format","PulseForgeBackup");meta.put("format_version",1);meta.put("exported_at",System.currentTimeMillis());meta.put("db_version",PulseDb.DB_VERSION);meta.put("app_version",appVersion());JSONArray hs=new JSONArray();for(int x:PulseDb.HORIZONS)hs.put(x);meta.put("outcome_horizons_min",hs);meta.put("api_credentials_included",false);addText(z,"metadata.json",meta.toString(2));addText(z,"preferences.json",preferencesJson().toString(2));addText(z,"README.txt","PulseForge X 모바일 데이터 백업입니다.\n- pulseforge_mobile.db: 분석/알림/사후채점/실제매매/후행차단 데이터\n- preferences.json: 화면/필터/알림 설정(일부)\n- Binance API Key/Secret: 보안상 포함하지 않음\n향후 보조 PC 연동/복원 기능에서 사용할 수 있도록 원본 SQLite DB를 포함합니다.\n");}}
 void addFile(ZipOutputStream z,String name,File f)throws Exception{z.putNextEntry(new ZipEntry(name));try(InputStream in=new BufferedInputStream(new FileInputStream(f))){byte[] buf=new byte[16384];for(int n;(n=in.read(buf))>0;)z.write(buf,0,n);}z.closeEntry();}
 void addText(ZipOutputStream z,String name,String text)throws Exception{z.putNextEntry(new ZipEntry(name));z.write(text.getBytes(StandardCharsets.UTF_8));z.closeEntry();}
 JSONObject preferencesJson()throws Exception{JSONObject root=new JSONObject();for(String name:new String[]{"settings","ui_state","prediction_stats"}){JSONObject o=new JSONObject();Map<String,?> all=getSharedPreferences(name,0).getAll();for(Map.Entry<String,?>e:all.entrySet()){Object v=e.getValue();if(v instanceof Set){JSONArray a=new JSONArray();for(Object q:(Set<?>)v)a.put(String.valueOf(q));o.put(e.getKey(),a);}else if(v!=null)o.put(e.getKey(),v);}root.put(name,o);}return root;}
 String appVersion(){try{return getPackageManager().getPackageInfo(getPackageName(),0).versionName;}catch(Exception e){return "0.8.9";}}

 String fmtTime(long ms){return new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.KOREA).format(new Date(ms));}
 String fmtDate(long ms){return new java.text.SimpleDateFormat("MM/dd HH:mm",Locale.KOREA).format(new Date(ms));}
 String fmtDur(long s){long h=s/3600,m=(s%3600)/60,ss=s%60;return h+"시간 "+m+"분 "+ss+"초";}
 protected void onDestroy(){h.removeCallbacks(tick);super.onDestroy();}
}
