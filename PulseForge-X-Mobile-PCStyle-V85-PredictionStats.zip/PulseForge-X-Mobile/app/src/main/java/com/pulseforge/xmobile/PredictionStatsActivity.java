package com.pulseforge.xmobile;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;
import java.util.*;
import java.util.concurrent.*;

public class PredictionStatsActivity extends Activity{
 Spinner period,horizon;
 Button back,refresh;
 TextView summary,subtitle,status;
 LinearLayout surgeBox,dropBox,blockedBox;
 PulseDb db;
 SharedPreferences pref;
 ExecutorService work=Executors.newSingleThreadExecutor();
 int requestSeq=0;
 final int[] DAYS={7,30,0};
 final String[] PERIOD_LABELS={"최근 7일","최근 30일","전체"};
 final int[] HORIZONS={5,15,30,60,120,240};
 final String[] HORIZON_LABELS={"5분","15분","30분","1시간","2시간","4시간"};

 public void onCreate(Bundle b){
  super.onCreate(b);setContentView(R.layout.activity_prediction_stats);
  back=findViewById(R.id.back);refresh=findViewById(R.id.refresh);period=findViewById(R.id.period);horizon=findViewById(R.id.horizon);summary=findViewById(R.id.summary);subtitle=findViewById(R.id.subtitle);status=findViewById(R.id.status);surgeBox=findViewById(R.id.surgeBox);dropBox=findViewById(R.id.dropBox);blockedBox=findViewById(R.id.blockedBox);
  db=new PulseDb(this);pref=getSharedPreferences("prediction_stats",0);
  period.setAdapter(new PfSpinnerAdapter(this,PERIOD_LABELS));horizon.setAdapter(new PfSpinnerAdapter(this,HORIZON_LABELS));
  period.setSelection(Math.max(0,Math.min(PERIOD_LABELS.length-1,pref.getInt("PERIOD",1))));horizon.setSelection(Math.max(0,Math.min(HORIZON_LABELS.length-1,pref.getInt("HORIZON",3))));
  back.setOnClickListener(v->finish());refresh.setOnClickListener(v->load());
  android.widget.AdapterView.OnItemSelectedListener l=new android.widget.AdapterView.OnItemSelectedListener(){public void onItemSelected(android.widget.AdapterView<?>p,View v,int pos,long id){pref.edit().putInt(p==period?"PERIOD":"HORIZON",pos).apply();load();}public void onNothingSelected(android.widget.AdapterView<?>p){}};
  period.setOnItemSelectedListener(l);horizon.setOnItemSelectedListener(l);
  subtitle.setText("기본 적중 = 선택 시간 안 급등 +3% / 급락 -3% 도달 · 미판정은 적중률 분모에서 제외");
  load();
 }

 void load(){
  final int seq=++requestSeq;final int d=DAYS[Math.max(0,period.getSelectedItemPosition())],h=HORIZONS[Math.max(0,horizon.getSelectedItemPosition())];
  status.setText("통계 계산 중…");refresh.setEnabled(false);
  work.submit(()->{PulseDb.PredictionStats s=null;Exception err=null;try{s=db.predictionStats(d,h);}catch(Exception e){err=e;}final PulseDb.PredictionStats result=s;final Exception problem=err;runOnUiThread(()->{if(seq!=requestSeq)return;refresh.setEnabled(true);if(problem!=null||result==null){status.setText("통계를 불러오지 못했습니다.");return;}render(result);});});
 }

 void render(PulseDb.PredictionStats s){
  surgeBox.removeAllViews();dropBox.removeAllViews();blockedBox.removeAllViews();
  long st=0,se=0,ss=0,dt=0,de=0,ds=0;
  for(PulseDb.PredictionStageStats x:s.surge){st+=x.total;se+=x.evaluated;ss+=x.success();addStageCard(surgeBox,x,false);}
  for(PulseDb.PredictionStageStats x:s.drop){dt+=x.total;de+=x.evaluated;ds+=x.success();addStageCard(dropBox,x,true);}
  String surgeRate=rate(ss,se),dropRate=rate(ds,de);long eval=se+de,total=st+dt;
  summary.setText("🚀 급등 적중  "+surgeRate+"   ·   ⚠ 급락 적중  "+dropRate+"\n판정 완료 "+eval+"건 / 대상 "+total+"건   ·   "+periodLabel()+" · "+horizonLabel());
  status.setText("기준: 3% 도달 여부 · 표본이 적을수록 수치는 크게 흔들릴 수 있습니다.");
  addBlockedCard(blockedBox,"🚀 급등 후행차단",s.surgeBlocked,false);
  addBlockedCard(blockedBox,"⚠ 급락 후행차단",s.dropBlocked,true);
 }

 void addStageCard(LinearLayout parent,PulseDb.PredictionStageStats x,boolean drop){
  LinearLayout card=card();TextView title=text(x.stage,18,true,stageColor(x.stage));card.addView(title);
  if(x.evaluated<=0){card.addView(text("판정 완료 표본이 아직 없습니다.\n발생 "+x.total+"건 · 미판정/데이터 부족 "+x.pending()+"건",13,false,Color.parseColor("#A9B7C8")));parent.addView(card);return;}
  String base=(drop?"-3%":"+3%")+" 기준  적중 "+rate(x.success(),x.evaluated)+" · 빗나감(3% 미달) "+rate(x.miss(),x.evaluated);
  TextView primary=text(base,16,true,Color.parseColor(rateColor(x.success(),x.evaluated)));card.addView(primary);
  String targets=(drop?"도달률  -2% ":"도달률  +2% ")+rate(x.hit2,x.evaluated)+(drop?" · -3% ":" · +3% ")+rate(x.hit3,x.evaluated)+(drop?" · -5% ":" · +5% ")+rate(x.hit5,x.evaluated)+(drop?" · -8% ":" · +8% ")+rate(x.hit8,x.evaluated);
  card.addView(text(targets,13,false,Color.parseColor("#D8E2EE")));
  String movement=drop?"평균 최대하락 "+pct(x.avgFav)+" · 역행상승 "+pct(x.avgAgainst):"평균 최대상승 "+pct(x.avgFav)+" · 역행하락 "+pct(x.avgAgainst);
  card.addView(text(movement,13,false,Color.parseColor("#B7C8DD")));
  card.addView(text("발생 "+x.total+"건 · 판정 완료 "+x.evaluated+"건 · 미판정/데이터 부족 "+x.pending()+"건",12,false,Color.parseColor("#7F8EA3")));
  parent.addView(card);
 }

 void addBlockedCard(LinearLayout parent,String title,PulseDb.BlockedPredictionStats x,boolean drop){
  LinearLayout card=card();card.addView(text(title,16,true,Color.parseColor("#C4CDD8")));
  if(x.evaluated<=0){card.addView(text("차단 "+x.total+"건 · 판정 가능한 표본 없음",13,false,Color.parseColor("#8D9BAD")));parent.addView(card);return;}
  String target=drop?"-3%":"+3%";
  card.addView(text("차단 후에도 "+target+" 도달 "+rate(x.targetHit,x.evaluated)+" · 미도달 "+rate(x.targetMiss(),x.evaluated),13,true,Color.parseColor("#D8E2EE")));
  card.addView(text("차단 "+x.total+"건 · 판정 완료 "+x.evaluated+"건 · 미판정/데이터 부족 "+x.pending()+"건\n※ 목표 도달률이 높으면 놓친 신호가 많았다는 뜻이라 차단 기준 재검토에 활용합니다.",12,false,Color.parseColor("#7F8EA3")));
  parent.addView(card);
 }

 LinearLayout card(){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(dp(15),dp(13),dp(15),dp(13));GradientDrawable g=new GradientDrawable();g.setColor(Color.parseColor("#111D2E"));g.setCornerRadius(dp(12));g.setStroke(dp(1),Color.parseColor("#263A52"));c.setBackground(g);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,0,0,dp(10));c.setLayoutParams(lp);return c;}
 TextView text(String s,int sp,boolean bold,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(sp);t.setTextColor(color);t.setLineSpacing(0,1.14f);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(2),0,dp(3));t.setLayoutParams(lp);return t;}
 String rate(long hit,long n){return n<=0?"-":String.format(Locale.US,"%.1f%%",hit*100.0/n);}
 String pct(double v){return String.format(Locale.US,"%+.2f%%",v);}
 String periodLabel(){return PERIOD_LABELS[Math.max(0,period.getSelectedItemPosition())];}
 String horizonLabel(){return HORIZON_LABELS[Math.max(0,horizon.getSelectedItemPosition())];}
 String rateColor(long hit,long n){if(n<=0)return "#A9B7C8";double r=hit*100.0/n;return r>=70?"#79EAB1":r>=50?"#F7C948":"#FFA8B6";}
 int stageColor(String s){if("PRIME+".equals(s))return Color.parseColor("#C084FC");if("PRIME".equals(s))return Color.parseColor("#FF5D73");if("HOT".equals(s))return Color.parseColor("#FF9F43");if("DROP RISK".equals(s))return Color.parseColor("#FF5D73");if("REVERSAL".equals(s))return Color.parseColor("#FF8A65");return Color.parseColor("#9CC3FF");}
 int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}
 protected void onDestroy(){requestSeq++;work.shutdownNow();if(db!=null)db.close();super.onDestroy();}
}
