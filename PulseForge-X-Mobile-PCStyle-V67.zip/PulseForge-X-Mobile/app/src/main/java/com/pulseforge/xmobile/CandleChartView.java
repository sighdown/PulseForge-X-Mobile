package com.pulseforge.xmobile;

import android.content.*;
import android.util.*;
import android.graphics.*;
import android.view.*;
import java.text.*;
import java.util.*;

public class CandleChartView extends View {
 public static class Candle {
  public long openTime; public double open,high,low,close;
  public Candle(long t,double o,double h,double l,double c){openTime=t;open=o;high=h;low=l;close=c;}
 }

 private List<Candle> d=new ArrayList<>();
 private long markerTs=0; private boolean showMarker=true;
 private double alertPrice=0.0;
 private final Paint grid=new Paint(1),up=new Paint(1),down=new Paint(1),wick=new Paint(1),marker=new Paint(1),text=new Paint(1),axisBg=new Paint(1),labelBg=new Paint(1),cross=new Paint(1),strongText=new Paint(1);
 private ScaleGestureDetector scaleDetector;
 private GestureDetector gestureDetector;
 private float visibleCount=72f, startIndex=0f, lastX=0f;
 private boolean dragging=false, crosshair=false;
 private float crossX=0f,crossY=0f;
 private boolean olderRequested=false;
 public interface OnNeedOlderListener{void onNeedOlder(long oldestOpenTime);}
 private OnNeedOlderListener olderListener;
 private static final float MIN_VISIBLE=12f;
 private static final float AXIS_R=92f, AXIS_B=38f, PAD=10f;

 public CandleChartView(Context c,AttributeSet a){
  super(c,a);
  grid.setColor(Color.rgb(38,52,72)); grid.setStrokeWidth(1);
  up.setColor(Color.rgb(53,208,127)); down.setColor(Color.rgb(255,93,115));
  wick.setStrokeWidth(2);
  marker.setColor(Color.rgb(255,93,115)); marker.setStrokeWidth(3);
  text.setColor(Color.rgb(152,162,179)); text.setTextSize(20);
  strongText.setColor(Color.rgb(238,242,247)); strongText.setTextSize(20); strongText.setFakeBoldText(true);
  axisBg.setColor(Color.rgb(17,29,46));
  labelBg.setColor(Color.rgb(37,49,66));
  cross.setColor(Color.rgb(190,198,210)); cross.setStrokeWidth(1.4f);
  setFocusable(true); setClickable(true);

  scaleDetector=new ScaleGestureDetector(c,new ScaleGestureDetector.SimpleOnScaleGestureListener(){
   public boolean onScale(ScaleGestureDetector detector){
    crosshair=false;
    if(d.isEmpty()) return false;
    float factor=detector.getScaleFactor();
    if(factor<=0) return false;
    zoomAt(factor, detector.getFocusX());
    return true;
   }
  });
  gestureDetector=new GestureDetector(c,new GestureDetector.SimpleOnGestureListener(){
   public boolean onDoubleTap(MotionEvent e){crosshair=false;resetZoom();return true;}
   public void onLongPress(MotionEvent e){
    if(d.isEmpty())return;
    crosshair=true;dragging=false;crossX=e.getX();crossY=e.getY();clampCross();invalidate();
   }
  });
 }

 public void setData(List<Candle>x){d=x==null?new ArrayList<>():x;olderRequested=false;crosshair=false;resetZoom();}
 public void setAlertReference(double p){alertPrice=p;invalidate();}
 public void setOnNeedOlderListener(OnNeedOlderListener l){olderListener=l;}
 public void olderLoadFinished(){olderRequested=false;}
 public int prependData(List<Candle>x){
  if(x==null||x.isEmpty()){olderRequested=false;return 0;}
  long first=d.isEmpty()?Long.MAX_VALUE:d.get(0).openTime;
  ArrayList<Candle> add=new ArrayList<>();
  for(Candle c:x)if(c.openTime<first)add.add(c);
  if(add.isEmpty()){olderRequested=false;return 0;}
  d.addAll(0,add);startIndex+=add.size();olderRequested=false;invalidate();return add.size();
 }
 public void setMarker(long ts,boolean show){markerTs=ts;showMarker=show;invalidate();}
 public void resetZoom(){visibleCount=Math.max(MIN_VISIBLE,d.size());startIndex=0f;crosshair=false;invalidate();}
 public void zoomIn(){crosshair=false;zoomAt(1.35f,getWidth()/2f);}
 public void zoomOut(){crosshair=false;zoomAt(1f/1.35f,getWidth()/2f);}

 private void zoomAt(float factor,float focusX){
  if(d.isEmpty())return;
  float before=visibleCount;
  float after=before/factor;
  float max=Math.max(MIN_VISIBLE,d.size());
  after=Math.max(MIN_VISIBLE,Math.min(max,after));
  float plotW=Math.max(1,getWidth()-AXIS_R);
  float ratio=Math.max(0,Math.min(1,focusX/plotW));
  float focusIndex=startIndex+ratio*before;
  visibleCount=after;
  startIndex=focusIndex-ratio*after;
  clampWindow();invalidate();
 }

 private void clampCross(){
  float plotW=Math.max(1,getWidth()-AXIS_R),plotH=Math.max(1,getHeight()-AXIS_B);
  crossX=Math.max(0,Math.min(plotW,crossX));
  crossY=Math.max(0,Math.min(plotH,crossY));
 }

 @Override public boolean onTouchEvent(MotionEvent e){
  gestureDetector.onTouchEvent(e);scaleDetector.onTouchEvent(e);
  switch(e.getActionMasked()){
   case MotionEvent.ACTION_DOWN:
    lastX=e.getX();dragging=true;getParent().requestDisallowInterceptTouchEvent(true);return true;
   case MotionEvent.ACTION_MOVE:
    if(crosshair){
     crossX=e.getX();crossY=e.getY();clampCross();invalidate();return true;
    }
    if(!scaleDetector.isInProgress()&&dragging&&!d.isEmpty()){
     float dx=e.getX()-lastX;lastX=e.getX();
     float plotW=Math.max(1,getWidth()-AXIS_R);
     startIndex-=dx*(visibleCount/plotW);clampWindow();invalidate();
     if(dx>0&&startIndex<=0.25f&&olderListener!=null&&!olderRequested){
      olderRequested=true;olderListener.onNeedOlder(d.get(0).openTime);
     }
    }
    return true;
   case MotionEvent.ACTION_POINTER_DOWN:crosshair=false;dragging=false;return true;
   case MotionEvent.ACTION_POINTER_UP:lastX=e.getX();return true;
   case MotionEvent.ACTION_UP:
   case MotionEvent.ACTION_CANCEL:
    dragging=false;
    if(crosshair){crosshair=false;invalidate();}
    getParent().requestDisallowInterceptTouchEvent(false);return true;
  }
  return true;
 }

 private void clampWindow(){
  if(d.isEmpty()){startIndex=0;return;}
  visibleCount=Math.max(MIN_VISIBLE,Math.min(Math.max(MIN_VISIBLE,d.size()),visibleCount));
  float maxStart=Math.max(0,d.size()-visibleCount);
  startIndex=Math.max(0,Math.min(maxStart,startIndex));
 }

 @Override protected void onDraw(Canvas c){
  super.onDraw(c);
  float w=getWidth(),h=getHeight(),plotW=Math.max(1,w-AXIS_R),plotH=Math.max(1,h-AXIS_B);
  c.drawRect(plotW,0,w,h,axisBg);c.drawRect(0,plotH,w,h,axisBg);
  if(d.isEmpty()){c.drawText("캔들 데이터 없음",18,h/2,text);return;}

  clampWindow();
  int from=Math.max(0,(int)Math.floor(startIndex));
  int to=Math.min(d.size(),(int)Math.ceil(startIndex+visibleCount));
  if(to<=from){from=0;to=d.size();}

  double rawMin=Double.MAX_VALUE,rawMax=-Double.MAX_VALUE;
  int hiIndex=from,loIndex=from;
  for(int i=from;i<to;i++){
   Candle x=d.get(i);
   if(x.high>rawMax){rawMax=x.high;hiIndex=i;}
   if(x.low<rawMin){rawMin=x.low;loIndex=i;}
  }
  double mn=rawMin,mx=rawMax;
  if(mx<=mn)mx=mn+1;
  double margin=(mx-mn)*0.07;mn-=margin;mx+=margin;

  for(int i=1;i<5;i++){
   float yy=plotH*i/5f;c.drawLine(0,yy,plotW,yy,grid);
   double pv=priceAtY(yy,mn,mx,plotH);
   c.drawText(price(pv),plotW+5,yy-4,text);
  }

  float step=plotW/Math.max(1,visibleCount),body=Math.max(2f,Math.min(14f,step*.64f));
  int markerIndex=-1;
  if(markerTs>0){long best=Long.MAX_VALUE;for(int i=0;i<d.size();i++){long dist=Math.abs(d.get(i).openTime-markerTs);if(dist<best){best=dist;markerIndex=i;}}}

  for(int i=from;i<to;i++){
   Candle x=d.get(i);float cx=((i-startIndex)+.5f)*step;
   float yh=y(x.high,mn,mx,plotH),yl=y(x.low,mn,mx,plotH),yo=y(x.open,mn,mx,plotH),yc=y(x.close,mn,mx,plotH);
   Paint p=x.close>=x.open?up:down;wick.setColor(p.getColor());
   c.drawLine(cx,yh,cx,yl,wick);float top=Math.min(yo,yc),bot=Math.max(yo,yc);if(bot-top<2)bot=top+2;
   c.drawRect(cx-body/2,top,cx+body/2,bot,p);
  }

  drawExtremeLabel(c,hiIndex,rawMax,true,startIndex,step,mn,mx,plotW,plotH);
  drawExtremeLabel(c,loIndex,rawMin,false,startIndex,step,mn,mx,plotW,plotH);

  if(showMarker&&markerIndex>=from&&markerIndex<to){
   float x=((markerIndex-startIndex)+.5f)*step;Candle m=d.get(markerIndex);float yy=y(m.close,mn,mx,plotH);
   c.drawLine(x,0,x,plotH,marker);c.drawCircle(x,yy,9,marker);
   Paint ring=new Paint(marker);ring.setStyle(Paint.Style.STROKE);ring.setStrokeWidth(3);c.drawCircle(x,yy,15,ring);
  }

  int mid=(from+to-1)/2;
  drawTime(c,d.get(from).openTime,3,plotH+27);
  drawTimeCenter(c,d.get(mid).openTime,plotW/2,plotH+27);
  drawTimeRight(c,d.get(to-1).openTime,plotW-3,plotH+27);

  if(crosshair)drawCrosshair(c,from,to,startIndex,step,mn,mx,plotW,plotH);
 }

 private void drawExtremeLabel(Canvas c,int index,double value,boolean high,float start,float step,double mn,double mx,float plotW,float plotH){
  float cx=((index-start)+.5f)*step;
  float cy=y(value,mn,mx,plotH);
  String s=price(value);
  float tw=strongText.measureText(s);
  boolean right=cx<plotW*.58f;
  float x1=right?cx+4:Math.max(2,cx-tw-30);
  float x2=right?Math.min(plotW-2,x1+tw+26):cx-4;
  float yy=high?Math.max(18,cy-8):Math.min(plotH-4,cy+20);
  c.drawLine(right?cx:x2,cy,right?x1:x2+tw+24,cy,strongText);
  c.drawText((high?"H ":"L ")+s,right?x1+4:Math.max(2,x2+4),yy,strongText);
 }

 private void drawCrosshair(Canvas c,int from,int to,float start,float step,double mn,double mx,float plotW,float plotH){
  clampCross();
  c.drawLine(crossX,0,crossX,plotH,cross);
  c.drawLine(0,crossY,plotW,crossY,cross);

  int idx=(int)Math.floor(start+crossX/Math.max(1,step));
  idx=Math.max(from,Math.min(to-1,idx));
  Candle x=d.get(idx);
  double cursorPrice=priceAtY(crossY,mn,mx,plotH);

  String p=price(cursorPrice);
  if(alertPrice>0)p+="  "+String.format(Locale.US,"%+.2f%%",(cursorPrice/alertPrice-1.0)*100.0);
  float ph=30f;
  c.drawRect(plotW,crossY-ph/2,getWidth(),crossY+ph/2,labelBg);
  c.drawText(p,plotW+4,crossY+7,strongText);

  String ts=new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.KOREA).format(new Date(x.openTime));
  float tw=strongText.measureText(ts),tx=Math.max(0,Math.min(plotW-tw-8,crossX-tw/2-4));
  c.drawRect(tx,plotH,tx+tw+8,getHeight(),labelBg);
  c.drawText(ts,tx+4,plotH+27,strongText);

  String ohlc="O "+price(x.open)+"   H "+price(x.high)+"   L "+price(x.low)+"   C "+price(x.close);
  float boxW=Math.min(plotW-8,strongText.measureText(ohlc)+18);
  c.drawRect(5,5,5+boxW,37,labelBg);
  c.drawText(ohlc,12,28,strongText);
 }

 private void drawTime(Canvas c,long ts,float x,float y){c.drawText(time(ts),x,y,text);}
 private void drawTimeCenter(Canvas c,long ts,float x,float y){String s=time(ts);c.drawText(s,x-text.measureText(s)/2,y,text);}
 private void drawTimeRight(Canvas c,long ts,float x,float y){String s=time(ts);c.drawText(s,x-text.measureText(s),y,text);}
 private String time(long ts){return new SimpleDateFormat("MM/dd HH:mm",Locale.KOREA).format(new Date(ts));}
 private String price(double v){
  if(v>=1000)return String.format(Locale.US,"%.1f",v);
  if(v>=100)return String.format(Locale.US,"%.2f",v);
  if(v>=1)return String.format(Locale.US,"%.4f",v);
  if(v>=0.01)return String.format(Locale.US,"%.5f",v);
  return String.format(Locale.US,"%.7f",v);
 }
 private double priceAtY(float yy,double mn,double mx,float h){
  double ratio=(yy-PAD)/Math.max(1,h-PAD*2);
  ratio=Math.max(0,Math.min(1,ratio));
  return mx-ratio*(mx-mn);
 }
 private float y(double v,double mn,double mx,float h){return (float)(PAD+(mx-v)/(mx-mn)*(h-PAD*2));}
}