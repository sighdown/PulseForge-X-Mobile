package com.pulseforge.xmobile;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.net.URLDecoder;
import java.text.SimpleDateFormat;
import java.util.*;

public class NewsRangeChecks {
 static final long NOW=1792656000000L,DAY=86400000L;
 static void check(boolean value,String message){if(!value)throw new AssertionError(message);}
 static String feed(){
  StringBuilder xml=new StringBuilder("<rss><channel>");int[] ages={1,5,10,20,31,-1};
  SimpleDateFormat fmt=new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss z",Locale.US);fmt.setTimeZone(TimeZone.getTimeZone("GMT"));
  for(int i=0;i<ages.length;i++)xml.append("<item><title>비트코인 메인넷 업그레이드 공식 발표 ").append((char)('A'+i)).append(" - 코인데스크</title><source>코인데스크</source><link>https://example.test/").append(i).append("</link><pubDate>").append(fmt.format(new Date(NOW-ages[i]*DAY))).append("</pubDate></item>");
  xml.append("<item><title>비트코인 메인넷 업그레이드 날짜 미상</title><link>https://example.test/missing</link></item>");
  xml.append("<item><title>비트코인 가격 전망과 목표가</title><link>https://example.test/noise</link><pubDate>").append(fmt.format(new Date(NOW-DAY))).append("</pubDate></item>");
  xml.append("<item><title>비트코인 메인넷 업그레이드 공식 발표 A - 코인데스크</title><source>코인데스크</source><link>https://example.test/duplicate</link><pubDate>").append(fmt.format(new Date(NOW-DAY))).append("</pubDate></item>");
  return xml.append("</channel></rss>").toString();
 }
 public static void main(String[] args)throws Exception{
  int count=0;
  for(int days:new int[]{3,7,14,30}){
   check(NewsClient.query("BTCUSDT",days).contains("when:"+days+"d"),"query range");
   check(URLDecoder.decode(NewsClient.searchUrl("BTCUSDT",days),"UTF-8").contains(NewsClient.query("BTCUSDT",days)),"more news link");
   check(NewsClient.inRange(NOW-days*DAY,days,NOW),"exact boundary");
   check(!NewsClient.inRange(NOW-days*DAY-1,days,NOW),"older than boundary");
   check(!NewsClient.inRange(0,days,NOW)&&!NewsClient.inRange(NOW+1,days,NOW),"unknown/future date");
  }count++;
  check(NewsClient.query("BTCUSDT").equals(NewsClient.query("BTCUSDT",3)),"default 3D");
  check(NewsClient.rangeLabel(30).equals("최근 1달(30일)"),"1M means 30 days");count++;
  check(!NewsClient.cacheKey("BTCUSDT",3).equals(NewsClient.cacheKey("BTCUSDT",7)),"range cache isolation");count++;
  int expected=1;
  for(int days:new int[]{3,7,14,30}){
   ArrayList<NewsClient.Item> items=NewsClient.parseFeed(new ByteArrayInputStream(feed().getBytes(StandardCharsets.UTF_8)),"BTCUSDT",days,NOW);
   check(items.size()==expected++,"RSS date/quality/duplicate filter "+days+" got "+items.size());
  }count++;
  ArrayList<NewsClient.Item> edge=new ArrayList<>();edge.add(new NewsClient.Item("edge","url","source",NOW-3*DAY+1000,"공식",10,true));
  check(NewsClient.cachedItems(new NewsClient.Cache(NOW,edge),3,5,NOW+2000).isEmpty(),"expired article on fresh cache");count++;
  NewsRequestGate gate=new NewsRequestGate();NewsRequestGate.Ticket old=gate.begin(3),other=gate.begin(30),latest=gate.begin(3);
  check(!gate.accepts(old)&&!gate.accepts(other)&&gate.accepts(latest),"A B A stale response");
  NewsRequestGate.Ticket refresh=gate.begin(3);check(!gate.accepts(latest)&&gate.accepts(refresh),"same tab refresh race");
  gate.close();check(!gate.accepts(refresh),"closed screen");count++;
  System.out.println("MOBILE NEWS CHECKS PASS: "+count+" groups (actual NewsClient/NewsRequestGate, test XML adapter)");
 }
}
