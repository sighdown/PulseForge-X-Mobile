// Test-only adapter contract. Never included in the Android app source set.
package org.xmlpull.v1;
import java.io.InputStream;
public interface XmlPullParser {
 int START_DOCUMENT=0,END_DOCUMENT=1,START_TAG=2,END_TAG=3,TEXT=4;
 void setInput(InputStream stream,String encoding)throws Exception;
 int getEventType();int next()throws Exception;
 String getName();String getText();
}
