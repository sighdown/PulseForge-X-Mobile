// Test-only XmlPullParser implementation backed by the JDK StAX parser.
package android.util;
import org.xmlpull.v1.XmlPullParser;
import java.io.InputStream;
import javax.xml.stream.*;
public final class Xml {
 public static XmlPullParser newPullParser(){return new Pull();}
 private static class Pull implements XmlPullParser {
  XMLStreamReader reader;int event=START_DOCUMENT;
  public void setInput(InputStream in,String encoding)throws Exception{reader=XMLInputFactory.newFactory().createXMLStreamReader(in,encoding);event=START_DOCUMENT;}
  public int getEventType(){return event;}
  public int next()throws Exception{
   while(reader.hasNext()){
    int kind=reader.next();
    if(kind==XMLStreamConstants.START_ELEMENT)return event=START_TAG;
    if(kind==XMLStreamConstants.END_ELEMENT)return event=END_TAG;
    if(kind==XMLStreamConstants.CHARACTERS||kind==XMLStreamConstants.CDATA||kind==XMLStreamConstants.SPACE)return event=TEXT;
    if(kind==XMLStreamConstants.END_DOCUMENT)return event=END_DOCUMENT;
   }
   return event=END_DOCUMENT;
  }
  public String getName(){return reader.hasName()?reader.getLocalName():"";}
  public String getText(){return reader.getText();}
 }
}
