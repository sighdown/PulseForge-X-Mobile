package com.pulseforge.xmobile;

import android.util.Xml;
import org.xmlpull.v1.XmlPullParser;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Pattern;

public class NewsClient {
 public static class Item {
  public String title,url,source,category; public long ts; public int score; public boolean important;
  Item(String t,String u,String s,long x,String c,int sc,boolean imp){title=t;url=u;source=s;ts=x;category=c;score=sc;important=imp;}
 }
 static class Cache { long at; ArrayList<Item> items; Cache(long a,ArrayList<Item> i){at=a;items=i;} }
 static class Quality { String category; int score; boolean important; Quality(String c,int s,boolean i){category=c;score=s;important=i;} }
 static final long CACHE_MS=15*60*1000L;
 static final int FETCH_MAX=40;
 static final ConcurrentHashMap<String,Cache> cache=new ConcurrentHashMap<>();
 static final HashMap<String,String> KO=new HashMap<>();
 static { String[][] x={{"BTC","비트코인"},{"ETH","이더리움"},{"XRP","리플"},{"SOL","솔라나"},{"DOGE","도지코인"},{"ADA","에이다"},{"BNB","바이낸스코인"},{"AVAX","아발란체"},{"LINK","체인링크"},{"DOT","폴카닷"},{"TRX","트론"},{"SUI","수이"},{"APT","앱토스"},{"OP","옵티미즘"},{"ARB","아비트럼"},{"WLD","월드코인"},{"UNI","유니스왑"},{"AAVE","에이브"},{"BCH","비트코인캐시"},{"LTC","라이트코인"},{"ETC","이더리움클래식"},{"NEAR","니어프로토콜"},{"ATOM","코스모스"},{"FIL","파일코인"},{"INJ","인젝티브"},{"SEI","세이"},{"TON","톤코인"},{"XLM","스텔라루멘"},{"HBAR","헤데라"},{"SHIB","시바이누"},{"PEPE","페페"},{"ENA","에테나"},{"ONDO","온도"},{"DYDX","디와이디엑스"},{"TAO","비텐서"},{"FET","페치에이아이"},{"RENDER","렌더"},{"POL","폴리곤"},{"MATIC","폴리곤"},{"ICP","인터넷컴퓨터"},{"EOS","이오스"},{"GALA","갈라"},{"SAND","샌드박스"},{"MANA","디센트럴랜드"},{"APE","에이프코인"},{"JUP","주피터"},{"JTO","지토"},{"PYTH","피스네트워크"},{"PENDLE","펜들"}}; for(String[] a:x)KO.put(a[0],a[1]); }
 static final String[][] GROUPS={
  {"보안","10","1","해킹|해커|보안 사고|취약점|익스플로잇|exploit|공격|침해|탈취"},
  {"상장/상폐","9","1","상장|상폐|거래 지원|거래지원|거래 종료|거래종료|listing|delisting"},
  {"규제/소송","9","1","규제|소송|법원|판결|금융위|금융위원회|법안|제재|조사 착수|sec |승인"},
  {"토크노믹스","8","1","토큰 언락|언락|락업 해제|소각|바이백|에어드롭|공급량"},
  {"ETF/기관","8","1","현물 etf| etf|etf |기관 투자|기관 매수|기관 자금"},
  {"공식/개발","7","1","메인넷|테스트넷|업그레이드|하드포크|거버넌스|프로토콜 업데이트|공식 발표|로드맵|출시|런칭"},
  {"파트너십/투자","7","1","파트너십|협력|제휴|통합|채택|투자 유치|투자유치|펀딩|인수|합병"},
  {"거래소","7","1","입출금 중단|입출금 재개|거래 중단|거래 재개|거래소 공지"},
  {"수급","5","0","고래|대규모 매수|대규모 매도|대규모 이체|매집|순유입|순유출"}
 };
 static final String[] HARD_NOISE={"가격 전망","가격전망","가격 예측","가격예측","목표가","장기 가격","향후 가격","2030년 가격","2029년 가격","2028년 가격","2027년 가격"};
 static final String[] PROMO_NOISE={"유망 코인","추천 코인","사야 할 코인","매수할 코인","top 5 코인","top5 코인","top 10 코인","상위 코인"};
 static final String[] MARKET_WORDS={"급등","급락","상승","하락","마감","시세","랠리","반등","조정"};
 static final String[] TRUSTED={"로이터","reuters","블룸버그","bloomberg","연합뉴스","코인데스크","coindesk","코인니스","블록미디어","디센터","디지털애셋","코인텔레그래프"};

 public static String base(String symbol){String s=(symbol==null?"":symbol.trim().toUpperCase(Locale.US));for(String q:new String[]{"USDT","USDC","BUSD","FDUSD"})if(s.endsWith(q)){s=s.substring(0,s.length()-q.length());break;}s=s.replaceFirst("^1000(?=[A-Z])","");return s;}
 public static int rangeDays(int days){if(days!=3&&days!=7&&days!=14&&days!=30)throw new IllegalArgumentException("Unsupported news range");return days;}
 public static String rangeLabel(int days){return rangeDays(days)==30?"최근 1달(30일)":"최근 "+days+"일";}
 static boolean inRange(long ts,int days,long now){return ts>0&&ts<=now&&now-ts<=rangeDays(days)*86400000L;}
 static String cacheKey(String symbol,int days){return base(symbol)+":"+rangeDays(days);}
 public static String query(String symbol){return query(symbol,3);}
 public static String query(String symbol,int days){String b=base(symbol),a=KO.get(b);return ((a==null?"":a+" ")+b+" 코인 암호화폐 when:"+rangeDays(days)+"d").trim();}
 public static String searchUrl(String symbol)throws Exception{return searchUrl(symbol,3);}
 public static String searchUrl(String symbol,int days)throws Exception{return "https://news.google.com/search?q="+URLEncoder.encode(query(symbol,days),"UTF-8")+"&hl=ko&gl=KR&ceid=KR%3Ako";}
 static boolean hangul(String s){if(s==null)return false;for(int i=0;i<s.length();i++){char c=s.charAt(i);if(c>='가'&&c<='힣')return true;}return false;}
 static String clean(String s){return s==null?"":s.replaceAll("\\s+"," ").trim();}
 static long parseDate(String s){try{return new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss z",Locale.US).parse(s).getTime();}catch(Exception e){return 0;}}
 static boolean hasAny(String low,String[] words){for(String w:words)if(low.contains(w.toLowerCase(Locale.US)))return true;return false;}
 static boolean hasToken(String title,String token){if(token==null||token.isEmpty())return false;return Pattern.compile("(?i)(?<![A-Z0-9])"+Pattern.quote(token)+"(?![A-Z0-9])").matcher(title==null?"":title).find();}
 static Quality quality(String symbol,String title,String source,long ts,long now){
  String b=base(symbol),a=KO.get(b),low=(title==null?"":title.toLowerCase(Locale.US));int relevance=0;
  if(a!=null&&title.contains(a))relevance+=4;if(hasToken(title,b))relevance+=3;if(relevance<=0)return null;
  String cat="관련";int impact=0;boolean important=false;
  for(String[] g:GROUPS){String[] ws=g[3].split("\\|");boolean hit=false;for(String w:ws)if(low.contains(w.toLowerCase(Locale.US))){hit=true;break;}int pts=Integer.parseInt(g[1]);if(hit&&pts>impact){cat=g[0];impact=pts;important="1".equals(g[2]);}}
  if(hasAny(low,HARD_NOISE)&&impact<7)return null;if(hasAny(low,PROMO_NOISE)&&impact<7)return null;
  boolean pct=Pattern.compile("\\d+(?:\\.\\d+)?\\s*%").matcher(title).find();boolean move=hasAny(title,MARKET_WORDS);boolean priceOnly=(title.contains("달러 마감")||title.contains("원 마감")||title.contains("시간 새"))&&move;
  if((pct&&move||priceOnly)&&impact<7)return null;
  int score=relevance+impact;if(ts>0){long age=Math.max(0,now-ts);if(age<=6*3600000L)score+=3;else if(age<=24*3600000L)score+=2;else if(age<=48*3600000L)score+=1;}
  if(hasAny((source==null?"":source.toLowerCase(Locale.US)),TRUSTED))score+=1;
  if(impact==0&&(title.contains("전망")||title.contains("예측")||title.contains("기술적 분석")||title.contains("차트 분석")))score-=3;
  if(score<5)return null;return new Quality(cat,score,important);
 }
 static ArrayList<Item> cachedItems(Cache c,int days,int limit,long now){
  ArrayList<Item> current=new ArrayList<>();
  for(Item item:c.items)if(inRange(item.ts,days,now)){current.add(item);if(current.size()>=limit)break;}
  return current;
 }
 public static ArrayList<Item> fetch(String symbol,int limit,boolean force)throws Exception{return fetch(symbol,limit,force,3);}
 public static ArrayList<Item> fetch(String symbol,int limit,boolean force,int days)throws Exception{
  rangeDays(days);String key=cacheKey(symbol,days);long now=System.currentTimeMillis();Cache c=cache.get(key);
  if(!force&&c!=null&&now>=c.at&&now-c.at<=CACHE_MS)return cachedItems(c,days,limit,now);
  String u="https://news.google.com/rss/search?q="+URLEncoder.encode(query(symbol,days),"UTF-8")+"&hl=ko&gl=KR&ceid=KR%3Ako";
  HttpURLConnection h=(HttpURLConnection)new URL(u).openConnection();h.setConnectTimeout(6000);h.setReadTimeout(7000);h.setRequestProperty("User-Agent","Mozilla/5.0 PulseForgeX-Mobile/10.9");h.setRequestProperty("Accept-Language","ko-KR,ko;q=0.9");
  ArrayList<Item> out;
  try(InputStream in=h.getInputStream()){out=parseFeed(in,symbol,days,now);}finally{h.disconnect();}
  cache.compute(key,(k,previous)->previous==null||previous.at<=now?new Cache(now,new ArrayList<>(out)):previous);
  return new ArrayList<>(out.subList(0,Math.min(limit,out.size())));
 }
 static ArrayList<Item> parseFeed(InputStream in,String symbol,int days,long now)throws Exception{
  rangeDays(days);ArrayList<Item> out=new ArrayList<>();HashSet<String> seen=new HashSet<>();
   XmlPullParser p=Xml.newPullParser();p.setInput(in,"UTF-8");boolean inItem=false;String tag="",title="",link="",source="",pub="";
   for(int ev=p.getEventType();ev!=XmlPullParser.END_DOCUMENT;ev=p.next()){
    if(ev==XmlPullParser.START_TAG){tag=p.getName();if("item".equals(tag)){inItem=true;title=link=source=pub="";}}
    else if(ev==XmlPullParser.TEXT&&inItem){String t=p.getText();if("title".equals(tag))title+=t;else if("link".equals(tag))link+=t;else if("source".equals(tag))source+=t;else if("pubDate".equals(tag))pub+=t;}
    else if(ev==XmlPullParser.END_TAG){String n=p.getName();if("item".equals(n)){inItem=false;title=clean(title);link=clean(link);source=clean(source);if(!source.isEmpty()&&title.endsWith(" - "+source))title=title.substring(0,title.length()-source.length()-3).trim();long ts=parseDate(clean(pub));if(hangul(title)&&!link.isEmpty()&&inRange(ts,days,now)){String norm=title.replaceAll("[^0-9A-Za-z가-힣]+","").toLowerCase(Locale.US);if(seen.add(norm)){Quality q=quality(symbol,title,source,ts,now);if(q!=null)out.add(new Item(title,link,source.isEmpty()?"Google 뉴스":source,ts,q.category,q.score,q.important));}}if(out.size()>=FETCH_MAX)break;}tag="";}
   }
  Collections.sort(out,(a,b)->{int x=Boolean.compare(b.important,a.important);if(x!=0)return x;x=Integer.compare(b.score,a.score);if(x!=0)return x;return Long.compare(b.ts,a.ts);});
  return out;
 }
}
