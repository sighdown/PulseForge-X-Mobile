package com.pulseforge.xmobile;

/** A result belongs to one tab/refresh, even when the user goes A -> B -> A. */
final class NewsRequestGate {
 static final class Ticket {
  final int serial, days;
  Ticket(int serial,int days){this.serial=serial;this.days=days;}
 }
 private int serial=0, days=3;
 private boolean closed=false;
 Ticket begin(int rangeDays){days=NewsClient.rangeDays(rangeDays);return new Ticket(++serial,days);}
 boolean accepts(Ticket ticket){return !closed&&ticket.serial==serial&&ticket.days==days;}
 void close(){closed=true;serial++;}
}
