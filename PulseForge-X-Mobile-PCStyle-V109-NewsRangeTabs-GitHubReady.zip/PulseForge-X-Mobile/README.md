# PulseForge X Mobile V10.9 — 뉴스 범위 탭

종목 상세의 주요뉴스에 네 탭을 추가했습니다. PC V6.9.7과 같은 범위입니다.

| 탭 | 뉴스 범위 |
|---|---|
| 3D | 최근 3일, 기본 선택 |
| 1W | 최근 7일 |
| 2W | 최근 14일 |
| 1M | 최근 1달, 30일 기준 |

기간은 현재 시각을 기준으로 계산합니다. 발행 시각 미상·미래 기사는 제외합니다.
기존 한글·관련성·중요도 필터와 주요뉴스 최대 5개 표시를 유지합니다.
기간별 캐시를 분리하고 새로고침과 '한글 뉴스 더 보기'에도 선택 범위를 적용합니다.
이전 요청이 늦게 도착해도 마지막 선택 결과를 덮지 않도록 처리했습니다.
새 종목 상세는 3D로 시작하고 화면 회전 시 현재 선택을 복원합니다.

V10.8의 FALLBACK 이력 정렬과 PRIMARY/FALLBACK 구조를 기준으로 수정했습니다.
계산 엔진·DB 스키마·수집 서비스·알림 이력 정렬 코드는 수정하지 않았습니다.
versionCode 52, versionName 0.10.9-v10.9-news-range-tabs.

## GitHub 빌드

기존처럼 프로젝트 루트의 app, build.gradle, settings.gradle, .github 폴더를 저장소에 반영합니다.
숨김 폴더인 .github/workflows/build-apk.yml도 함께 반영해야 합니다.
전체 소스를 포함한 ZIP이므로 구버전 일부 파일과 섞지 않습니다.

Actions의 Build Android APK는 뉴스 로직 검사를 실행한 다음 APK를 빌드합니다.
결과 artifact 이름은 **PulseForge-X-Mobile-V109-debug-apk** 입니다.
설치할 APK는 GitHub Actions 빌드 결과에서 받아 기존 서명 절차를 적용합니다.
이 ZIP은 소스·빌드 설정이며 APK 자체를 포함하지 않습니다.
기존 앱을 업데이트할 때는 기존 앱과 같은 서명 키를 사용해야 데이터를 유지하며 설치할 수 있습니다.

## 검사 범위

- 실제 NewsClient/NewsRequestGate Java 컴파일 및 기간·캐시·RSS·전환 6개 묶음 검사 통과
- 전체 Android Java 21개 파일 구문 분석 통과
- Android 리소스 XML 파싱, PC/앱 탭 범위 일치 검사 통과
- Android SDK 빌드와 실제 휴대폰 화면 동작은 이 환경에서 확인하지 못함

qa_news/stubs는 일반 JDK에서 뉴스 파서를 검사하기 위한 테스트 전용 어댑터입니다.
app/src 밖에 있으며 앱에 포함되지 않습니다. Actions의 assembleDebug가 실제 SDK 컴파일을 수행합니다.
