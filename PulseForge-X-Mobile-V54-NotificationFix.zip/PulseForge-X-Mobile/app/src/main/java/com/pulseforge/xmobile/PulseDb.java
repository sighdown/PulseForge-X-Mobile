package com.pulseforge.xmobile;
import android.content.*;import android.database.sqlite.*;import android.database.*;import java.util.*;
public class PulseDb extends SQLiteOpenHelper{
 public PulseDb(Context c){super(c,"pulseforge_mobile.db",null,1);} public void onCreate(SQLiteDatabase d){d.execSQL("CREATE TABLE scans(ts INTEGER,symbol TEXT,price REAL,qv REAL,oi REAL,score REAL,PRIMARY KEY(ts,symbol))");d.execSQL("CREATE TABLE alerts(ts INTEGER,symbol TEXT,stage TEXT,score REAL)");} public void onUpgrade(SQLiteDatabase d,int a,int b){}
 public List<ScoreEngine.Hist> hist(String s){ArrayList<ScoreEngine.Hist> out=new ArrayList<>();Cursor c=getReadableDatabase().rawQuery("SELECT price,qv,oi FROM scans WHERE symbol=? ORDER BY ts DESC LIMIT 24",new String[]{s});ArrayList<ScoreEngine.Hist> rev=new ArrayList<>();while(c.moveToNext())rev.add(new ScoreEngine.Hist(c.getDouble(0),c.getDouble(1),c.getDouble(2)));c.close();Collections.reverse(rev);return rev;}
 public void scan(long ts,String s,double p,double q,double oi,double score){getWritableDatabase().execSQL("INSERT OR REPLACE INTO scans VALUES(?,?,?,?,?,?)",new Object[]{ts,s,p,q,oi,score});}
 public void alert(long ts,String s,String st,double sc){getWritableDatabase().execSQL("INSERT INTO alerts VALUES(?,?,?,?)",new Object[]{ts,s,st,sc});}
}
