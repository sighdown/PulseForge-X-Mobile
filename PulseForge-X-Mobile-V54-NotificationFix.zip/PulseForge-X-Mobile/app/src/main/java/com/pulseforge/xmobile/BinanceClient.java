package com.pulseforge.xmobile;
import org.json.*;import java.net.*;import java.io.*;import java.nio.charset.StandardCharsets;import java.util.*;
public class BinanceClient{
 static String get(String path)throws Exception{HttpURLConnection c=(HttpURLConnection)new URL("https://fapi.binance.com"+path).openConnection();c.setConnectTimeout(10000);c.setReadTimeout(15000);c.setRequestProperty("User-Agent","PulseForge-X-Mobile/0.1");try(InputStream in=c.getInputStream()){ByteArrayOutputStream b=new ByteArrayOutputStream();byte[] x=new byte[8192];for(int n;(n=in.read(x))>0;)b.write(x,0,n);return b.toString(StandardCharsets.UTF_8.name());}}
 public static Set<String> symbols()throws Exception{JSONObject o=new JSONObject(get("/fapi/v1/exchangeInfo"));Set<String>s=new HashSet<>();JSONArray a=o.getJSONArray("symbols");for(int i=0;i<a.length();i++){JSONObject x=a.getJSONObject(i);if("USDT".equals(x.optString("quoteAsset"))&&"PERPETUAL".equals(x.optString("contractType"))&&"TRADING".equals(x.optString("status")))s.add(x.optString("symbol"));}return s;}
 public static JSONArray tickers()throws Exception{return new JSONArray(get("/fapi/v1/ticker/24hr"));} public static JSONArray premiums()throws Exception{return new JSONArray(get("/fapi/v1/premiumIndex"));}
 public static double oi(String sym){try{return new JSONObject(get("/fapi/v1/openInterest?symbol="+URLEncoder.encode(sym,"UTF-8"))).optDouble("openInterest",0);}catch(Exception e){return 0;}}
}
