package com.pulseforge.xmobile;
import java.util.*;

public final class ScoreEngine {
 public static class Hist { public double price,qv,oi; public Hist(double p,double q,double o){price=p;qv=q;oi=o;} }
 public static class Result { public double score,confidence,vz,oz,ret3,ret10,ret20,compression,prebreakout,gap,chase; public int leadCount; }
 static double clamp(double x){return Math.max(0,Math.min(100,x));}
 static double pct(double p,double old){return p>0&&old>0?(p/old-1)*100:0;}
 static double z(List<Double> vals,double x){List<Double> v=new ArrayList<>(); for(double d:vals)if(d>0)v.add(d); if(v.size()<5)return 0; double m=0;for(double d:v)m+=d;m/=v.size();double s=0;for(double d:v)s+=(d-m)*(d-m);s=Math.sqrt(s/v.size());return s<=0?0:Math.max(-4,Math.min(4,(x-m)/s));}
 static double compression(double r){if(r<=.8)return 100;if(r<=1.5)return 88;if(r<=2.5)return 68;if(r<=4)return 42;if(r<=6)return 22;return 8;}
 static double[] pre(double price,double high){if(price<=0||high<=0)return new double[]{35,0};double g=(high-price)/high*100;if(g>=.08&&g<=.8)return new double[]{100,g};if(g>=0&&g<.08)return new double[]{88,g};if(g>.8&&g<=1.8)return new double[]{82,g};if(g>1.8&&g<=3)return new double[]{58,g};if(g>=-.25&&g<0)return new double[]{58,g};if(g<-.25)return new double[]{12,g};return new double[]{28,g};}
 static double quiet(double r3,double r10){if(r3>=-.5&&r3<=.9&&r10>=-1&&r10<=1.8)return 100;if(r3>=-1&&r3<=1.5&&r10>=-2&&r10<=3)return 78;if(r3>=-1.5&&r3<=2&&r10>=-3&&r10<=4)return 52;return 15;}
 static double funding(double f){if(f<=-.00030)return 100;if(f<=-.00010)return 88;if(f<=0)return 72;if(f<=.00010)return 55;if(f<=.00030)return 35;return 15;}
 public static Result compute(double price,double qv,double change24,double fund,double oi,List<Hist> h,double btc){
  List<Double> qd=new ArrayList<>(), oc=new ArrayList<>(); for(int i=1;i<h.size();i++){double d=h.get(i).qv-h.get(i-1).qv;if(d>=0)qd.add(d); if(h.get(i-1).oi>0&&h.get(i).oi>0)oc.add((h.get(i).oi/h.get(i-1).oi-1)*100);}
  double vd=h.isEmpty()?0:Math.max(0,qv-h.get(h.size()-1).qv), vz=z(qd,vd); double lastOi=0;for(int i=h.size()-1;i>=0;i--)if(h.get(i).oi>0){lastOi=h.get(i).oi;break;} double oiPct=oi>0&&lastOi>0?(oi/lastOi-1)*100:0, oz=oi>0?z(oc,oiPct):0;
  double r3=h.size()>=3?pct(price,h.get(h.size()-3).price):0, r10=h.size()>=10?pct(price,h.get(h.size()-10).price):0, r20=h.size()>=20?pct(price,h.get(h.size()-20).price):0;
  List<Double> recent=new ArrayList<>();for(int i=Math.max(0,h.size()-12);i<h.size();i++)if(h.get(i).price>0)recent.add(h.get(i).price);double comp=35,pb=35,gap=0;if(!recent.isEmpty()){double hi=Collections.max(recent),lo=Collections.min(recent),mean=0;for(double p:recent)mean+=p;mean/=recent.size();comp=compression(mean>0?(hi-lo)/mean*100:99);double[] pr=pre(price,hi);pb=pr[0];gap=pr[1];}
  double vs=clamp(50+vz*17), os=clamp(50+oz*16), qs=quiet(r3,r10), fs=funding(fund), bs=clamp(50+btc*4); double raw=vs*.28+os*.24+comp*.16+pb*.15+qs*.08+fs*.05+bs*.04;
  double chase=0;if(r3>1.2)chase+=Math.min(14,(r3-1.2)*6);if(r10>2.5)chase+=Math.min(13,(r10-2.5)*3.4);if(change24>20)chase+=Math.min(8,(change24-20)*.35);if(gap<-.25)chase+=Math.min(8,Math.abs(gap+.25)*5+2);chase=Math.max(0,Math.min(35,chase)); double maturity=Math.min(1,h.size()/12.0), score=clamp(50+(raw-50)*(.42+.58*maturity)-chase);
  int leads=0;if(vz>=1.15)leads++;if(oz>=.90)leads++;if(comp>=70)leads++;if(pb>=65)leads++;if(qs>=75)leads++;int complete=(qv>0?1:0)+1+(oi>0?1:0)+(h.size()>=6?1:0); Result r=new Result();r.score=Math.round(score*10)/10.0;r.confidence=Math.round(clamp(35+65*(complete/4.0))*10)/10.0;r.vz=vz;r.oz=oz;r.ret3=r3;r.ret10=r10;r.ret20=r20;r.compression=comp;r.prebreakout=pb;r.gap=gap;r.chase=chase;r.leadCount=leads;return r;
 }
 public static String stage(double s){return s>=88?"PRIME":s>=84?"HOT":s>=78?"ALERT":s>=72?"EARLY WATCH":"QUIET";}
}
