# PulseForge X Mobile · V5.4 MVP
Android native port of the PulseForge X V5.4 `early_v53` scoring core.

## Included
- Binance USDⓈ-M perpetual public market scan
- 60-second foreground monitoring service
- V5.4 scoring weights / compression / pre-breakout / quiet-price / funding / chase penalty / lead flags
- EARLY WATCH 72 / ALERT 78 / HOT 84 / PRIME 88
- 2-scan confirmation, 5-minute signal cooldown, 5M USDT quote-volume gate
- Local SQLite scan + alert history storage
- Android high-priority signal notifications
- GitHub Actions debug APK build

## Important V0.1 limitation
The desktop V5.4 leverage filter calls Binance `/fapi/v1/leverageBracket`, a signed USER_DATA endpoint. This first mobile build deliberately does not store Binance API secrets, so the leverage filter UI is visible but disabled. Public-data signal collection and notifications work without an API key. A later build can add Android Keystore-protected credentials and enable the exact 5/10/20/25/50/75/100/125x filter.

This is a signal-analysis tool, not a guarantee of future price movement.

## V5.7
- EARLY / ALERT / HOT / PRIME stage colors
- Rich TOP SIGNAL rows (price / 24h change / volume / OI)
- Alert notification tap opens the matching symbol detail
- Alert history with alert-time price and chart marker
- Binance button targets the installed global Binance Android app first, then falls back to app launch/web
- Collection delay warning
