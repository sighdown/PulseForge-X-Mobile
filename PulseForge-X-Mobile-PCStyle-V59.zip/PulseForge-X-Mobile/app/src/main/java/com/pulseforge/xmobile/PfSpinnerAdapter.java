package com.pulseforge.xmobile;

import android.content.*;
import android.graphics.Color;
import android.view.*;
import android.widget.*;

public class PfSpinnerAdapter extends ArrayAdapter<String>{
 private final Context ctx;
 public PfSpinnerAdapter(Context c,String[] items){super(c,android.R.layout.simple_spinner_item,items);ctx=c;}
 private TextView make(String text,boolean dropdown){
  TextView t=new TextView(ctx);t.setText(text);t.setTextColor(Color.parseColor("#E5EAF1"));t.setTextSize(16);t.setGravity(Gravity.CENTER_VERTICAL);int hp=dp(14),vp=dp(10);t.setPadding(hp,vp,hp,vp);t.setMinHeight(dp(dropdown?50:48));t.setBackgroundColor(Color.parseColor(dropdown?"#111D2E":"#111D2E"));return t;
 }
 public View getView(int pos,View v,ViewGroup p){return make(getItem(pos),false);}
 public View getDropDownView(int pos,View v,ViewGroup p){return make(getItem(pos),true);}
 private int dp(int v){return Math.round(v*ctx.getResources().getDisplayMetrics().density);}
}
