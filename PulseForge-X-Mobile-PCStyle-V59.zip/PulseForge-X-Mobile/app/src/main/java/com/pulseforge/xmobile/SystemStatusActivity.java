package com.pulseforge.xmobile;

import android.app.*;
import android.os.*;
import android.content.*;
import android.widget.*;
import java.util.*;

public class SystemStatusActivity extends Activity{
 TextView info;
 Handler h=new Handler(Looper.getMainLooper());
 Runnable tick=new Runnable(){public void run(){render();h.postDelayed(this,1000);}};
 static final int[] LEVS={5,10,20,25,50,75,100,125};

 public void onCreate(Bundle b){
  super.onCreate(b);setContentView(R.layout.activity_system_status);info=findViewById(R.id.info);findViewById(R.id.back).setOnClickListener(v->finish());h.post(tick);
 }

 void render(){
  PulseDb db=new PulseDb(this);PulseDb.Stats s=db.stats();PulseDb.LeverageStats ls=db.leverageStats();
  SharedPreferences r=getSharedPreferences("runtime",0),p=getSharedPreferences("settings",0);
  long now=System.currentTimeMillis(),last=r.getLong("last_success_ms",0),start=r.getLong("service_start_ms",0);
  long age=last>0?(now-last)/1000:-1,up=start>0?(now-start)/1000:0;
  boolean svc=ScanService.runningNow||r.getBoolean("service_running",false);
  String state=svc?(age>=0&&age<=110?"정상 감시 중":"감시 중 · 갱신 확인 필요"):"중지";
  String stages=(p.getBoolean("EARLY",false)?"EARLY ":"")+(p.getBoolean("ALERT",false)?"ALERT ":"")+(p.getBoolean("HOT",true)?"HOT ":"")+(p.getBoolean("PRIME",true)?"PRIME":"");
  if(stages.trim().isEmpty())stages="모두 OFF";
  boolean levOn=p.getBoolean("LEV_ENABLED",false);
  int li=Math.max(0,Math.min(LEVS.length-1,p.getInt("MIN_LEV_INDEX",4)));
  int ri=Math.max(0,Math.min(8,p.getInt("RANK_LEV_INDEX",0)));
  String api=ApiCredentialStore.exists(this)?"연결정보 저장됨":"미연결";
  String levCache=ls.count>0?ls.count+"종목 · "+fmtDate(ls.updatedTs*1000):"없음";
  String rankFilter=ri==0?"전체":LEVS[ri-1]+"x 이상";
  String levFilter=levOn?LEVS[li]+"x 이상":"OFF";
  String levErr=r.getString("leverage_last_error","");

  StringBuilder b=new StringBuilder();
  b.append("실시간 수집 상태  ").append(state)
   .append("\n마지막 정상 스캔  ").append(last>0?fmtTime(last):"-")
   .append("\n마지막 스캔 경과  ").append(age>=0?age+"초":"-")
   .append("\n서비스 가동시간  ").append(fmtDur(up))
   .append("\n\n원시 스캔 DB  ").append(String.format(Locale.US,"%,d",s.rows)).append("행")
   .append("\n분석 회차  ").append(String.format(Locale.US,"%,d",s.scans)).append("회")
   .append("\n알림 신호 기록  ").append(String.format(Locale.US,"%,d",s.alerts)).append("건")
   .append("\n사후채점 완료  ").append(String.format(Locale.US,"%,d",s.outcomes)).append("개 구간")
   .append("\nDB 크기  ").append(String.format(Locale.US,"%.1f MB",s.dbBytes/1048576.0))
   .append("\nDB 기록 범위  ").append(s.firstTs>0?fmtDate(s.firstTs*1000):"-").append(" ~ ").append(s.lastTs>0?fmtDate(s.lastTs*1000):"-")
   .append("\n\n알림 단계  ").append(stages.trim())
   .append("\n재알림 쿨다운  ").append(p.getInt("COOLDOWN_MIN",60)).append("분")
   .append("\n연속 확인  ").append(p.getInt("CONFIRMATIONS",2)).append("회")
   .append("\n단계 상승 즉시 알림  ").append(p.getBoolean("ESCALATION_IMMEDIATE",true)?"ON":"OFF")
   .append("\n같은 단계 반복  ").append(p.getBoolean("SAME_STAGE_REPEAT",false)?"ON":"OFF")
   .append("\n\nBinance API  ").append(api)
   .append("\n레버리지 캐시  ").append(levCache)
   .append("\n순위 최소배수  ").append(rankFilter)
   .append("\n레버리지 알림필터  ").append(levFilter);
  if(!levErr.isEmpty())b.append("\n최근 API 오류  ").append(levErr);
  b.append("\n\n※ 원시 스캔은 최근 12시간 유지 · 알림과 사후채점 결과는 장기 누적");
  info.setText(b.toString());
 }

 String fmtTime(long ms){return new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.KOREA).format(new Date(ms));}
 String fmtDate(long ms){return new java.text.SimpleDateFormat("MM/dd HH:mm",Locale.KOREA).format(new Date(ms));}
 String fmtDur(long s){long h=s/3600,m=(s%3600)/60,ss=s%60;return h+"시간 "+m+"분 "+ss+"초";}
 protected void onDestroy(){h.removeCallbacks(tick);super.onDestroy();}
}
