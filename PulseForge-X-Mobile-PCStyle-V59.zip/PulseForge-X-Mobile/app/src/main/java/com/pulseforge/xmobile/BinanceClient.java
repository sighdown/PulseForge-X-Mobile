package com.pulseforge.xmobile;

import org.json.*;
import java.net.*;import java.io.*;import java.nio.charset.StandardCharsets;import java.util.*;
import javax.crypto.Mac;import javax.crypto.spec.SecretKeySpec;

public class BinanceClient{
 static final String BASE="https://fapi.binance.com";
 static String get(String path)throws Exception{return request(path,null,3);}
 static String request(String path,Map<String,String> headers,int retries)throws Exception{
  Exception last=null;for(int attempt=1;attempt<=Math.max(1,retries);attempt++){HttpURLConnection c=null;try{c=(HttpURLConnection)new URL(BASE+path).openConnection();c.setConnectTimeout(10000);c.setReadTimeout(15000);c.setRequestProperty("User-Agent","PulseForge-X-Mobile/0.9");if(headers!=null)for(Map.Entry<String,String>e:headers.entrySet())c.setRequestProperty(e.getKey(),e.getValue());int code=c.getResponseCode();InputStream in=(code>=200&&code<300)?c.getInputStream():c.getErrorStream();String body=read(in);if(code<200||code>=300){String msg="HTTP "+code;try{JSONObject o=new JSONObject(body);if(o.has("code"))msg+=" · "+o.optInt("code");if(o.has("msg"))msg+=" · "+o.optString("msg");}catch(Exception ignored){}throw new IOException(msg);}return body;}catch(Exception e){last=e;String m=e.getMessage()==null?"":e.getMessage();boolean auth=m.contains("HTTP 400")||m.contains("HTTP 401")||m.contains("HTTP 403");if(auth)break;if(attempt<retries){try{Thread.sleep(500L*attempt);}catch(InterruptedException ie){Thread.currentThread().interrupt();throw ie;}}}finally{if(c!=null)c.disconnect();}}throw last==null?new IOException("Binance request failed"):last;
 }
 static String read(InputStream in)throws Exception{if(in==null)return "";try(InputStream x=in;ByteArrayOutputStream b=new ByteArrayOutputStream()){byte[] buf=new byte[8192];for(int n;(n=x.read(buf))>0;)b.write(buf,0,n);return b.toString(StandardCharsets.UTF_8.name());}}
 static String hex(byte[] b){StringBuilder s=new StringBuilder();for(byte x:b)s.append(String.format(Locale.US,"%02x",x&0xff));return s.toString();}
 static String hmac(String secret,String payload)throws Exception{Mac m=Mac.getInstance("HmacSHA256");m.init(new SecretKeySpec(secret.getBytes(StandardCharsets.UTF_8),"HmacSHA256"));return hex(m.doFinal(payload.getBytes(StandardCharsets.UTF_8)));}
 public static long serverTime()throws Exception{return new JSONObject(get("/fapi/v1/time")).optLong("serverTime",System.currentTimeMillis());}
 public static JSONArray leverageBrackets(String apiKey,String secret)throws Exception{
  long ts=serverTime();String q="timestamp="+ts+"&recvWindow=10000";String sig=hmac(secret,q);Map<String,String> h=new HashMap<>();h.put("X-MBX-APIKEY",apiKey);String raw=request("/fapi/v1/leverageBracket?"+q+"&signature="+sig,h,2);if(raw.trim().startsWith("["))return new JSONArray(raw);JSONObject o=new JSONObject(raw);JSONArray a=new JSONArray();if(o.has("symbol"))a.put(o);else if(o.optJSONArray("data")!=null)a=o.optJSONArray("data");return a;
 }
 public static Map<String,Integer> leverageMap(String apiKey,String secret)throws Exception{JSONArray a=leverageBrackets(apiKey,secret);HashMap<String,Integer> out=new HashMap<>();for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x==null)continue;String sym=x.optString("symbol","").toUpperCase(Locale.US);JSONArray bs=x.optJSONArray("brackets");int max=0;if(bs!=null)for(int j=0;j<bs.length();j++){JSONObject b=bs.optJSONObject(j);if(b!=null)max=Math.max(max,(int)Math.round(b.optDouble("initialLeverage",0)));}if(!sym.isEmpty()&&max>0)out.put(sym,max);}if(out.isEmpty())throw new IOException("Binance에서 레버리지 브래킷을 받지 못했습니다.");return out;}
 public static Set<String> symbols()throws Exception{JSONObject o=new JSONObject(get("/fapi/v1/exchangeInfo"));Set<String>s=new HashSet<>();JSONArray a=o.getJSONArray("symbols");for(int i=0;i<a.length();i++){JSONObject x=a.getJSONObject(i);if("USDT".equals(x.optString("quoteAsset"))&&"PERPETUAL".equals(x.optString("contractType"))&&"TRADING".equals(x.optString("status")))s.add(x.optString("symbol"));}return s;}
 public static JSONArray tickers()throws Exception{return new JSONArray(get("/fapi/v1/ticker/24hr"));}
 public static JSONArray premiums()throws Exception{return new JSONArray(get("/fapi/v1/premiumIndex"));}
 public static double oi(String sym){try{return new JSONObject(get("/fapi/v1/openInterest?symbol="+URLEncoder.encode(sym,"UTF-8"))).optDouble("openInterest",0);}catch(Exception e){return 0;}}
 public static JSONArray klines(String sym,String interval,int limit,Long startMs,Long endMs)throws Exception{StringBuilder p=new StringBuilder("/fapi/v1/klines?symbol=").append(URLEncoder.encode(sym,"UTF-8")).append("&interval=").append(URLEncoder.encode(interval,"UTF-8")).append("&limit=").append(Math.max(10,Math.min(500,limit)));if(startMs!=null)p.append("&startTime=").append(startMs);if(endMs!=null)p.append("&endTime=").append(endMs);return new JSONArray(get(p.toString()));}
}
