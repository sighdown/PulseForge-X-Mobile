package com.pulseforge.xmobile;

import android.content.*;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import org.json.JSONObject;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

public class ApiCredentialStore{
 private static final String PREF="pf_secure_api",ALIAS="pulseforge_binance_api_v1",DATA="blob",IV="iv";
 public static class Credentials{public final String apiKey,secret;Credentials(String k,String s){apiKey=k;secret=s;}}
 private static SecretKey key()throws Exception{
  KeyStore ks=KeyStore.getInstance("AndroidKeyStore");ks.load(null);if(ks.containsAlias(ALIAS))return (SecretKey)ks.getKey(ALIAS,null);
  KeyGenerator kg=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");kg.init(new KeyGenParameterSpec.Builder(ALIAS,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).setRandomizedEncryptionRequired(true).build());return kg.generateKey();
 }
 public static void save(Context c,String apiKey,String secret)throws Exception{
  apiKey=apiKey==null?"":apiKey.trim();secret=secret==null?"":secret.trim();if(apiKey.isEmpty()||secret.isEmpty())throw new IllegalArgumentException("API Key와 Secret Key를 모두 입력해 주세요.");
  JSONObject o=new JSONObject();o.put("apiKey",apiKey);o.put("secret",secret);Cipher cp=Cipher.getInstance("AES/GCM/NoPadding");cp.init(Cipher.ENCRYPT_MODE,key());byte[] enc=cp.doFinal(o.toString().getBytes(StandardCharsets.UTF_8));c.getSharedPreferences(PREF,0).edit().putString(DATA,Base64.encodeToString(enc,Base64.NO_WRAP)).putString(IV,Base64.encodeToString(cp.getIV(),Base64.NO_WRAP)).apply();
 }
 public static Credentials load(Context c)throws Exception{
  SharedPreferences p=c.getSharedPreferences(PREF,0);String b=p.getString(DATA,""),iv=p.getString(IV,"");if(b.isEmpty()||iv.isEmpty())return null;Cipher cp=Cipher.getInstance("AES/GCM/NoPadding");cp.init(Cipher.DECRYPT_MODE,key(),new GCMParameterSpec(128,Base64.decode(iv,Base64.NO_WRAP)));String s=new String(cp.doFinal(Base64.decode(b,Base64.NO_WRAP)),StandardCharsets.UTF_8);JSONObject o=new JSONObject(s);String k=o.optString("apiKey","").trim(),sec=o.optString("secret","").trim();return k.isEmpty()||sec.isEmpty()?null:new Credentials(k,sec);
 }
 public static boolean exists(Context c){try{return load(c)!=null;}catch(Exception e){return false;}}
 public static void clear(Context c){c.getSharedPreferences(PREF,0).edit().clear().apply();}
}
