# PulseForge X Mobile V5.9

PulseForge X Android build aligned with the current PC signal/alert workflow.

## V5.9 highlights
- Binance USDⓈ-M Futures API connection screen.
- API Key + HMAC Secret encrypted locally with Android Keystore (AES/GCM).
- Authenticated `GET /fapi/v1/leverageBracket` lookup, leverage cache, and ~6-hour refresh while monitoring.
- Minimum max-leverage alert filter: 5/10/20/25/50/75/100/125x. All-symbol collection/scoring continues even when the notification filter suppresses a symbol.
- Max leverage shown in TOP SIGNALS and symbol detail when leverage data is available.
- PC-style TOP SIGNALS minimum-leverage ranking filter (전체 / 5 / 10 / 20 / 25 / 50 / 75 / 100 / 125x). It changes only the visible ranking, not collection/scoring/history.
- Advanced-setting spinner selected values and alert-history filter selected value are now visible in the dark theme.
- Binance button first sends the exact Futures symbol URL directly to the installed Binance package, then falls back to Binance app + clipboard symbol copy.
- V5.8 signal outcome tracking, MFE/MAE, 5/15/30/60/120/240-minute scoring, similar-pattern feedback, multi-timeframe charts, alert history and system status remain intact.

## Security
- Do not put Binance API credentials in source code, GitHub, ZIP files, screenshots, or chat.
- Credentials are entered only on the device and encrypted with Android Keystore.
- The authenticated code path in this build is for leverage-bracket GET lookup only; no order-placement endpoint is implemented.
