package com.pulseforge.xmobile;

import org.json.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;

public final class CoreClient{
 public static final String DEVICE_ID="mobile-a56";
 public static final String LAN_URL="http://192.168.0.30:8765";
 public static final String TAILSCALE_URL="http://100.74.6.90:8765";
 // Core V2.2 protects mobile write endpoints by the mobile Tailscale source IP.
 // Read/health prefers LAN at home; canonical writes stay on Tailscale for V2.2 trust.
 private static volatile String activeReadUrl=LAN_URL;
 private CoreClient(){}

 public static String activeBaseUrl(){return activeReadUrl;}
 public static String writeBaseUrl(){return TAILSCALE_URL;}
 public static String routeSummary(){return activeReadUrl+" · 쓰기 "+TAILSCALE_URL;}

 public static JSONObject health()throws Exception{
  Exception lanErr=null;
  try{JSONObject o=requestAt(LAN_URL,"GET","/health",null,900,2200);activeReadUrl=LAN_URL;return o;}
  catch(Exception e){lanErr=e;}
  try{JSONObject o=requestAt(TAILSCALE_URL,"GET","/health",null,2500,3200);activeReadUrl=TAILSCALE_URL;return o;}
  catch(Exception tailErr){String a=msg(lanErr),b=msg(tailErr);throw new IOException("LAN "+a+" / Tailscale "+b,tailErr);}
 }
 public static JSONObject heartbeat()throws Exception{JSONObject b=new JSONObject();b.put("device_id",DEVICE_ID);b.put("role","MOBILE");return requestAt(activeReadUrl,"POST","/heartbeat",b,1800,3000);}
 public static JSONObject lease()throws Exception{JSONObject b=new JSONObject();b.put("device_id",DEVICE_ID);return requestWrite("POST","/lease",b,3000,5000);}
 public static JSONObject createEvent(String eventType,JSONObject payload,String eventUuid)throws Exception{JSONObject b=new JSONObject();b.put("device_id",DEVICE_ID);b.put("event_type",eventType);b.put("origin","MOBILE_BRIDGE");b.put("payload",payload);if(eventUuid!=null&&!eventUuid.isEmpty())b.put("event_uuid",eventUuid);return requestWrite("POST","/events/create",b,3000,6000);}
 public static JSONObject ingestFallback(JSONArray events)throws Exception{JSONObject b=new JSONObject();b.put("device_id",DEVICE_ID);b.put("events",events);return requestWrite("POST","/ingest/fallback",b,3000,8000);}

 static JSONObject requestWrite(String method,String path,JSONObject body,int connectMs,int readMs)throws Exception{
  // V2.2 mobile trust is intentionally Tailscale-only for protected writes.
  return requestAt(TAILSCALE_URL,method,path,body,connectMs,readMs);
 }
 static JSONObject requestAt(String base,String method,String path,JSONObject body,int connectMs,int readMs)throws Exception{
  HttpURLConnection c=(HttpURLConnection)new URL(base+path).openConnection();
  c.setConnectTimeout(connectMs);c.setReadTimeout(readMs);c.setRequestMethod(method);c.setUseCaches(false);c.setRequestProperty("Accept","application/json");
  if(body!=null){c.setDoOutput(true);c.setRequestProperty("Content-Type","application/json; charset=utf-8");byte[] raw=body.toString().getBytes(StandardCharsets.UTF_8);c.setFixedLengthStreamingMode(raw.length);try(OutputStream out=c.getOutputStream()){out.write(raw);}}
  int code=c.getResponseCode();InputStream in=code>=200&&code<300?c.getInputStream():c.getErrorStream();String text=readAll(in);c.disconnect();JSONObject o=text==null||text.trim().isEmpty()?new JSONObject():new JSONObject(text);if(code<200||code>=300)throw new IOException("HTTP "+code+" · "+o.optString("error",text));return o;
 }
 static String readAll(InputStream in)throws Exception{if(in==null)return "";try(InputStream x=in;ByteArrayOutputStream b=new ByteArrayOutputStream()){byte[] buf=new byte[8192];for(int n;(n=x.read(buf))>0;)b.write(buf,0,n);return b.toString("UTF-8");}}
 static String msg(Exception e){if(e==null)return "unknown";String s=e.getMessage();if(s==null||s.trim().isEmpty())s=e.getClass().getSimpleName();return s.length()>90?s.substring(0,90):s;}
}
