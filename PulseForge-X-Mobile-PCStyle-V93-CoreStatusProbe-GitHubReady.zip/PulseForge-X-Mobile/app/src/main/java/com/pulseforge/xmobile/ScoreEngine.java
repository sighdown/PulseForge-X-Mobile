package com.pulseforge.xmobile;
import java.util.*;

public final class ScoreEngine {
 public static final String MODEL_VERSION="early_v71_lateguard";
 public static final String COMPAT_MODEL_VERSION="early_v60";
 public static class Hist { public double price,qv,oi; public Hist(double p,double q,double o){price=p;qv=q;oi=o;} }
 public static class Result {
  public double score,preLateScore,confidence,vz,oz,ret1,ret3,ret5,ret10,ret20,ret30,ret60,compression,prebreakout,gap,chase,dist20,burst,latePenalty,leadLearnBonus,leadLearnAvgGain,leadLearnAvgMinutes;
  public int leadCount,staleHighMin,leadLearnSamples;
  public boolean lateBlocked;
  public String lateFlag="";
 }
 static double clamp(double x){return Math.max(0,Math.min(100,x));}
 static double pct(double p,double old){return p>0&&old>0?(p/old-1)*100:0;}
 static double agoPct(double price,List<Hist> h,int n){return h.size()>=n?pct(price,h.get(h.size()-n).price):0;}
 static double z(List<Double> vals,double x){List<Double> v=new ArrayList<>(); for(double d:vals)if(d>0)v.add(d); if(v.size()<5)return 0; double m=0;for(double d:v)m+=d;m/=v.size();double s=0;for(double d:v)s+=(d-m)*(d-m);s=Math.sqrt(s/v.size());return s<=0?0:Math.max(-4,Math.min(4,(x-m)/s));}
 static double compression(double r){if(r<=.8)return 100;if(r<=1.5)return 88;if(r<=2.5)return 68;if(r<=4)return 42;if(r<=6)return 22;return 8;}
 static double[] pre(double price,double high){if(price<=0||high<=0)return new double[]{35,0};double g=(high-price)/high*100;if(g>=.08&&g<=.8)return new double[]{100,g};if(g>=0&&g<.08)return new double[]{88,g};if(g>.8&&g<=1.8)return new double[]{82,g};if(g>1.8&&g<=3)return new double[]{58,g};if(g>=-.25&&g<0)return new double[]{58,g};if(g<-.25)return new double[]{12,g};return new double[]{28,g};}
 static double quiet(double r3,double r10){if(r3>=-.5&&r3<=.9&&r10>=-1&&r10<=1.8)return 100;if(r3>=-1&&r3<=1.5&&r10>=-2&&r10<=3)return 78;if(r3>=-1.5&&r3<=2&&r10>=-3&&r10<=4)return 52;return 15;}
 static double funding(double f){if(f<=-.00030)return 100;if(f<=-.00010)return 88;if(f<=0)return 72;if(f<=.00010)return 55;if(f<=.00030)return 35;return 15;}
 static double meanPrice(List<Hist> h,int n){int a=Math.max(0,h.size()-n);double s=0;int c=0;for(int i=a;i<h.size();i++)if(h.get(i).price>0){s+=h.get(i).price;c++;}return c>0?s/c:0;}
 static double burstRatio(List<Hist> h,double ret1){if(h.size()<8)return 0;int a=Math.max(1,h.size()-18);double s=0;int c=0;for(int i=a;i<h.size();i++){double x=Math.abs(pct(h.get(i).price,h.get(i-1).price));if(x<20){s+=x;c++;}}double avg=c>0?s/c:0;return Math.abs(ret1)/(avg+.05);}
 static int staleHigh(List<Hist> h,double price){if(price<=0||h.isEmpty())return 0;int a=Math.max(0,h.size()-30);for(int i=a;i<h.size();i++){double p=h.get(i).price;if(p>0&&p>=price*.994)return h.size()-i;}return 0;}
 static String lateFlag(double r1,double r3,double r5,double r10,double r30,double r60,double change24,double pb,double comp,int stale,double dist20,double latePenalty){
  if(r1>=1.8||r3>=3.2||r5>=4.6||r10>=6.3)return "FAST_SPIKE";
  if(r30>=8.0||r60>=12.0)return "EXTENDED_MOVE";
  if(change24>=15&&stale>=10&&pb>=80&&comp>=62&&Math.abs(r10)<=2.2)return "STALE_HIGH";
  if(dist20>=3.8&&change24>=8)return "MEAN_STRETCH";
  if(latePenalty>=15)return "OVEREXTENDED";
  return "";
 }
 public static Result compute(double price,double qv,double change24,double fund,double oi,List<Hist> h,double btc){
  List<Double> qd=new ArrayList<>(),oc=new ArrayList<>();int start=Math.max(1,h.size()-24);for(int i=start;i<h.size();i++){double d=h.get(i).qv-h.get(i-1).qv;if(d>=0)qd.add(d);if(h.get(i-1).oi>0&&h.get(i).oi>0)oc.add((h.get(i).oi/h.get(i-1).oi-1)*100);}
  double vd=h.isEmpty()?0:Math.max(0,qv-h.get(h.size()-1).qv),vz=z(qd,vd);double lastOi=0;for(int i=h.size()-1;i>=0;i--)if(h.get(i).oi>0){lastOi=h.get(i).oi;break;}double oiPct=oi>0&&lastOi>0?(oi/lastOi-1)*100:0,oz=oi>0?z(oc,oiPct):0;
  double r1=agoPct(price,h,1),r3=agoPct(price,h,3),r5=agoPct(price,h,5),r10=agoPct(price,h,10),r20=agoPct(price,h,20),r30=agoPct(price,h,30),r60=agoPct(price,h,60);
  List<Double> recent=new ArrayList<>();for(int i=Math.max(0,h.size()-12);i<h.size();i++)if(h.get(i).price>0)recent.add(h.get(i).price);double comp=35,pb=35,gap=0;if(!recent.isEmpty()){double hi=Collections.max(recent),lo=Collections.min(recent),mean=0;for(double p:recent)mean+=p;mean/=recent.size();comp=compression(mean>0?(hi-lo)/mean*100:99);double[] pr=pre(price,hi);pb=pr[0];gap=pr[1];}
  double mean20=meanPrice(h,20),dist20=mean20>0?(price/mean20-1)*100:0,burst=burstRatio(h,r1);int stale=staleHigh(h,price);
  double vs=clamp(50+vz*17),os=clamp(50+oz*16),qs=quiet(r3,r10),fs=funding(fund),bs=clamp(50+btc*4);double raw=vs*.28+os*.24+comp*.16+pb*.15+qs*.08+fs*.05+bs*.04;
  double chase=0;if(r1>1.0)chase+=Math.min(12,(r1-1.0)*8);if(r3>1.8)chase+=Math.min(14,(r3-1.8)*6);if(r5>2.8)chase+=Math.min(12,(r5-2.8)*3.5);if(r10>4.0)chase+=Math.min(12,(r10-4.0)*2.5);if(gap<-.25)chase+=Math.min(8,Math.abs(gap+.25)*5+2);chase=Math.max(0,Math.min(38,chase));
  double late=0;if(r30>5)late+=Math.min(12,(r30-5)*1.2);if(r60>8)late+=Math.min(14,(r60-8)*.9);if(dist20>2.0)late+=Math.min(10,(dist20-2.0)*2.2);if(burst>=4&&r1>.8)late+=Math.min(8,(burst-4)*1.5+2);if(change24>=12&&pb>=82&&comp>=65&&Math.abs(r10)<=1.8&&stale>=12)late+=Math.min(18,8+(change24-12)*.65);late=Math.max(0,Math.min(42,late));
  double maturity=Math.min(1,h.size()/12.0),preLate=clamp(50+(raw-50)*(.42+.58*maturity)-chase),score=clamp(preLate-late);String lf=lateFlag(r1,r3,r5,r10,r30,r60,change24,pb,comp,stale,dist20,late);boolean lateBlocked=!lf.isEmpty();
  int leads=0;if(vz>=1.15)leads++;if(oz>=.90)leads++;if(comp>=70)leads++;if(pb>=65)leads++;if(qs>=75)leads++;int complete=(qv>0?1:0)+1+(oi>0?1:0)+(h.size()>=6?1:0);
  Result r=new Result();r.score=Math.round(score*10)/10.0;r.preLateScore=Math.round(preLate*10)/10.0;r.confidence=Math.round(clamp(35+65*(complete/4.0))*10)/10.0;r.vz=vz;r.oz=oz;r.ret1=r1;r.ret3=r3;r.ret5=r5;r.ret10=r10;r.ret20=r20;r.ret30=r30;r.ret60=r60;r.compression=comp;r.prebreakout=pb;r.gap=gap;r.chase=chase;r.dist20=dist20;r.burst=burst;r.staleHighMin=stale;r.latePenalty=Math.round(late*10)/10.0;r.lateFlag=lf;r.lateBlocked=lateBlocked;r.leadCount=leads;return r;
 }
 public static String stage(double s){return s>=92?"PRIME+":s>=88?"PRIME":s>=84?"HOT":s>=78?"ALERT":s>=72?"EARLY WATCH":"QUIET";}
 public static String lateLabel(String f){if("FAST_SPIKE".equals(f))return "단기 급등 진행";if("EXTENDED_MOVE".equals(f))return "30~60분 과확장";if("STALE_HIGH".equals(f))return "급등 후 고점 체류";if("MEAN_STRETCH".equals(f))return "단기 평균 과이격";if("OVEREXTENDED".equals(f))return "과열/추격 위험";return "";}
 public static final String DROP_MODEL_VERSION="drop_v21_lateguard";
 public static class DropResult {
  public double score,preLateScore,latePenalty,topHeat,exhaustion,reversal,oiHeat,fundingHeat,marketDrag,drawdownHigh;
  public boolean lateBlocked;
  public String lateFlag="",reason="";
 }
 static double ramp(double x,double lo,double hi){if(hi<=lo)return 0;return clamp((x-lo)*100.0/(hi-lo));}
 static double hiPrice(List<Hist> h,double price,int n){double hi=price;for(int i=Math.max(0,h.size()-n);i<h.size();i++)if(h.get(i).price>hi)hi=h.get(i).price;return hi;}
 public static DropResult computeDrop(double price,double change24,double fund,double oi,List<Hist> h,double btc,Result up){
  DropResult d=new DropResult();
  double high=hiPrice(h,price,60),dd=price>0&&high>0?(price/high-1)*100:0;
  double changeHeat=ramp(change24,4,28);
  double hourHeat=ramp(up.ret60,2.5,14);
  double distHeat=ramp(up.dist20,1.0,6.0);
  double lateHeat=clamp(up.latePenalty*3.1);
  double staleHeat=ramp(up.staleHighMin,4,24);
  d.topHeat=clamp(changeHeat*.30+hourHeat*.24+distHeat*.18+lateHeat*.18+staleHeat*.10);

  double neg1=ramp(-up.ret1,.05,1.8),neg3=ramp(-up.ret3,.10,3.2),neg5=ramp(-up.ret5,.15,4.8),neg10=ramp(-up.ret10,.25,6.5);
  double stall=clamp((100-Math.min(100,Math.abs(up.ret3)*35))*0.55+staleHeat*.45);
  double volFade=clamp(52-up.vz*15);
  double oiStall=(up.oz>.35&&up.ret3<.5)?ramp(up.oz,.35,2.8):0;
  d.exhaustion=clamp(neg1*.18+neg3*.16+stall*.26+volFade*.14+staleHeat*.16+oiStall*.10);

  double drawdownScore=ramp(-dd,.25,3.8);
  d.reversal=clamp(neg1*.24+neg3*.22+neg5*.18+neg10*.12+drawdownScore*.24);
  d.oiHeat=clamp(ramp(up.oz,.5,3.0)*.7+oiStall*.3);
  d.fundingHeat=fund<=0?0:ramp(fund,.00005,.00055);
  d.marketDrag=btc>=0?0:ramp(-btc,.5,7.0);
  d.drawdownHigh=dd;

  // V7.7 calibration:
  // 점수는 "고점 과열 -> 에너지 약화 -> 반전 확인"의 진행 강도를 나타내고,
  // 단계는 아래의 구성요소 조합으로 별도 판정한다.
  double raw=d.topHeat*.44+d.exhaustion*.22+d.reversal*.24+d.oiHeat*.05+d.fundingHeat*.03+d.marketDrag*.02;
  raw*=1.35;
  if(d.topHeat<18)raw*=.60;
  if(change24<3.5&&up.ret60<2.5)raw*=.70;
  if(d.topHeat>=25)raw+=5;
  if(d.exhaustion>=42)raw+=6;
  if(d.reversal>=38)raw+=8;
  if(d.topHeat>=38&&d.reversal>=55)raw+=10;

  // V8.2: 급락도 "이미 떨어진 뒤"의 후행 경고를 별도 차단한다.
  // 원래 위험 점수(preLateScore)는 보존하고, 진행된 하락폭/속도만 latePenalty로 분리해 검증 가능하게 한다.
  double preLate=clamp(raw),late=0;
  if(up.ret1<-.8)late+=Math.min(10,(-up.ret1-.8)*6.0);
  if(up.ret3<-1.5)late+=Math.min(12,(-up.ret3-1.5)*4.0);
  if(up.ret5<-2.5)late+=Math.min(12,(-up.ret5-2.5)*3.0);
  if(up.ret10<-4.0)late+=Math.min(10,(-up.ret10-4.0)*2.0);
  if(up.ret30<-5.0)late+=Math.min(10,(-up.ret30-5.0)*1.2);
  if(dd<-2.5)late+=Math.min(14,(-dd-2.5)*3.2);
  if(up.dist20<-2.5)late+=Math.min(10,(-up.dist20-2.5)*2.0);
  late=Math.max(0,Math.min(42,late));
  String dlf=dropLateFlag(up.ret1,up.ret3,up.ret5,up.ret10,up.ret30,up.ret60,up.dist20,dd,late);
  d.preLateScore=Math.round(preLate*10)/10.0;
  d.latePenalty=Math.round(late*10)/10.0;
  d.lateFlag=dlf;
  d.lateBlocked=!dlf.isEmpty();
  d.score=Math.round(clamp(preLate-late)*10)/10.0;

  ArrayList<String> why=new ArrayList<>();
  if(d.topHeat>=65)why.add("상승 과열");
  if(up.dist20>=2.5)why.add("20m 평균 과이격");
  if(up.staleHighMin>=10)why.add("고점 체류");
  if(d.exhaustion>=60)why.add("상승 에너지 약화");
  if(d.reversal>=60)why.add("단기 반전 확인");
  if(d.oiHeat>=60)why.add("OI 과열/정체");
  if(d.fundingHeat>=60)why.add("Funding 과열");
  if(d.marketDrag>=60)why.add("시장 약세");
  if(dd<=-1.0)why.add("최근고점 대비 "+String.format(Locale.US,"%.1f%%",dd));
  if(why.isEmpty())why.add("복합 고점 위험");
  StringBuilder rb=new StringBuilder();for(String w:why){if(rb.length()>0)rb.append(" · ");rb.append(w);}d.reason=rb.toString();
  return d;
 }
 static String dropLateFlag(double r1,double r3,double r5,double r10,double r30,double r60,double dist20,double dd,double latePenalty){
  if(r1<=-1.8||r3<=-3.2||r5<=-4.5||r10<=-6.5)return "FAST_DROP";
  if(r30<=-8.0||r60<=-12.0)return "EXTENDED_DROP";
  if(dd<=-5.0)return "DEEP_DRAWDOWN";
  if(dist20<=-4.0)return "MEAN_UNDERSTRETCH";
  if(latePenalty>=16&&dd<=-2.5)return "OVEREXTENDED_DROP";
  return "";
 }
 public static String dropLateLabel(String f){if("FAST_DROP".equals(f))return "단기 급락 진행";if("EXTENDED_DROP".equals(f))return "30~60분 하락 과확장";if("DEEP_DRAWDOWN".equals(f))return "최근고점 대비 이미 큰 하락";if("MEAN_UNDERSTRETCH".equals(f))return "단기 평균 하방 과이격";if("OVEREXTENDED_DROP".equals(f))return "하락 진행 후 추격 위험";return "";}
 public static String dropStage(DropResult d){return d==null||d.lateBlocked?"NORMAL":dropStage(d.score,d.topHeat,d.exhaustion,d.reversal,d.drawdownHigh);}
 public static String dropStage(double score,double topHeat,double exhaustion,double reversal,double drawdownHigh){
  // 단순 점수 컷이 아니라 진행 상태를 판정한다.
  if(topHeat>=38&&reversal>=55&&(exhaustion>=40||drawdownHigh<=-1.20)&&score>=58)return "DROP RISK";
  if(topHeat>=28&&reversal>=38)return "REVERSAL";
  if(topHeat>=30&&exhaustion>=42)return "EXHAUST";
  if(topHeat>=25||(score>=45&&topHeat>=20))return "TOP WATCH";
  return "NORMAL";
 }
 // 과거 코드/표시 호환용. 신규 실시간 판정은 반드시 DropResult 또는 구성요소 오버로드를 사용한다.
 public static String dropStage(double score){return score>=86?"DROP RISK":score>=72?"REVERSAL":score>=58?"EXHAUST":score>=45?"TOP WATCH":"NORMAL";}

}
