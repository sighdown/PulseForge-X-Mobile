package com.pulseforge.xmobile;

/** Shared leverage options for settings, rankings and actual trade records. */
public final class LeverageOptions {
 private LeverageOptions() {}
 public static final int[] VALUES={5,10,20,25,50,75,100,125};
 public static final String[] LABELS={"5x","10x","20x","25x","50x","75x","100x","125x"};
 public static boolean isValid(int v){for(int x:VALUES)if(x==v)return true;return false;}
 public static int indexOf(int v){for(int i=0;i<VALUES.length;i++)if(VALUES[i]==v)return i;return 4;}
 public static int valueAt(int i){return VALUES[Math.max(0,Math.min(VALUES.length-1,i))];}
}
