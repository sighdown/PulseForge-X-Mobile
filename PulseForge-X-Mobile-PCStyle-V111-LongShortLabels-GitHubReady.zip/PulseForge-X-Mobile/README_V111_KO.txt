PulseForge X Mobile V11.1 · 롱/숏 예측 명칭 + 전체 이력 조회
2026-10-24
versionCode 54 / versionName 0.11.1-v11.1-long-short-labels-history-range

반영 내용
1. 급등 선행 → 롱 예측 / 급락 위험 → 숏 예측.
2. 이력 화면 제목은 롱 알림 이력 / 숏 알림 이력.
3. EARLY WATCH/ALERT/HOT/PRIME/PRIME+ → 롱1/롱2/롱3/롱4/롱5.
4. TOP WATCH/EXHAUST/REVERSAL/DROP RISK → 숏1/숏2/숏3/숏4.
5. 이력 조회 범위: 전체 / 최근 500 / 최근 1,000 / 최근 5,000.
   처음 기본값은 양쪽 모두 전체이며, 이후 선택은 롱/숏별로 따로 기억합니다.
   조회와 행 표시용 문자열 준비는 백그라운드에서 진행합니다.
   빠르게 필터를 바꾸면 이전 조회 결과는 화면을 덮어쓰지 않습니다.
6. 이전 V11.0에서 미뤄둔 이력 배수 필터 분리 포함.
   푸시 알림 배수, 순위 배수, 이력 조회 배수는 각각 따로 설정할 수 있습니다.
   최초 한 번은 기존 알림 배수 설정을 이력 배수에 복사합니다.
   저배수 종목까지 보려면 이력 최소배수에서 전체 배수를 선택하세요.
7. 기존 번호 정확검색, 추천/비추천/실제매매, 상세 복귀 위치, 뉴스 3D/1W/2W/1M 유지.

데이터 호환
원래 단계값, 점수, 알림번호, UUID, 사후성과와 기존 설정 키는 유지합니다.
DB 파일명/스키마/버전과 ScoreEngine, Core 통신/병합 코드는 변경하지 않습니다.
화면 이름을 바꾸기 위해 기존 이벤트를 다시 쓰거나 합치지 않습니다.
뉴스 기사 제목/내용은 변환하지 않습니다.

기존 GitHub 빌드 방식
이 파일은 APK가 아닌 GitHub 빌드용 전체 소스 ZIP입니다.
ZIP 안 최상위 폴더는 PulseForge-X-Mobile입니다.
1. 기존 sighdown/PulseForge-X-Mobile 저장소에 새 ZIP을 업로드합니다.
2. 저장소의 .github/workflows/build-apk.yml에서 Extract project 단계의
   unzip 파일명만 GITHUB_COPYPASTE_V111.txt의 새 파일명으로 교체합니다.
3. 기존 Restore signing key / Build APK / Sign APK / Upload APK 단계는 유지합니다.
4. Commit 후 Actions → Build PulseForge APK → Run workflow.
5. 성공하면 기존 PulseForge-X-Signed-APK artifact에서 APK를 받아 설치합니다.
기존 앱을 삭제하지 않고, 기존과 같은 서명 키로 업데이트 설치합니다.

검증
Android API 35 + AndroidX Core 1.13.1 기준으로 실제 앱 Java 24개 타입 컴파일 통과.
명칭/범위/이전 조회 응답 차단 44개 assertion 통과.
실제 NewsClient/NewsRequestGate 검사 6개 그룹 통과.
모든 XML 파싱과 앱 R 리소스 참조 검증 통과.
엔진/DB/Core/차트 파일 해시와 알림 판정 메서드, 기존 설정 키 보존 확인.
qa_signals 폴더와 BUILD_CHECK_V111.txt에 결과가 있습니다.
R/BuildConfig는 컴파일 검사용 선언을 사용했습니다. APK 조립·서명과 실제 기기
화면 검사는 GitHub Actions 빌드 및 휴대폰 설치 후 확인해야 합니다.
