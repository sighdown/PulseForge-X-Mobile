package com.pulseforge.xmobile;

import java.util.concurrent.atomic.AtomicInteger;

/** Discard an older query when filters change or its Activity is destroyed. */
public final class HistoryRequestGate {
 private final AtomicInteger serial=new AtomicInteger();
 private volatile boolean closed;
 public int begin(){return serial.incrementAndGet();}
 public boolean accepts(int ticket){return !closed&&serial.get()==ticket;}
 public void close(){closed=true;serial.incrementAndGet();}
}
