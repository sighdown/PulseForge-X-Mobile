package com.pulseforge.xmobile;

/** Zero is the existing DB API's unlimited-history sentinel. */
public final class HistoryRange {
 private static final String[] LABELS={"전체","최근 500","최근 1,000","최근 5,000"};
 private static final int[] LIMITS={0,500,1000,5000};
 private HistoryRange(){}
 public static int index(int value){return value>=0&&value<LIMITS.length?value:0;}
 public static int limit(int value){return LIMITS[index(value)];}
 public static String label(int value){return LABELS[index(value)];}
 public static String[] labels(){return LABELS.clone();}
}
