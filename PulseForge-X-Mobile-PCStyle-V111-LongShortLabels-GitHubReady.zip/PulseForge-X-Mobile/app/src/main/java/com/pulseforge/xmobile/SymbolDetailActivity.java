package com.pulseforge.xmobile;

import android.app.*;import android.os.*;import android.content.*;import android.graphics.Color;import android.net.Uri;import android.view.View;import android.widget.*;import org.json.*;import java.util.*;import java.util.concurrent.*;

public class SymbolDetailActivity extends Activity {
 private String symbol=""; private long alertTs=0,alertId=0,dropAlertTs=0,dropSignalId=0; private double dropAlertPrice=0,dropAlertScore=0,dropAlertDrawdown=0; private String dropAlertStage="",dropAlertReason=""; private boolean fromDropAlert=false; private PulseDb db; private PulseDb.AlertRow alert; private PulseDb.DropRow dropAlert;
 private TextView stage,dropRiskInfo,dropAlertInfo,alertInfo,info,chartStatus,newsStatus; private MiniChartView lineChart; private CandleChartView candleChart; private Spinner timeframe; private CheckBox markerToggle; private LinearLayout detailOrderContainer,newsList; private View chartSection,binanceSection,analysisSection;
 private ExecutorService net=Executors.newSingleThreadExecutor(); private ExecutorService newsNet=Executors.newFixedThreadPool(2);
 private int newsDays=3; private Future<?> newsTask; private final NewsRequestGate newsGate=new NewsRequestGate();
 private volatile boolean loadingOlder=false; private int activeChartPos=0; private android.content.SharedPreferences prefs;
 private final String[] tfNames={"선형(스캔)","1분봉","3분봉","5분봉","15분봉","30분봉","1시간봉","2시간봉","4시간봉","6시간봉","8시간봉","12시간봉","1일봉","1주봉","1달봉"};
 private final String[] intervals={"","1m","3m","5m","15m","30m","1h","2h","4h","6h","8h","12h","1d","1w","1M"};
 private final long[] intervalMs={0,60000L,180000L,300000L,900000L,1800000L,3600000L,7200000L,14400000L,21600000L,28800000L,43200000L,86400000L,604800000L,2592000000L};

 public void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_symbol_detail);db=new PulseDb(this);prefs=getSharedPreferences("pulseforge_ui",MODE_PRIVATE);symbol=String.valueOf(getIntent().getStringExtra("symbol"));if("null".equals(symbol))symbol="";fromDropAlert=getIntent().getBooleanExtra("drop_alert",false);dropSignalId=getIntent().getLongExtra("drop_signal_id",0);dropAlertTs=getIntent().getLongExtra("drop_alert_ts",0);dropAlertPrice=getIntent().getDoubleExtra("drop_alert_price",0);dropAlertScore=getIntent().getDoubleExtra("drop_alert_score",0);dropAlertDrawdown=getIntent().getDoubleExtra("drop_alert_drawdown",0);dropAlertStage=String.valueOf(getIntent().getStringExtra("drop_alert_stage"));if("null".equals(dropAlertStage))dropAlertStage="";dropAlertReason=String.valueOf(getIntent().getStringExtra("drop_alert_reason"));if("null".equals(dropAlertReason))dropAlertReason="";if(dropSignalId>0)dropAlert=db.dropById(dropSignalId);if(dropAlert!=null){dropAlertTs=dropAlert.ts;dropAlertPrice=dropAlert.price;dropAlertScore=dropAlert.score;dropAlertDrawdown=dropAlert.drawdownHigh;dropAlertStage=dropAlert.stage;dropAlertReason=dropAlert.reason;}alertId=getIntent().getLongExtra("alert_id",0);alertTs=getIntent().getLongExtra("alert_ts",0);if(alertId>0)alert=db.alertById(alertId);if(alert==null&&alertTs>0)alert=db.alertByTs(symbol,alertTs);if(alert!=null){alertId=alert.id;alertTs=alert.ts;}
  ((TextView)findViewById(R.id.symbol)).setText(symbol);stage=findViewById(R.id.stage);dropRiskInfo=findViewById(R.id.dropRiskInfo);dropAlertInfo=findViewById(R.id.dropAlertInfo);alertInfo=findViewById(R.id.alertInfo);info=findViewById(R.id.info);chartStatus=findViewById(R.id.chartStatus);newsStatus=findViewById(R.id.newsStatus);newsList=findViewById(R.id.newsList);lineChart=findViewById(R.id.lineChart);candleChart=findViewById(R.id.candleChart);timeframe=findViewById(R.id.timeframe);markerToggle=findViewById(R.id.markerToggle);detailOrderContainer=findViewById(R.id.detailOrderContainer);chartSection=findViewById(R.id.chartSection);binanceSection=findViewById(R.id.binanceSection);analysisSection=findViewById(R.id.analysisSection);applySectionOrder();
  candleChart.setOnNeedOlderListener(oldest->loadOlder(oldest));
  long markerTs=alertTs>0?alertTs:dropAlertTs;double markerPrice=alert!=null?alert.price:dropAlertPrice;candleChart.setAlertReference(markerPrice);
  findViewById(R.id.back).setOnClickListener(v->finish());findViewById(R.id.binance).setOnClickListener(v->openBinance());findViewById(R.id.newsRefresh).setOnClickListener(v->loadNews(true));findViewById(R.id.newsSearch).setOnClickListener(v->openNewsSearch());
  initNewsTabs(b);
  findViewById(R.id.chartHome).setOnClickListener(v->{if(candleChart.getVisibility()==View.VISIBLE)candleChart.resetZoom();});
  findViewById(R.id.chartMinus).setOnClickListener(v->{if(candleChart.getVisibility()==View.VISIBLE)candleChart.zoomOut();});
  findViewById(R.id.chartPlus).setOnClickListener(v->{if(candleChart.getVisibility()==View.VISIBLE)candleChart.zoomIn();});
  findViewById(R.id.chartFull).setOnClickListener(v->openFullChart());
  timeframe.setAdapter(new PfSpinnerAdapter(this,tfNames));markerToggle.setChecked(markerTs>0);markerToggle.setVisibility(markerTs>0?View.VISIBLE:View.GONE);markerToggle.setText(fromDropAlert?"숏 알림 위치 표시":"롱 알림 위치 표시");candleChart.setMarker(markerTs*1000L,markerToggle.isChecked());markerToggle.setOnCheckedChangeListener((btt,on)->{lineChart.setMarkerVisible(on);candleChart.setMarker(markerTs*1000L,on);});
  int savedTf=prefs.getInt("detail_chart_tf",3); if(savedTf<0||savedTf>=tfNames.length)savedTf=3; timeframe.setSelection(savedTf,false);
  timeframe.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onItemSelected(android.widget.AdapterView<?>p,View v,int pos,long id){prefs.edit().putInt("detail_chart_tf",pos).apply();loadChart(pos);}public void onNothingSelected(android.widget.AdapterView<?>p){}});
  loadChart(savedTf);
  loadNews(false);
  renderInfo();net.submit(()->{try{db.evaluatePendingAlerts(System.currentTimeMillis()/1000);}catch(Exception ignored){}runOnUiThread(this::renderInfo);});
 }


 void applySectionOrder(){
  if(detailOrderContainer==null)return;
  String raw=getSharedPreferences("settings",0).getString("DETAIL_SECTION_ORDER","chart,binance,analysis");
  String[] parts=raw.split(",");java.util.LinkedHashSet<String> order=new java.util.LinkedHashSet<>();for(String x:parts)if("chart".equals(x)||"binance".equals(x)||"analysis".equals(x))order.add(x);order.add("chart");order.add("binance");order.add("analysis");
  detailOrderContainer.removeAllViews();for(String x:order){if("chart".equals(x))detailOrderContainer.addView(chartSection);else if("binance".equals(x))detailOrderContainer.addView(binanceSection);else if("analysis".equals(x))detailOrderContainer.addView(analysisSection);}
 }

 void renderInfo(){PulseDb.Latest x=db.latest(symbol);String curStage=x==null?"QUIET":ScoreEngine.stage(x.score);if(x!=null&&x.lateFlag!=null&&!x.lateFlag.isEmpty()){String rawStage=ScoreEngine.stage(x.preLateScore);stage.setText(SignalLabels.text("후행차단 · "+ScoreEngine.lateLabel(x.lateFlag)+" · 원 "+rawStage+" "+String.format(Locale.US,"%.1f",x.preLateScore)+" → "+String.format(Locale.US,"%.1f점",x.score)));stage.setTextColor(Color.parseColor("#98A2B3"));}else{stage.setText(SignalLabels.text(x==null?"데이터 준비 중":curStage+" · "+String.format(Locale.US,"%.1f점",x.score)));stage.setTextColor(stageColor(curStage));}
  if(x==null){dropRiskInfo.setText(SignalLabels.text("⚠ 숏 예측 분석 준비 중"));dropRiskInfo.setTextColor(Color.parseColor("#98A2B3"));}else{String ds=ScoreEngine.dropStage(x.dropScore,x.dropTopHeat,x.dropExhaustion,x.dropReversal,x.dropDrawdownHigh);dropRiskInfo.setText(SignalLabels.text("⚠ 숏 예측  "+ds+" · "+String.format(Locale.US,"%.1f점",x.dropScore)+"\n과열 "+String.format(Locale.US,"%.0f",x.dropTopHeat)+" · 소진 "+String.format(Locale.US,"%.0f",x.dropExhaustion)+" · 반전 "+String.format(Locale.US,"%.0f",x.dropReversal)+" · OI과열 "+String.format(Locale.US,"%.0f",x.dropOiHeat)+"\n최근고점 대비 "+String.format(Locale.US,"%+.2f%%",x.dropDrawdownHigh)+" · "+x.dropReason));dropRiskInfo.setTextColor(dropStageColor(ds));}
  if(fromDropAlert&&dropAlertTs>0){StringBuilder da=new StringBuilder();if(dropAlert!=null&&dropAlert.suppressed){da.append("후행차단 기록  · 푸시 알림 제외\n원 ").append(dropAlert.stage).append(" ").append(String.format(Locale.US,"%.1f점",dropAlert.baseScore)).append(" → 차단후 ").append(String.format(Locale.US,"%.1f점",dropAlert.score)).append("\n차단근거  ").append(ScoreEngine.dropLateLabel(dropAlert.lateFlag)).append(" · 후행패널티 ").append(String.format(Locale.US,"%.1f점",dropAlert.latePenalty));}else da.append("🔔 숏 예측 알림 당시\n").append(dropAlertStage).append(" · ").append(String.format(Locale.US,"%.1f점",dropAlertScore));da.append("\n시간  ").append(date(dropAlertTs)).append(" · 기준가 ").append(fmt(dropAlertPrice)).append(" · 고점대비 ").append(String.format(Locale.US,"%+.2f%%",dropAlertDrawdown));if(!empty(dropAlertReason))da.append("\n위험근거  ").append(dropAlertReason);if(dropAlert!=null){Map<Integer,PulseDb.DropOutcome> outs=db.dropOutcomes(dropAlert.id);da.append("\n\n사후평가");for(int h:PulseDb.HORIZONS){PulseDb.DropOutcome o=outs.get(h);da.append("\n").append(hLabel(h)).append("  ");if(o==null)da.append("대기 중");else da.append(String.format(Locale.US,"%+.2f%%",o.ret)).append("  · 최대하락 ").append(String.format(Locale.US,"%+.2f%%",o.maxDown)).append(" · 역행상승 ").append(String.format(Locale.US,"%+.2f%%",o.maxUp));}}dropAlertInfo.setText(SignalLabels.text(da.toString()));dropAlertInfo.setVisibility(View.VISIBLE);}else dropAlertInfo.setVisibility(View.GONE);
  if(alert!=null){Map<Integer,PulseDb.Outcome> outs=db.outcomes(alert.id);double since=x!=null&&alert.price>0?(x.price/alert.price-1)*100:0;StringBuilder a=new StringBuilder();if(alert.suppressed)a.append("후행차단 기록  · 푸시 알림 제외\n원 ").append(alert.stage).append(" ").append(String.format(Locale.US,"%.1f점",alert.baseScore)).append(" → 차단후 ").append(String.format(Locale.US,"%.1f점",alert.score));else a.append("알림 당시  ").append(alert.stage).append(" · ").append(String.format(Locale.US,"%.1f점",alert.score));a.append("\n시간  ").append(date(alert.ts)).append("\n가격  ").append(fmt(alert.price));if(x!=null)a.append("  →  현재 ").append(fmt(x.price)).append("  (").append(String.format(Locale.US,"%+.2f%%",since)).append(")");a.append("\n판정 근거  ").append(empty(alert.reason)?"복합 선행 신호":alert.reason);if(!alert.suppressed){if(alert.leadLearnSamples>=5)a.append("\n선행역추적  ").append(alert.leadLearnSamples).append("건 · 평균 급등 ").append(String.format(Locale.US,"%+.2f%%",alert.leadLearnAvgGain)).append(" · 평균 선행 ").append(String.format(Locale.US,"%.0f분",alert.leadLearnAvgMinutes)).append(" · 보정 +").append(String.format(Locale.US,"%.1f점",alert.leadLearnBonus));if(alert.patternSamples>=5)a.append("\n유사패턴  ").append(alert.patternSamples).append("건 · 30m 평균 ").append(pct(alert.patternAvg30)).append(" · +3% ").append(pct0(alert.patternHit3)).append(" · -3% ").append(pct0(alert.patternDown3));else a.append("\n유사패턴  표본 ").append(alert.patternSamples).append("건 (V6 동일모델 5건부터 점수 보정)");}a.append("\n\n사후평가");PulseDb.Outcome lead=null;for(int h:PulseDb.HORIZONS){PulseDb.Outcome o=outs.get(h);a.append("\n").append(hLabel(h)).append("  ");if(o==null)a.append("대기 중");else{a.append(String.format(Locale.US,"%+.2f%%",o.ret)).append("  · MFE ").append(String.format(Locale.US,"%+.2f%%",o.maxUp)).append(" · MAE ").append(String.format(Locale.US,"%+.2f%%",o.maxDown));lead=o;}}if(lead!=null)a.append("\n선행시간  +3% ").append(tHit(lead.timeTo3)).append(" · +5% ").append(tHit(lead.timeTo5)).append(" · +8% ").append(tHit(lead.timeTo8));alertInfo.setText(SignalLabels.text(a.toString()));alertInfo.setVisibility(View.VISIBLE);}else alertInfo.setVisibility(View.GONE);
  if(x==null){info.setText(SignalLabels.text("아직 저장된 분석 데이터가 없습니다."));return;}PulseDb.PatternStats p=db.patternStats(x.score,x.vz,x.oz,x.ret3,x.compression);String estimated=p.samples>=5?String.format(Locale.US,"%+.1f점",p.bonus):"표본 부족";int maxLev=db.maxLeverage(symbol);String levText=maxLev>0?maxLev+"x":"—";String risk=(x.lateFlag==null||x.lateFlag.isEmpty())?"정상":"차단 · "+ScoreEngine.lateLabel(x.lateFlag);info.setText(SignalLabels.text("현재 분석\n현재가  "+fmt(x.price)+"   ·  24h "+String.format(Locale.US,"%+.2f%%",x.change24)+"\n거래대금  "+money(x.qv)+"   ·  OI "+money(x.oi)+"   ·  최대배수 "+levText+"\nConfidence  "+String.format(Locale.US,"%.1f",x.confidence)+"   ·  VZ "+String.format(Locale.US,"%.2f",x.vz)+"   ·  OZ "+String.format(Locale.US,"%.2f",x.oz)+"\n1m "+String.format(Locale.US,"%+.2f%%",x.ret1)+" · 3m "+String.format(Locale.US,"%+.2f%%",x.ret3)+" · 5m "+String.format(Locale.US,"%+.2f%%",x.ret5)+"\n10m "+String.format(Locale.US,"%+.2f%%",x.ret10)+" · 20m "+String.format(Locale.US,"%+.2f%%",x.ret20)+" · 30m "+String.format(Locale.US,"%+.2f%%",x.ret30)+" · 60m "+String.format(Locale.US,"%+.2f%%",x.ret60)+"\n압축 "+String.format(Locale.US,"%.0f",x.compression)+"   ·  돌파직전 "+String.format(Locale.US,"%.0f",x.prebreakout)+"   ·  추격패널티 "+String.format(Locale.US,"%.1f",x.chase)+"\n20m평균 이격 "+String.format(Locale.US,"%+.2f%%",x.dist20)+"   ·  1m폭발비 "+String.format(Locale.US,"%.1f",x.burst)+"   ·  고점체류 "+x.staleHighMin+"분\n후행위험  "+risk+"   ·  후행패널티 "+String.format(Locale.US,"%.1f",x.latePenalty)+"\n선행조건 "+x.leadCount+"개   ·  Funding "+String.format(Locale.US,"%+.5f%%",x.funding*100)+"\n선행역추적  "+x.leadLearnSamples+"건   ·  선행보정 +"+String.format(Locale.US,"%.1f점",x.leadLearnBonus)+(x.leadLearnSamples>0?"   ·  평균급등 "+String.format(Locale.US,"%+.2f%%",x.leadLearnAvgGain)+" / 평균선행 "+String.format(Locale.US,"%.0f분",x.leadLearnAvgMinutes):"")+"\n유사패턴  "+p.samples+"건   ·  현재 통계 보정 "+estimated+"\n숏 예측  "+ScoreEngine.dropStage(x.dropScore,x.dropTopHeat,x.dropExhaustion,x.dropReversal,x.dropDrawdownHigh)+" "+String.format(Locale.US,"%.1f점",x.dropScore)+"   ·  고점대비 "+String.format(Locale.US,"%+.2f%%",x.dropDrawdownHigh)+"\n최근 분석  "+date(x.ts)));
 }

 void loadChart(int pos){
  activeChartPos=pos;
  if(pos<=0){loadLine();return;}
  lineChart.setVisibility(View.GONE);candleChart.setVisibility(View.VISIBLE);
  chartStatus.setText(tfNames[pos]+" 불러오는 중…");
  final String interval=intervals[pos];final long dur=intervalMs[pos];final int index=pos;
  net.submit(()->{try{
    Long start=null,end=null;
    long focusTs=alertTs>0?alertTs:dropAlertTs;if(focusTs>0){
      long center=focusTs*1000L;
      start=Math.max(0,center-360L*dur);
      end=Math.min(System.currentTimeMillis(),center+140L*dur);
    }
    JSONArray a=BinanceClient.klines(symbol,interval,500,start,end);
    ArrayList<CandleChartView.Candle> cs=new ArrayList<>();
    for(int i=0;i<a.length();i++){JSONArray k=a.getJSONArray(i);cs.add(new CandleChartView.Candle(k.getLong(0),num(k,1),num(k,2),num(k,3),num(k,4)));}
    runOnUiThread(()->{
      if(timeframe.getSelectedItemPosition()!=index)return;
      candleChart.setData(cs);candleChart.setMarker(focusTs*1000L,markerToggle.isChecked());
      chartStatus.setText(tfNames[index]+" · "+cs.size()+"개 · 길게 누르면 십자선/OHLC/알림가 대비% · 좌우 드래그=과거 탐색");
    });
  }catch(Exception e){runOnUiThread(()->{if(timeframe.getSelectedItemPosition()==index)chartStatus.setText(tfNames[index]+" 불러오기 실패 · 다시 선택하면 재시도");});}});
 }
 void loadOlder(long oldestMs){
  final int pos=activeChartPos;
  if(pos<=0||loadingOlder){candleChart.olderLoadFinished();return;}
  loadingOlder=true;chartStatus.setText(tfNames[pos]+" · 과거 캔들 추가 로딩 중…");
  final String interval=intervals[pos];final long dur=intervalMs[pos];
  net.submit(()->{try{
    long end=Math.max(0,oldestMs-1);
    long start=Math.max(0,end-500L*dur);
    JSONArray a=BinanceClient.klines(symbol,interval,500,start,end);
    ArrayList<CandleChartView.Candle> older=new ArrayList<>();
    for(int i=0;i<a.length();i++){JSONArray k=a.getJSONArray(i);older.add(new CandleChartView.Candle(k.getLong(0),num(k,1),num(k,2),num(k,3),num(k,4)));}
    runOnUiThread(()->{
      loadingOlder=false;
      if(timeframe.getSelectedItemPosition()!=pos){candleChart.olderLoadFinished();return;}
      int added=candleChart.prependData(older);
      if(added>0)chartStatus.setText(tfNames[pos]+" · 과거 "+added+"개 추가 · 계속 드래그하면 더 불러옴");
      else chartStatus.setText(tfNames[pos]+" · 더 이전 캔들이 없습니다");
    });
  }catch(Exception e){runOnUiThread(()->{loadingOlder=false;candleChart.olderLoadFinished();chartStatus.setText(tfNames[pos]+" · 과거 데이터 로딩 실패 · 다시 드래그하면 재시도");});}});
 }
 void loadLine(){
  candleChart.setVisibility(View.GONE);lineChart.setVisibility(View.VISIBLE);
  final long focusTs=alertTs>0?alertTs:dropAlertTs;List<PulseDb.Point> pts=db.points(symbol,focusTs);ArrayList<Double> local=new ArrayList<>();int localMarker=-1;long nearest=Long.MAX_VALUE;
  for(int i=0;i<pts.size();i++){PulseDb.Point p=pts.get(i);if(p.price<=0)continue;local.add(p.price);if(focusTs>0&&Math.abs(p.ts-focusTs)<nearest){nearest=Math.abs(p.ts-focusTs);localMarker=local.size()-1;}}
  boolean localUsable=local.size()>=(focusTs>0?20:10)&&(focusTs<=0||nearest<=180);
  lineChart.setData(local);lineChart.setMarkerIndex(localMarker);lineChart.setMarkerVisible(markerToggle.isChecked());
  if(localUsable){chartStatus.setText("선형(스캔) · PulseForge 60초 수집 "+local.size()+"개");return;}
  final int localCount=local.size();chartStatus.setText("선형(스캔) · 로컬 "+localCount+"개 · Binance 1분 데이터로 자동 보완 중…");
  net.submit(()->{try{
    long now=System.currentTimeMillis();Long start,end;
    if(focusTs>0){start=Math.max(0,(focusTs-45L*60L)*1000L);end=Math.min(now,(focusTs+90L*60L)*1000L);}else{end=now;start=Math.max(0,now-120L*60L*1000L);}
    JSONArray a=BinanceClient.klines(symbol,"1m",180,start,end);ArrayList<Double> ps=new ArrayList<>();int marker=-1;long best=Long.MAX_VALUE;
    for(int i=0;i<a.length();i++){JSONArray k=a.getJSONArray(i);double close=num(k,4);if(close<=0)continue;long ts=k.getLong(0)/1000L;ps.add(close);if(focusTs>0&&Math.abs(ts-focusTs)<best){best=Math.abs(ts-focusTs);marker=ps.size()-1;}}
    final int m=marker;runOnUiThread(()->{if(activeChartPos!=0||timeframe.getSelectedItemPosition()!=0)return;if(ps.size()>=2){lineChart.setData(ps);lineChart.setMarkerIndex(m);lineChart.setMarkerVisible(markerToggle.isChecked());chartStatus.setText("선형(보완) · Binance 1분 "+ps.size()+"개 · 로컬 스캔 부족 자동보완");}else if(localCount>=2)chartStatus.setText("선형(스캔) · 로컬 "+localCount+"개 · Binance 보완 데이터 부족");else chartStatus.setText("선형 데이터 부족 · 다시 선택하면 재시도");});
  }catch(Exception e){runOnUiThread(()->{if(activeChartPos!=0||timeframe.getSelectedItemPosition()!=0)return;if(localCount>=2)chartStatus.setText("선형(스캔) · 로컬 "+localCount+"개 · Binance 보완 실패 · 다시 선택하면 재시도");else chartStatus.setText("선형 데이터 부족 · Binance 보완 실패 · 다시 선택하면 재시도");});}});
 }
 void initNewsTabs(Bundle saved){
  if(saved!=null){int days=saved.getInt("news_range_days",3);if(days==3||days==7||days==14||days==30)newsDays=days;}
  RadioGroup tabs=findViewById(R.id.newsRangeTabs);
  tabs.check(newsDays==7?R.id.newsRange1w:newsDays==14?R.id.newsRange2w:newsDays==30?R.id.newsRange1m:R.id.newsRange3d);
  tabs.setOnCheckedChangeListener((group,id)->{int days=id==R.id.newsRange1w?7:id==R.id.newsRange2w?14:id==R.id.newsRange1m?30:3;if(days!=newsDays){newsDays=days;loadNews(false);}});
 }
 boolean currentNews(NewsRequestGate.Ticket ticket){return !isFinishing()&&!isDestroyed()&&newsGate.accepts(ticket);}
 void loadNews(boolean force){
  if(newsStatus==null||newsList==null||isFinishing()||isDestroyed())return;
  if(newsTask!=null)newsTask.cancel(true);
  final NewsRequestGate.Ticket ticket=newsGate.begin(newsDays);
  final String label=NewsClient.rangeLabel(ticket.days);
  newsList.removeAllViews();newsStatus.setText(label+(force?" · 한글 주요뉴스 새로고침 중…":" · 중요도 우선 한글 뉴스를 불러오는 중…"));
  newsTask=newsNet.submit(()->{try{ArrayList<NewsClient.Item> items=NewsClient.fetch(symbol,5,force,ticket.days);runOnUiThread(()->{if(currentNews(ticket))renderNews(items);});}catch(Exception e){runOnUiThread(()->{if(currentNews(ticket))newsStatus.setText(label+" · 뉴스 연결 실패 · 새로고침 또는 한글 뉴스 더 보기 사용");});}});
 }
 void renderNews(ArrayList<NewsClient.Item> items){
  newsList.removeAllViews();if(items==null||items.isEmpty()){TextView t=new TextView(this);t.setText(NewsClient.rangeLabel(newsDays)+" 내 가격 영향 가능성이 높은 한글 관련뉴스가 없습니다.");t.setTextColor(Color.parseColor("#98A2B3"));t.setTextSize(13);t.setPadding(4,12,4,12);newsList.addView(t);newsStatus.setText(NewsClient.rangeLabel(newsDays)+" · 핵심 재료 없음 · 단순 시세/가격전망 기사는 자동 제외");return;}
  int i=1;for(NewsClient.Item it:items){LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(12,12,12,12);LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,-2);bp.setMargins(0,5,0,5);box.setLayoutParams(bp);box.setBackgroundColor(Color.parseColor("#162337"));TextView tt=new TextView(this);String badge=(it.important?"핵심·":"")+(it.category==null?"관련":it.category);tt.setText((i++)+". ["+badge+"] "+it.title);tt.setTextColor(Color.parseColor("#74B7FF"));tt.setTextSize(14);tt.setTypeface(android.graphics.Typeface.DEFAULT,android.graphics.Typeface.BOLD);TextView sm=new TextView(this);sm.setText((it.source==null?"뉴스":it.source)+" · "+newsAge(it.ts)+" · 눌러서 원문보기");sm.setTextColor(Color.parseColor("#8FA0B5"));sm.setTextSize(11);sm.setPadding(0,5,0,0);View.OnClickListener l=v->openNewsUrl(it.url);box.setOnClickListener(l);tt.setOnClickListener(l);sm.setOnClickListener(l);box.addView(tt);box.addView(sm);newsList.addView(box);}newsStatus.setText(NewsClient.rangeLabel(newsDays)+" · 중요도 우선 "+items.size()+"개 · 시세/전망성 기사 제외 · 15분 캐시");
 }
 String newsAge(long ts){if(ts<=0)return "시간 미상";long sec=Math.max(0,(System.currentTimeMillis()-ts)/1000);if(sec<60)return "방금 전";if(sec<3600)return (sec/60)+"분 전";if(sec<86400)return (sec/3600)+"시간 전";return (sec/86400)+"일 전";}
 void openNewsUrl(String url){if(url==null||url.isEmpty())return;try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url)));}catch(Exception e){Toast.makeText(this,"뉴스 원문을 열 수 없습니다",Toast.LENGTH_SHORT).show();}}
 void openNewsSearch(){try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(NewsClient.searchUrl(symbol,newsDays))));}catch(Exception e){Toast.makeText(this,"뉴스 검색을 열 수 없습니다",Toast.LENGTH_SHORT).show();}}

 void openFullChart(){int pos=timeframe.getSelectedItemPosition();if(pos<=0){Toast.makeText(this,"캔들 시간봉을 선택하면 전체화면을 사용할 수 있습니다",Toast.LENGTH_SHORT).show();return;}Intent i=new Intent(this,ChartFullscreenActivity.class);i.putExtra("symbol",symbol);i.putExtra("interval",intervals[pos]);i.putExtra("label",tfNames[pos]);long focusTs=alertTs>0?alertTs:dropAlertTs;double focusPrice=alert!=null?alert.price:dropAlertPrice;i.putExtra("alert_ts",focusTs);i.putExtra("alert_price",focusPrice);startActivity(i);}
  double num(JSONArray a,int i)throws Exception{return Double.parseDouble(a.getString(i));}

 void openBinance(){android.content.ClipboardManager cm=(android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE);if(cm!=null)cm.setPrimaryClip(ClipData.newPlainText("PulseForge symbol",symbol));boolean opened=false;String web="https://www.binance.com/en/futures/"+Uri.encode(symbol);String dpPath="/trade/trade?at=futures&symbol="+symbol.toLowerCase(Locale.US);String dp=android.util.Base64.encodeToString(dpPath.getBytes(java.nio.charset.StandardCharsets.UTF_8),android.util.Base64.NO_WRAP);String officialDp=web+"?_dp="+dp;String appDp="https://app.binance.com/?_dp="+dp;for(String u:new String[]{officialDp,appDp}){if(opened)break;try{Intent x=new Intent(Intent.ACTION_VIEW,Uri.parse(u));x.setPackage("com.binance.dev");x.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);startActivity(x);opened=true;}catch(Exception ignored){}}if(!opened)try{Uri u=Uri.parse("bnc://app.binance.com/markets/markets?at=futures&symbol="+Uri.encode(symbol)+"&coin=um");Intent x=new Intent(Intent.ACTION_VIEW,u);x.setPackage("com.binance.dev");startActivity(x);opened=true;}catch(Exception ignored){}if(!opened)try{Intent x=getPackageManager().getLaunchIntentForPackage("com.binance.dev");if(x!=null){x.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);startActivity(x);opened=true;}}catch(Exception ignored){}if(!opened)try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(web)));opened=true;}catch(Exception ignored){}Toast.makeText(this,symbol+" Futures 직행을 다시 시도했습니다 · 종목까지 이동하지 않으면 심볼은 클립보드에 복사돼 있습니다",Toast.LENGTH_LONG).show();}

 int stageColor(String s){if("PRIME+".equals(s))return Color.parseColor("#C084FC");if("PRIME".equals(s))return Color.parseColor("#FF5D73");if("HOT".equals(s))return Color.parseColor("#FF9F43");if("ALERT".equals(s))return Color.parseColor("#F7C948");if("EARLY WATCH".equals(s))return Color.parseColor("#36C5F0");return Color.parseColor("#98A2B3");}
 int dropStageColor(String s){if("DROP RISK".equals(s))return Color.parseColor("#FF4770");if("REVERSAL".equals(s))return Color.parseColor("#FF7043");if("EXHAUST".equals(s))return Color.parseColor("#F7C948");if("TOP WATCH".equals(s))return Color.parseColor("#36C5F0");return Color.parseColor("#98A2B3");}
 String hLabel(int h){return h<60?h+"m":(h/60)+"h";}String date(long sec){return new java.text.SimpleDateFormat("MM/dd HH:mm:ss",Locale.KOREA).format(new Date(sec*1000));}String pct(Double v){return v==null?"-":String.format(Locale.US,"%+.2f%%",v);}String pct0(Double v){return v==null?"-":String.format(Locale.US,"%.0f%%",v);}String tHit(Double v){return v==null?"-":(v<10?String.format(Locale.US,"%.1f분",v):String.format(Locale.US,"%.0f분",v));}boolean empty(String s){return s==null||s.trim().isEmpty();}String fmt(double v){return v>=1?String.format(Locale.US,"%,.4f",v):String.format(Locale.US,"%.8f",v);}String money(double v){if(v>=1e9)return String.format(Locale.US,"%.2fB",v/1e9);if(v>=1e6)return String.format(Locale.US,"%.2fM",v/1e6);if(v>=1e3)return String.format(Locale.US,"%.1fK",v/1e3);return String.format(Locale.US,"%,.0f",v);}
 protected void onSaveInstanceState(Bundle out){out.putInt("news_range_days",newsDays);super.onSaveInstanceState(out);}
 protected void onDestroy(){newsGate.close();if(newsTask!=null)newsTask.cancel(true);net.shutdownNow();newsNet.shutdownNow();super.onDestroy();}
}
