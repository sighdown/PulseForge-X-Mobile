package com.pulseforge.xmobile;

import java.util.*;
import java.util.regex.*;

/** UI translation only: never write these labels into Core events or settings. */
public final class SignalLabels {
 private static final Map<String,String> STAGES;
 private static final Pattern TOKENS;
 static {
  LinkedHashMap<String,String> map=new LinkedHashMap<>();
  map.put("EARLY WATCH","롱1");map.put("ALERT","롱2");map.put("HOT","롱3");map.put("PRIME+","롱5");map.put("PRIME","롱4");
  map.put("TOP WATCH","숏1");map.put("EXHAUST","숏2");map.put("REVERSAL","숏3");map.put("DROP RISK","숏4");
  STAGES=Collections.unmodifiableMap(map);
  StringBuilder expression=new StringBuilder("(?<![A-Z0-9_])(");
  for(String key:map.keySet()){if(expression.charAt(expression.length()-1)!='(')expression.append('|');expression.append(Pattern.quote(key));}
  expression.append("|EARLY)(?![A-Z0-9_+])");TOKENS=Pattern.compile(expression.toString());
 }
 private SignalLabels(){}
 public static String stage(String raw){if(raw==null)return "";String label=STAGES.get(raw.toUpperCase(Locale.US));return label==null?raw:label;}
 public static String canonical(String label){if(label==null)return "";for(Map.Entry<String,String> entry:STAGES.entrySet())if(entry.getValue().equals(label))return entry.getKey();return label;}
 public static String[] longs(){return new String[]{"롱1","롱2","롱3","롱4","롱5"};}
 public static String[] shorts(){return new String[]{"숏1","숏2","숏3","숏4"};}
 public static String text(String input){
  if(input==null)return "";
  String value=input.replace("고점/급락 위험","숏 예측").replace("급등 선행","롱 예측").replace("급등선행","롱 예측")
   .replace("급락 위험","숏 예측").replace("급락위험","숏 예측").replace("급등 알림","롱 알림").replace("급락 알림","숏 알림").replace("급등/급락","롱/숏");
  Matcher matcher=TOKENS.matcher(value);StringBuffer out=new StringBuffer();
  while(matcher.find()){String label="EARLY".equals(matcher.group())?"롱1":stage(matcher.group());matcher.appendReplacement(out,Matcher.quoteReplacement(label));}
  matcher.appendTail(out);return out.toString();
 }
 public static String[] texts(String[] inputs){String[] out=new String[inputs.length];for(int i=0;i<inputs.length;i++)out[i]=text(inputs[i]);return out;}
}
