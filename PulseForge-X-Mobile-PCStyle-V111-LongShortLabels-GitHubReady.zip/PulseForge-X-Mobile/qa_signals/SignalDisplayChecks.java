package com.pulseforge.xmobile;

import java.util.*;
import java.util.concurrent.*;

/** Plain JVM checks. No Android device, user DB or network is used. */
public final class SignalDisplayChecks {
 private static int checks;
 private static void check(boolean ok,String message){checks++;if(!ok)throw new AssertionError(message);}
 public static void main(String[] args)throws Exception{
  String[] raw={"EARLY WATCH","ALERT","HOT","PRIME","PRIME+","TOP WATCH","EXHAUST","REVERSAL","DROP RISK"};
  String[] display={"롱1","롱2","롱3","롱4","롱5","숏1","숏2","숏3","숏4"};
  for(int i=0;i<raw.length;i++){
   check(display[i].equals(SignalLabels.stage(raw[i])),"stage display "+raw[i]);
   check(raw[i].equals(SignalLabels.canonical(display[i])),"canonical identity "+raw[i]);
   check(("#147224 · "+display[i]+" · 94.0점").equals(SignalLabels.text("#147224 · "+raw[i]+" · 94.0점")),"row text "+raw[i]);
  }
  check(SignalLabels.longs().length==5&&SignalLabels.shorts().length==4,"keep stage counts");
  check("롱 예측 / 숏 예측 · 롱 알림 / 숏 알림".equals(SignalLabels.text("급등 선행 / 급락 위험 · 급등 알림 / 급락 알림")),"direction names");
  check("PRIME_PLUS DROP_NOTIFY_RISK ALERT_HISTORY_FILTER".equals(SignalLabels.text("PRIME_PLUS DROP_NOTIFY_RISK ALERT_HISTORY_FILTER")),"preference-like tokens are not rewritten");
  check("BTCUSDT · +5.25% · 50x · #100001".equals(SignalLabels.text("BTCUSDT · +5.25% · 50x · #100001")),"numeric and symbol identity");
  check("CUSTOM STAGE".equals(SignalLabels.stage("CUSTOM STAGE")),"unknown stages remain visible");
  String[] names=SignalLabels.longs();names[0]="changed";check("롱1".equals(SignalLabels.longs()[0]),"label option isolation");
  check(HistoryRange.limit(0)==0&&"전체".equals(HistoryRange.label(0)),"default is all");
  check(HistoryRange.limit(1)==500&&HistoryRange.limit(2)==1000&&HistoryRange.limit(3)==5000,"recent limits");
  check(HistoryRange.limit(-1)==0&&HistoryRange.limit(99)==0,"invalid range returns to all");
  String[] ranges=HistoryRange.labels();ranges[0]="changed";check("전체".equals(HistoryRange.labels()[0]),"range option isolation");
  HistoryRequestGate gate=new HistoryRequestGate();int first=gate.begin();check(gate.accepts(first),"initial request");
  int second=gate.begin();check(!gate.accepts(first)&&gate.accepts(second),"new filter invalidates old request");
  int third=gate.begin();check(!gate.accepts(second)&&gate.accepts(third),"A to B to A request identity");
  ExecutorService pool=Executors.newSingleThreadExecutor();CountDownLatch started=new CountDownLatch(1),release=new CountDownLatch(1);
  List<Integer> published=Collections.synchronizedList(new ArrayList<>());int slow=gate.begin();
  Future<?> pending=pool.submit(()->{started.countDown();try{release.await();}catch(InterruptedException e){Thread.currentThread().interrupt();return;}if(gate.accepts(slow))published.add(slow);});
  check(started.await(2,TimeUnit.SECONDS),"worker started");int latest=gate.begin();if(gate.accepts(latest))published.add(latest);
  release.countDown();pending.get(2,TimeUnit.SECONDS);pool.shutdownNow();
  check(published.equals(Collections.singletonList(latest)),"late worker cannot replace new filter results");
  gate.close();check(!gate.accepts(latest),"destroy invalidates pending result");check(!gate.accepts(gate.begin()),"destroyed gate remains closed");
  System.out.println("Signal display / history range / async result checks: PASS ("+checks+" assertions)");
 }
}
